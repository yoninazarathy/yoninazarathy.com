package haifa.shopsim.lab;

import haifa.shopsim.*;

/**A Size chooser that uses an array P1,...,PR of proportions.  And N, a multiplicity factor.
 *@version 0.60
 */
public class ProportionalProblemSizeChooser extends AbstractProblemSizeChooser{

    /**The array of proportions.*/
    protected int [] Pr;
    
    /**The multiplicity of the problem.*/
    protected int N=1;

    public ProportionalProblemSizeChooser() {    }
    
    
    public ProportionalProblemSizeChooser(ShopData shopData_) {
        super(shopData_);
    }
    
    public ProportionalProblemSizeChooser(ShopData shopData_,int [] Pr_){
        super(shopData_);
        setPr(Pr_);
    }
    
    
    public void setN(int N_){
        N=N_;
       for(int i=0;i<Pr.length;i++)
            Nr[i]=Pr[i]*N;
    }

    public void setPr(int []Pr_){
        Pr=Pr_;
        for(int i=0;i<Pr.length;i++)
            Nr[i]=Pr[i]*N;
    }
    
    public int getN(){
        return N;
    }
}//END OF CLASS