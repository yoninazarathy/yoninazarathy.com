package haifa.shopsim.lab;

import java.util.*;


/**Returns a weibull R.V. with shape parameter = 1/2.  This is an r.v. with a hazarad rate of C e^-1/2.
*@version 0.60
 */
public class WeibullHalfRandomTimeMaker extends AbstractRandomTimeMaker {

    /** Returns the weibull 1/2 r.v. with specified mean.  (uses a transofmration from an exponential r.v.)*/
    public double getTime(double mean) {
		double betta=Math.sqrt(mean/2);
		double expRV=-betta*Math.log(random.nextDouble());
		return expRV*expRV;
    }
}//END OF CLASS