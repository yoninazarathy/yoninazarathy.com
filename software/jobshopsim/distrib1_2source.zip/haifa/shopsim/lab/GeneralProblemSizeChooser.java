package haifa.shopsim.lab;

import haifa.shopsim.*;

/**A size chooser that has a setNr() method and may be set to any size.  This is used by the GUI.
 *@version 0.60
 */
public class GeneralProblemSizeChooser extends AbstractProblemSizeChooser {

    public GeneralProblemSizeChooser() {}
    
    public GeneralProblemSizeChooser(ShopData shopData_) {
        super(shopData_);
    }

    /**Sets the number of routes to the value of Nr[]*/
    public void setNr(int Nr_[]){
        Nr=new int[Nr_.length];
        System.arraycopy(Nr_,0,Nr,0,Nr_.length);
    }
}//END OF CLASS