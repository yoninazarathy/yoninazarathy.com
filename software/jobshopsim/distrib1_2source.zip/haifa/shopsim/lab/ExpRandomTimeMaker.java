package haifa.shopsim.lab;

import java.util.*;

/**Returns exponential (CV=1) random variables.
 *@version 0.60
 */
public class ExpRandomTimeMaker extends AbstractRandomTimeMaker {
    
    /** Returns a random exponential variable with mean. */
    public double getTime(double mean) {
        return  -mean*Math.log(random.nextDouble());
    }
}//END OF CLASS