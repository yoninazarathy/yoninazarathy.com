package haifa.shopsim.lab;

import haifa.shopsim.*;

/**Maintains references to the shop data and the Nr[] array.  To be derived to working problem size choosers.
  * @version 0.6
 */
public abstract class AbstractProblemSizeChooser implements ProblemSizeChooser {

    /**The array of number of jobs on each route */
    protected int [] Nr;    

    /**A reference to the shop Data object.*/
    protected ShopData shopData;

    protected AbstractProblemSizeChooser(ShopData shopData_){
      setData(shopData_);  
    }

    /** Set the shop data object.  If Nr[] is null or not of the correct size it is reinitilized*/
    public void setData(ShopData shopData_) {
        shopData=shopData_;
        if(Nr==null || Nr.length !=shopData.getR()){
            Nr=new int[shopData.getR()];
        }
    }

    
    /** Returns an array, spcifing how many jobs are to be in each route. */
    public int[] getNr() {
        return Nr;
    }
    
    /**Sums the values of Nr[] and returns the sum.  This is the total number of jobs.  */
    public int getN(){
        int sum=0;
        for(int r=0;r<Nr.length;r++)
            sum+=Nr[r];
        return sum;
    }
    
    /** Creates new AbstractProblemSizeChooser */
    public AbstractProblemSizeChooser() {
    }

}
