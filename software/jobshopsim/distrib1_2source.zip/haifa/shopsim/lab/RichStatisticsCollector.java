package haifa.shopsim.lab;

import haifa.shopsim.*;

/**This is a statitiscis collector that creates a RichShopStatittics object.
 *@version 0.60
 */
public class RichStatisticsCollector extends StatisticsCollector {

    /**The name of the .jbs file used to create the shop.*/
    String jbsFileName;
    
    /**The random time maker name.*/
    String randomMaker;
    
    /**The algorithm name.*/
    String algorithmName;
    
    /** Creates new RichStatisticsCollector */
    public RichStatisticsCollector(ShopData shopData_, ShopState shopState_,String jbsFileName_ ,
                                                        String randomMaker_, String algorithmName_) {
          super( shopData_,  shopState_);
          jbsFileName=jbsFileName_;
          randomMaker=randomMaker_;
          algorithmName=algorithmName_;
    }
    
    /**Recacts to changes in the shop and collects stats.*/
    public void shopChanged(ShopChangeEvent sce) {
        //The only event that should caus the collector to act differently is the shop started event
        if(sce instanceof ShopStartedEvent){
            shopStatistics= new RichShopStatistics(shopData.getI(),jbsFileName,randomMaker,algorithmName);
            shopStatistics.incEvents();
            RichShopStatistics rss= (RichShopStatistics)shopStatistics;
            rss.setNr(shopState.getInitialNr());
            rss.setExpectedTimes(shopState.getExpectedProcessingTimes());
            for(int i=0;i<lastTimes.length;i++)
                lastTimes[i]=0.0;
            return;
        }
        //if here then this is not a shop started event.
        super.shopChanged(sce);
    }//END OF OVERRIDEN METHOD    
}//END OF CLASS