package haifa.shopsim.lab;

import haifa.shopsim.*;

/* *
 *A statistics collector expects to get the following ShopChangedEvents from the ShopSimulation:
 *<ul>
 *<li>ShopStartedEvent
 *<li>ShopFinishedEvent
 *<li>MachineStartedEvent (specfies machine).
 *<li>MachineFinsihedEvent (specifies machine).
 *<li>JobFinishedEvent
 *<li>WillingRestStartedEvent (specifies machine).
 *</ul>
 *
 *It is assumed that the first event is a ShopStartedEvent and the last event is the ShopFinishedEvent. It is also assumed that for each machine,
 *the MachineStartedEvent and MachineFinishedEvent come in matching pairs.  It is also known that a WillingRestStartedEvent comes
 *either for a specific machine as the first event for that machine (when the shop started and the machine decided to rest). Or it comes after
 *a MachineFinishedEvent.  It may not come after a MachineStartedEvent.
 *<P>
 *@version 0.60
 */
public class StatisticsCollector implements ShopChangeListener{

    /**The current shop statistics being collected.*/
    protected ShopStatistics shopStatistics;
    
    /**The statistics that have been completed by the last run.*/
    protected ShopStatistics finishedStatistics;
    
    /**A refrence to the shopdata object.*/
    protected ShopData shopData;
    
    /**A reference to the shopstate object.*/
    protected ShopState shopState;
    
     /**An array of time objects saying when the machine last had a started or finished event.*/
    protected double [] lastTimes;
    
    /**An array of booleans that has true for each machine is the last event was a willing rest time.*/
    protected  boolean [] lastEventWasWillingRest;
    
    /** Creates new StatisticsCollector */
    public StatisticsCollector(ShopData shopData_, ShopState shopState_) {
              shopData=shopData_;
              shopState=shopState_;
              lastTimes=new double[shopData.getI()];
              lastEventWasWillingRest = new boolean[shopData.getI()];
    }
    
    /**Called by the simulation whenever a shop change event takes place. Updates the statistics object that is being created accordingly.*/
    public void shopChanged(ShopChangeEvent sce) {
        //note that the implementation knows (assumes) that machinestarted events and machinefinished events
        //are alternating in the order in which they arrive. (it assumes some other stuff also).
        
        //System.out.println("StatCollector got: " + sce);
        
        if(shopStatistics!=null)
            shopStatistics.incEvents();
        
        double time=sce.getTime();
        
        if(sce instanceof ShopStartedEvent){
            shopStatistics= new ShopStatistics(shopData.getI());
            shopStatistics.incEvents();
            for(int i=0;i<lastTimes.length;i++)
                lastTimes[i]=0.0;
        }else  if(sce instanceof ShopFinishedEvent){
            for(int i=0;i<lastTimes.length;i++)
                if(lastTimes[i]!=time){//if machine is idle since lastTime
                   shopStatistics.increaseRestTime(i+1,time-lastTimes[i]); 
                   shopStatistics.increaseRestForGoodTime(i+1,time-lastTimes[i]); 
                }
           
            shopStatistics.seal();
            finishedStatistics=shopStatistics;
            shopStatistics=null;
            
        }else  if(sce instanceof MachineFinishedEvent){
             int machineNumber = ((MachineFinishedEvent)sce).getMachineNumber();
             lastEventWasWillingRest[machineNumber-1]=false;
             //System.out.println("Stat collector got: " + machineNumber + " finished  at " + time);

             shopStatistics.increaseWorkTime(machineNumber,time-lastTimes[machineNumber-1]);
             lastTimes[machineNumber-1]=time;
             
             if(shopState.isMachineDone(machineNumber))//maybe update the finish time
                    shopStatistics.maybeSetFinishTime(machineNumber,time);
            
        }else if(sce instanceof MachineStartedEvent){
             int machineNumber = ((MachineStartedEvent)sce).getMachineNumber();
             
             if(lastEventWasWillingRest[machineNumber-1]==true){
                    shopStatistics.increaseWillingRestTime(machineNumber,time-lastTimes[machineNumber-1]);
             }
             
             if(lastTimes[machineNumber-1]!=time){//if machine was idle for some period
                 shopStatistics.increaseRestTime(machineNumber,time-lastTimes[machineNumber-1]);

                 if(lastEventWasWillingRest[machineNumber-1]==false)//if jobs were avialable during the last time
                     shopStatistics.increaseStarveTime(machineNumber,time-lastTimes[machineNumber-1]);
                 
                 lastEventWasWillingRest[machineNumber-1]=false;
                 lastTimes[machineNumber-1]=time;//update time
             }
             
        }else if(sce instanceof JobFinishedEvent){
            shopStatistics.increaseFlowTime(time);
        }else if(sce instanceof WillingRestStartedEvent){
            int machineNumber = ((WillingRestStartedEvent)sce).getMachineNumber();
            
            if(lastTimes[machineNumber-1]!=time){//if machine was idle for some period
                 shopStatistics.increaseRestTime(machineNumber,time-lastTimes[machineNumber-1]);
            
                if(lastEventWasWillingRest[machineNumber-1]==true)
                    shopStatistics.increaseWillingRestTime(machineNumber,time-lastTimes[machineNumber-1]);

                if(lastEventWasWillingRest[machineNumber-1]==false)//if jobs were avialable during the last time
                         shopStatistics.increaseStarveTime(machineNumber,time-lastTimes[machineNumber-1]);
            }
            lastEventWasWillingRest[machineNumber-1]=true;
            lastTimes[machineNumber-1]=time;//update time
        }else{
          //other events, nothing to do  
        }
    }//END OF METHOD
    
    /**Returns the statistics object collected by the last run. Returns null if the statistics aren't complete yet.*/
    public ShopStatistics getStats(){
        if(finishedStatistics.isComplete())
            return finishedStatistics;
        else
            return null;
    }//END OF METHOD
    
    /**Returns the string of the last shopStatistics object. */
    public String toString(){
        StringBuffer sb = new StringBuffer();
        sb.append(getStats());
        return sb.toString();
    }//END OF toString METHOD
}//END OF CLASS 