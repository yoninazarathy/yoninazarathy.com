package haifa.shopsim.lab;

import haifa.global.*;

import java.io.*;

/**This object is the result of an observation of a shop simulation run.  It holds the data that describes the manner in which the run occured. 
 *This data is then to be analyzed. The object offers methods for updating the data.  These methods are to be used by a StatisticsCollector 
 *object.  Note that a ShopStatistics object maybe in a sealed state meanning that it is not changable anymore.  Currently, the changing
 *methods do not inforce this state.<P>
 *The pieces of infomration that this object holds are:
 *<ul>
 *<li>A static serial number, one is generated for each such object within a loading instance of a class (one per JVM). Used for debugging.
 *<li>The number of simulation events that were thrown (this is used for debugging.)
 *<li>The finish times of all machines (the time at which the machines were deemed uneeded in the shop.
 *<li>The makespan, this is the max of the finish times of all machines.
 *<li>The last working machine/s. This is the machine (or at rare instances several machines) that ended the job shop.
 *<li>The Total Flow time, this is the total finishing time of all jobs.
 *<li>The Working times of all machines.   This is the time that each machine was busy during a shop.  This is also used to show the workload
 *on a machine during a shop run.
 *<li> The most working machine (this is called the bottlneck machine for a particular instance.)
 *<li>The rest times of all machines. (Note that the rest times + the work times equals the makespan.)
 *<li>The rest for good times of all machines. This is the time a machine is resting because it doesn't have work upstream (it finsihed.)
 * *<li>The starve times of all machines.  This is the total time that a machine had work upstream (had not finished yet) but did not have any 
 *current work because it's buffers were empty.
 *<li>The willing resst times of all machines.  This is the time that a machine had at least one job ready to be worked on but still decided to rest.
 *</ul>
 *<P>
 *This information is not minimal, but it doesn't hurt to much to store all of it (good for debugging.) Note:
 *<ul>
 *<li>The rest time plus the work time = the makespan.
 *<li>The rest for good time  + the starve times + the willing rest times = rest time
 *</ul>
*@version 0.60
 **/
public class ShopStatistics implements Serializable{

    /**A serial number counter of the shopStatistics run. (The first run of a JVM has serial number 1).*/
    protected static long serialNumCounter;
    
    /**Gets the unique serial number (unique per JVM).*/
    protected long serialNum;
    
    /**The number of machines in the shop.*/
    protected int I;
    
    /**The completion time of each machine (when it doesn't have material upstream.*/
    protected double [] finishTimes;
    
    /**The times during which each machine is working.*/
    protected double [] workTimes;
    
    /**The times during which each machine rests.*/
    protected double [] restTimes;
    
    /**The times during which each machine has material up stream but isn't working.*/
    protected double [] starveTimes;
    
    /**The time during which each machine had a job but was willing to rest.*/
    protected double [] willingRestTimes;
    
    /**The time during which a machine was resting because it was finished.*/
    protected double [] restForGoodTimes;
    
    /**The flow time.*/
    protected double flowTime;
    
    /**true when the job shop is finished and this object is not to be changed any more.*/
    protected boolean finished;
    
    /**The number of simulation events were fired*/
    protected long numSimulationEvents;
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////CONSTRUCTOR//////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /** Creates new ShopStatatistics  for a given number of machines.*/
    public ShopStatistics(int I_) {
        I=I_;
        serialNum=serialNumCounter++;
        finishTimes=new double[I];
        for(int i=0;i<finishTimes.length;i++)
            finishTimes[i]=-1.0;//meanning that machine still hasn't registered a finish time
        workTimes=new double[I];
        restTimes=new double[I];
        starveTimes=new double[I];
        restForGoodTimes=new double[I];
        willingRestTimes=new double[I];
    }

    
    public String toString(){
      StringBuffer sb = new StringBuffer("Shop Statistics (SN: "+serialNum+")\n");  
      sb.append("Num simulation events:\t").append(numSimulationEvents).append('\n');
      sb.append("Makespan:\t\t").append(getMakeSpan()).append('\n');
      sb.append("Flowtime:\t\t").append(getFlowTime()).append('\n');
      sb.append("Last working machine/s:\t").append(HaifaArrays.toStringArray(getLastWorkingMachines())).append('\n');
      sb.append("Most working machine/s:\t").append(HaifaArrays.toStringArray(getMostWorkingMachines())).append('\n');
      sb.append("Finish  times:\t\t").append(HaifaArrays.toStringArray(getFinishTimes())).append('\n');
      sb.append("Work times:\t\t").append(HaifaArrays.toStringArray(getWorkTimes())).append('\n');
      sb.append("Rest times:\t\t").append(HaifaArrays.toStringArray(getRestTimes())).append('\n');
      sb.append("Starve times:\t\t").append(HaifaArrays.toStringArray(getStarveTimes())).append('\n');
      sb.append("Willing rest times:\t").append(HaifaArrays.toStringArray(getWillingRestTimes())).append('\n');
      sb.append("Rest for good times:\t").append(HaifaArrays.toStringArray(getRestForGoodTimes())).append('\n');
      return sb.toString();
    }//end of method

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////METHODS THAT CHANGE THE SHOP STATISTICS OBJECT///////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /**Increments the count of number of simulation events.*/
    public void incEvents(){
        numSimulationEvents++;
    }
    
    /**Sets the finish time for a machine.*/
    public void setFinishTime(int machineNum,double finishTime){
        finishTimes[machineNum-1]=finishTime;
    }
    
    /**Updates the finish time of a machine if it still hasn't been updated (if it hasn't registered as finished yet.)*/
    public void maybeSetFinishTime(int machineNum, double finishTime){
        machineNum--;
        if(finishTimes[machineNum]==-1.0)//if hasn't been updated yet
            finishTimes[machineNum]=finishTime;
    }
    
    /**Increases the work time of a machine.*/
    public void increaseWorkTime(int machineNum, double delta){
        workTimes[machineNum-1]+=delta;
    }
    
    /**Increases the rest time of a machine.*/
    public void increaseRestTime(int machineNum, double delta){
        restTimes[machineNum-1]+=delta;
    }
    
    /**Increases the starve time of a machine.*/
    public void increaseStarveTime(int machineNum, double delta){
        starveTimes[machineNum-1]+=delta;
    }

    /**Increases the rest for good time of a machine.*/
    public void increaseRestForGoodTime(int machineNum, double delta){
        restForGoodTimes[machineNum-1]+=delta;
    }
    
    /**Increases the willing rest time of a machine.*/
    public void increaseWillingRestTime(int machineNum, double delta){
        willingRestTimes[machineNum-1]+=delta;
    }
    
    /**Increases the flowtime by delta.*/
    public void increaseFlowTime(double delta){
      flowTime+=delta;  
    }
 
    /**Tell the shop statistics that there is no more incoming information.*/
    public void seal(){
      finished=true;  
    }
    
    /**Returns true if the statistics object is sealed.*/
    public boolean isComplete(){
        return finished;
    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////METHODS THAT GIVE OUT THE INFORMATION OF THE STATISTICS////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /**Returns the makespan.*/
    public double getMakeSpan(){
      return HaifaArrays.maxInArray(finishTimes);
    }
    
    /**Returns the total flow time.*/
    public double getFlowTime(){
        return flowTime;
    }

    /**Get the array of Last working machine indexs (indexes start at 1).*/
    public int [] getLastWorkingMachines(){
      int shitArray[]=HaifaArrays.maxIndexesInArray(finishTimes);
      for(int i=0;i<shitArray.length;i++)//offset the array to have machine numbers starting at 1
          shitArray[i]++;
      return shitArray;
    }

    /**Get the array of most working machine indexes (indexs start at 1), (this may often be one machine.*/
    public int[] getMostWorkingMachines(){
      int shitArray[]=HaifaArrays.maxIndexesInArray(workTimes);
      for(int i=0;i<shitArray.length;i++)//offset the array to have machine numbers starting at 1
          shitArray[i]++;
      return shitArray;
    }
    
    /**Returns a reference to the work times array.*/
    public double [] getWorkTimes(){
      return workTimes;  
    }
    
    /**Returns a reference to the starve times array.*/    
    public double[] getStarveTimes(){
        return starveTimes;
    }
    
    /**Returns a reference to the finsih times array.*/
    public double[] getFinishTimes(){
        return finishTimes;
    }
    
    /**Returns a reference to the resttimes array.*/
    public double [] getRestTimes(){
        return restTimes;
    }
    
    /**Returns a reference to the willing rest times array.*/
    public double [] getWillingRestTimes(){
        return willingRestTimes;
    }
    
    /**Returns a reference to the restForGoodTimes array.*/
    public double [] getRestForGoodTimes(){
        return restForGoodTimes;
    }
}//END OF CLASS