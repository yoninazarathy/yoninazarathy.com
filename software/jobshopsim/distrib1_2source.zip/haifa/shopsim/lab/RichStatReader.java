package haifa.shopsim.lab;

import java.io.*;

/**This class simply runs from the command prompt and gets a file name argument. The file should have a serialized Object (actually of any type).
 *The class then prints the object to consoule.
 *@version 0.60
 */
public class RichStatReader{

    public static void main(String [] args)throws Exception{
      ObjectInputStream oin = new ObjectInputStream(
                                                                new FileInputStream(args[0]));
      try{
        while(true)
            System.out.println(oin.readObject());
      }catch(EOFException e){
        System.out.println("End of Data");  
      }
      oin.close();
    }
}//END OF CLASS