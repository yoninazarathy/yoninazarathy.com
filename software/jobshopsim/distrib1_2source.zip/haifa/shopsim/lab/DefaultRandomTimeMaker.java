package haifa.shopsim.lab;


/**Returns the mean as a random time (not random).
 *@version 0.60
 */
public class DefaultRandomTimeMaker  implements RandomTimeMaker {
    /**Simply returns the mean.*/
    public double getTime(double mean){
        return mean;
    }
}//END OF CLASS