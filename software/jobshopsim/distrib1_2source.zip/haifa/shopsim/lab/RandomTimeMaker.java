package haifa.shopsim.lab;

/**This interface is implemented by R.V. generator classes. 
 All classes should have a getTime() method that returns a next random time.
 *@version 0.60
 */
public interface RandomTimeMaker {
    /**Returns a random time based on a parameter, (usuaully a mean).*/
    public double getTime(double param);
}

