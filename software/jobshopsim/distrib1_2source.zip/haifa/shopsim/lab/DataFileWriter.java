package haifa.shopsim.lab;

import java.io.*;
import java.util.*;
import haifa.global.*;

/*Appends the contents of a file that has serialized RichStat objects
to a datafile with the following format:<P>
<PRE>
{
"BeginObs",
	69,
	{"mt10.jbs",  "NormalCV025TimeMaker","MakespanFIAalgorithm"},
	{
		{10, 10, 1770, 1360, 4020,70, 150, 510, 2120, 10},
		{	485800., 538360.,
			522100.,525610.,
			552680., 475090.,
			523010.,548840.,
			499100.,457730.},
	   	554253.2075371117,
	   	2.784427689739332*^9,
	   	{5},
	   	{9},
	   	{535662.7193536734, 535650.515728856, 536029.8962761507,
	   		553542.3283255778, 554171.1951438864, 554131.0363729052,
	   		554132.4889776238, 553889.4802696968, 554253.2075371117,
	   		554102.3952946762},
	   	{487885.0505630666, 535650.515728856,
	   		524193.2789870287, 526954.5978263228, 553638.8319115526,
	   		476253.9628977876, 522696.745456811, 548115.616592135,
	   		499337.50709046016,
	   		458340.10856098036},
	   	{66368.1569740451, 18602.69180825574,
	   		30059.928550083016, 27298.609710788915, 614.3756255591423,
	   		77999.24463932408, 31556.462080300702, 6137.59094497667,
	   		54915.70044665154, 95913.09897613138},
	   	{47777.66879060678, 0.,  11836.61728912202, 26587.730499254983,
	   		532.3632323338087,
	   		77877.07347511762, 31435.743520812746, 5773.863677561756,
	   		54915.70044665154, 95762.28673369586},
	   	{0., 0., 0., 0., 0., 0., 0., 0., 0., 0.},
	   	{18590.488183438312, 18602.69180825574,
	   		18223.311260960996,
	   		710.8792115339311, 82.01239322533365,
	   		122.17116420646198, 120.71855948795564,
	   		363.7272674149135, 0., 150.81224243552424}
	}
}
</PRE>
 *Note that RandomMaker and Algorithm names may be of the sort: "haifa.shopsim.lab.ExpRandomTimeMaker"... Such names
 *will be stripped to "ExpRandomTimeMaker".
 *@version 0.60
 */
public class DataFileWriter{
	private static String onlyClassName(String fullName){
		StringBuffer sb = new StringBuffer(fullName);
		StringTokenizer st = new StringTokenizer(sb.reverse().toString(),".");
		StringBuffer our = new StringBuffer(st.nextToken());
		return our.reverse().toString();
	}

	private static void printToFile(FileWriter fw, RichShopStatistics rss){
		PrintWriter pw = new PrintWriter(fw);
		pw.println('{');
		pw.println("\"BeginObs\",");
		pw.println("0,");
		pw.println("{\""+rss.getJbsFileName()+"\",\""+
					onlyClassName(rss.getRandomMakerName())+"\",\""+
					onlyClassName(rss.getAlgorithmName())+"\"},");
		printStory(pw,rss);
		pw.println("}");
		pw.println("");
		pw.flush();
	}

	private static void printStory(PrintWriter pw, RichShopStatistics rss){
		pw.println("{");
		pw.println(HaifaArrays.toStringArray(rss.getNr(),",","{","}")+",");
		pw.println(HaifaArrays.toStringArray(rss.getExpectedTimes(),",","{","}")+",");
		pw.println(rss.getMakeSpan()+",");
		pw.println(rss.getFlowTime()+",");
		pw.println(HaifaArrays.toStringArray(rss.getMostWorkingMachines(),",","{","}")+",");
		pw.println(HaifaArrays.toStringArray(rss.getLastWorkingMachines(),",","{","}")+",");

		pw.println(HaifaArrays.toStringArray(rss.getFinishTimes(),",","{","}")+",");
		pw.println(HaifaArrays.toStringArray(rss.getWorkTimes(),",","{","}")+",");
		pw.println(HaifaArrays.toStringArray(rss.getRestTimes(),",","{","}")+",");
		pw.println(HaifaArrays.toStringArray(rss.getStarveTimes(),",","{","}")+",");
		pw.println(HaifaArrays.toStringArray(rss.getWillingRestTimes(),",","{","}")+",");

		pw.println(HaifaArrays.toStringArray(rss.getRestForGoodTimes(),",","{","}"));

		pw.println("}");
	}

        /**Gets input files names at prompt, followed by the outfile name. May exit with a variety of exceptions.*/
	public static void main(String [] args)throws Exception{
		if(args.length<2){
			System.err.println("usage: java haifa.shopsim.lab.DataFileWriter " +
								"<inFile1 inFile2 ....> <outFile>");
			System.exit(1);
		}
		int numWrote=0;//the number of runs wrote
		String outFile = args[args.length-1];
		FileWriter fw= new FileWriter(outFile,true);
		for(int i=0;i<args.length-1;i++){//loop on all input files
			ObjectInputStream oin = new ObjectInputStream(
										new FileInputStream(args[i]));
			try{
				while(true){
					RichShopStatistics rss=(RichShopStatistics)oin.readObject();
					printToFile(fw,rss);
					numWrote++;
				}
			}catch(EOFException e){

			}
		}//end of for loop on all input files
		fw.close();
		System.out.println("Wrote " + numWrote + " runs to " + outFile);
	}
}//END OF CLASS