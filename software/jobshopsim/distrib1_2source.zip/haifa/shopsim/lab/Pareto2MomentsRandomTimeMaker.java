package haifa.shopsim.lab;

import java.util.*;


/**A pareto generator with only the first and second moments.
 *@version 0.60
 */
public class Pareto2MomentsRandomTimeMaker extends ParetoRandomTimeMaker{
    public Pareto2MomentsRandomTimeMaker() {
		super(3.0);
    }
}