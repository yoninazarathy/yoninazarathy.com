package haifa.shopsim.lab;

import haifa.shopsim.*;

/**This interface is implemented by classes that are used to specifiy the size of a problem at the start of a simulation. Basiclly the getNr() method
 is the essence of such classes.
 *@version 0.60
 */
public interface ProblemSizeChooser {
    /**Returns an array, spcifing how many jobs are to be in each route.*/
    public int [] getNr();
    
    /**Set the shop data object.*/
    public void setData(ShopData shopData);
}