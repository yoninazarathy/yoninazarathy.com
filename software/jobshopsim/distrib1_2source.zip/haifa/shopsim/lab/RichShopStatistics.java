package haifa.shopsim.lab;

import java.io.*;


/**This class is a shopStatistics object, but it also contains some more info. This info is information that doesn't have
 *to do with the way the shop ran but rather with the job shop problem being run:
 *<ul>
 *<li>The job shop file name.
 *<li>The random time maker name.
 *<li>The algorithm name.
 *<li>The initial Nr[] (number of jobs on each route.)
 *<li>The initial expected times. (assuming that one job moves on each route.)
 *</ul>
 *Note that this class implements serizliable so that it can be saved to file as is.
 *
 *@version 0.60
 */
public class RichShopStatistics extends ShopStatistics implements Serializable{

    /**The job shop file name.*/
    protected String jbsFileName;
    
    /**The name of the random time maker.*/
    protected String randomMaker;
    
    /**The algorithm name.*/
    protected String algorithmName;
    
    /**The inital number of jobs on each route.*/
    protected int [] Nr;
    
    /**The expected processing times for each machine. (Assuming that one job is on each route.)*/
    double [] expectedTimes;
    
    /** Creates new RichShopStatistics */
    public RichShopStatistics(      int I_,String jbsFileName_,
                                                      String randomMaker_,String algorithmName_) {
        super(I_);
        jbsFileName=jbsFileName_;
        randomMaker=randomMaker_;
        algorithmName=algorithmName_;
    }

    public String getJbsFileName(){
        return jbsFileName;
    }
    
    public String getRandomMakerName(){
        return randomMaker;
    }
    
    public String getAlgorithmName(){
        return algorithmName;
    }
    
    public int [] getNr(){
        return Nr;
    }
    
    public double [] getExpectedTimes(){
        return expectedTimes;
    }
    
    public void setNr(int [] Nr_){
        Nr=new int[Nr_.length];
        System.arraycopy(Nr_,0,Nr,0,Nr.length);
    }
    
    public void setExpectedTimes(double [] expectedTimes_){
        expectedTimes=expectedTimes_;
    }

    public String toString(){
      StringBuffer sb= new StringBuffer();
      sb.append(jbsFileName).append(" : ").append(randomMaker).append(" : ").append(algorithmName);
      sb.append("\n");
      sb.append("NR[]:").append(haifa.global.HaifaArrays.toStringArray(Nr)).append('\n');
      sb.append("ExpectedTimes:").append(haifa.global.HaifaArrays.toStringArray(expectedTimes)).append('\n');
      sb.append(super.toString());
      return sb.toString();
    }
}//END OF CLASS