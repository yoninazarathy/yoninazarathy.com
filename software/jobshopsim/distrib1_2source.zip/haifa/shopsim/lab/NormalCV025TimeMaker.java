package haifa.shopsim.lab;

import java.util.*;

/**A random time maker that makes a normal random variable with specified mean and coeffeicient of variation of 0.25.
 *This means that if the mean is u, the standard deviation is 0.25u. The random variable is guarnteed to be positive. The way
 *this is done is by sampling again when the very unprobable situation occurs that a non-positive r.v. was sampled.  Note that this
 *creates a slight error in the distribution.
 *@version 0.60
 */
public class NormalCV025TimeMaker extends AbstractRandomTimeMaker {
    
    /** Creates new ExpRandomTimeMaker */
    public NormalCV025TimeMaker() {
    }

    /** Returns a random exponential variable with mean. */
    public double getTime(double mean) {
        double z;
        do{
         z= (0.25*random.nextGaussian()+1.0)*mean;
        }while(z<=0);
        return z;
    }
}