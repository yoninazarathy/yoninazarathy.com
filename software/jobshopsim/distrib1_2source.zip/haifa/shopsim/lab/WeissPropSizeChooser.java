package haifa.shopsim.lab;

import haifa.shopsim.*;

/**This problem size chooser creates Nr's based on weiss's suggestion of proporitons. The contant proportions are for shop
 *sizes of 10, 20 and 50.
  *@version 0.60
 */
public class WeissPropSizeChooser extends AbstractProblemSizeChooser{

    /**The distribution (should sum up to 1).*/
    double [] Pdr;

    static final double [] ROUTES_10_ARRAY={0.04,0.04,0.04,0.04,0.04,
                                                                                0.1,0.1,0.1,
                                                                                0.25,0.25};

    static final double [] ROUTES_20_ARRAY={0.02,0.02,0.02,0.02,0.02,0.02,0.02,0.02,0.02,
                                                                                0.04,0.04,0.04,0.04,0.04,
                                                                                0.06,0.06,
                                                                                0.08,
                                                                                0.10,
                                                                                0.12,
                                                                                0.20};

    static final double [] ROUTES_50_ARRAY={0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,
                                                                                0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,
                                                                                0.02,0.02,0.02,0.02,0.02,0.02,0.02,0.02,0.02,
                                                                                0.03,0.03,0.03,
                                                                                0.04,0.04,
                                                                                0.05,0.05,
                                                                                0.08,
                                                                                0.15};


    private void validateConstants(){
        double sum=0.0;
        for(int i=0;i<ROUTES_10_ARRAY.length;i++)
            sum+=ROUTES_10_ARRAY[i];
        if(sum!=1.0)
            throw new Error("Constants(10) in WeissPropSizeChooser aren't correct:" + sum);
        sum=0.0;
        for(int i=0;i<ROUTES_20_ARRAY.length;i++)
            sum+=ROUTES_20_ARRAY[i];
        if(sum!=1.0)
            throw new Error("Constants(20) in WeissPropSizeChooser aren't correct:" + sum);
        sum=0.0;
        for(int i=0;i<ROUTES_50_ARRAY.length;i++)
            sum+=ROUTES_50_ARRAY[i];
        if(sum!=1.0)
            throw new Error("Constants(50) in WeissPropSizeChooser aren't correct:" + sum);
    }

    public WeissPropSizeChooser() {
        //validateConstants();
    }

    public WeissPropSizeChooser(ShopData shopData_) {
        super(shopData_);
        //validateConstants();
    }//end of con'tr


    public void setN(int N){
        System.out.println("In wiessPropSize chooser , setting N to : " + N);
        Nr=new int[shopData.getR()];
        int sumN=0;
        for(int i=0;i<Nr.length;i++){
            Nr[i]=(int)(Pdr[i]*N);
            sumN+=Nr[i];
        }

        sumN=N-sumN;
        //now spread sumN around
        outer:while(true){
            for(int i=0;i<Nr.length;i++){
				if(sumN==0)
                    break outer;
                Nr[i]++;
                sumN--;

            }
        }
        System.out.println("WeissPropSizeChooser: N was set to : " +N);
        System.out.println("Values of Nr are: " + haifa.global.HaifaArrays.toStringArray(Nr));
    }//END OF METHOD


    /** Set the shop data object. */
    public void setData(ShopData shopData_) {
        super.setData(shopData_);
        switch(shopData.getR()){
            case 10:
                Pdr=ROUTES_10_ARRAY;
                break;
            case 20:
                Pdr=ROUTES_20_ARRAY;
                break;
            case 50:
                Pdr=ROUTES_50_ARRAY;
                break;
           default:
               Pdr=null;
               System.err.println("WeissPropSizeChooser only supports route amounts of 10,20 or 50");
               System.exit(1);
        }///end of switch on number of routes
    }
}//END OF CLASS