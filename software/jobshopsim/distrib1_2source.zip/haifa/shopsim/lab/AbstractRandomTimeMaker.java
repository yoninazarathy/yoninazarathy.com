package haifa.shopsim.lab;

import java.util.Random;

/**Supplies the random field for all sub classes.  This is a uniform r.v. that is ensured to be set with a different seed in each consecutive instance
 *on the same thread.
  * @version 0.60
 */
abstract class AbstractRandomTimeMaker implements RandomTimeMaker{
    protected Random random;
    
    static private long lastSeed;
    
    protected AbstractRandomTimeMaker(){
        if(lastSeed==System.currentTimeMillis())
            lastSeed++;
        else
            lastSeed=System.currentTimeMillis();
        random = new Random(lastSeed);
    }
}