package haifa.shopsim.lab;

import java.util.*;


import haifa.shopsim.*;

/**
Creates a shop data object where the number of routes just about equals
the number of jobs.
It creates this based on:
<ul>
<li> I - The number of machines
<li> a - The parameter affecting the size of the routes, route sizes will be 
drawn from a discrete uniform distribution [I-a,I+a].
<li> machineMeans- This is an array of mean processing times per machines.  
 If the shop simulation wishes, it can pertubrate these means using some distribution.
<li> N - The number of jobs/routes
</ul>
 *This class is a GeneralShopDataArray.
 *@version 0.60
*/
public class RLikeNShopData extends FastAbstractShopData{

        /**The last seed that was used to create the lat object.  Ensures that conscutive objects have diffrent seeds.*/
	static long lastSeed=System.currentTimeMillis();

	/**Constructor gets arguments as specified by the class.*/
	public RLikeNShopData(int I_, int a, double [] machineMeans, int N_){
		//The cont'r modifies the data structures defined in the father classs GeneralShopDataArray	
		I=I_;
		R=N_;
		//for(int i=0;i<machineMeans.length;i++)
		//	System.out.println("machine "+(i+1)+" with mean " +machineMeans[i]);

		routes=new int[R][];
		stepDurations = new double[R][];
		if(lastSeed==System.currentTimeMillis())
			lastSeed++;//get a different seed if needed
		else
			lastSeed=System.currentTimeMillis();
		Random random=new Random(lastSeed);

		//loop on all jobs/routes and draw route lengths
		for(int r=0;r<R;r++){
			int size=random.nextInt(2*a+1)+I-a;//a uniform on [I-a,I+a]
			routes[r]=new int[size];
			stepDurations[r]=new double[size];
		}

		//loop on all routes and assign machines and proper durations	
		for(int r=0;r<R;r++){
			for(int s=0;s<routes[r].length;s++){//loop on all steps of route
				int luckyMachine = random.nextInt(I)+1;//get next random machine
				routes[r][s]=luckyMachine;
				stepDurations[r][s]=machineMeans[luckyMachine-1];//put the machine's mean in step duration
			}
		}//end of loop on all routes
                
                setUpFastData();
	}//end of co'tr

	/**For testing,
	as arguments enter: <I> <a> <N> and machine means**/
	public static void main(String [] args){
		try{
		    int II=Integer.parseInt(args[0]);
		    int a=Integer.parseInt(args[1]);
		    int NN=Integer.parseInt(args[2]);
		    double [] means=new double[II];
		    for(int i=3;i<args.length;i++)
			means[i-3]=Integer.parseInt(args[i]);
		    RLikeNShopData sd= new RLikeNShopData(II,a,means,NN);
		    System.out.println(sd);
		}catch(Exception e){
			e.printStackTrace();
			System.err.println("Usage: java haifa.shopsim.RLikeNShopData <I> <a> <N> <I1,I2,...,II>");
		}
	}
}//end of class
