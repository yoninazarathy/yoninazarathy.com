package haifa.shopsim.lab;

import java.util.*;


/**A pareto generator with only the first, second and third moments.
 *@version 0.60
 */
public class Pareto3MomentsRandomTimeMaker extends ParetoRandomTimeMaker{
    public Pareto3MomentsRandomTimeMaker() {
		super(3.0);
    }
}