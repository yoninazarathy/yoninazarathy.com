package haifa.shopsim.lab;

import haifa.shopsim.*;

/**A size chooser that gives the Nr array {1,....,1}.
 *
 *@version 0.60
 */
public class DefaultProblemSizeChooser extends AbstractProblemSizeChooser{

    /** Creates new DefaultProblemSizeChooser */
    public DefaultProblemSizeChooser(ShopData shopData_) {
        super(shopData_);
        for(int r=0;r<Nr.length;r++)
            Nr[r]=1;//set all values of routes to 1
    }
}//END OF CLASSS