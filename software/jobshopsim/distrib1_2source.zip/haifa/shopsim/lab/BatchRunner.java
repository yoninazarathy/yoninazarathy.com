package haifa.shopsim.lab;

import java.io.*;

import haifa.shopsim.*;
import haifa.shopsim.fastkernel.*;
import haifa.shopsim.algorithms.*;

/**This class is run from the command line. It runs job shops and serializes the ShopStatistics Objects into files.
 These files may later either be view with the RichStatReader class or appended in the mathematicaShopRun format
to the some text file using the DataFileWriter class.
 Note that if the class is told to run with an outputfile named outToday, it will create the files outToday1, outToday2 etc.
 Each having a batch size of results. Be carefull when you use it.
 *@version 1.2
 */
public class BatchRunner  {

    /**The file name of the jbs file.  This is used by the RichShopStatistics.*/
    String jbsFileName;

    /**The current file that gets the output.*/
    String outputFileName;

/////////////////////////////////////////////////////////////////////////////////////
////////////The entities that are used by the shop//////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

    FastShopRun simulator;
    ShopAlgorithm shopAlgorithm;
    RandomTimeMaker randomTimeMaker;
    ProblemSizeChooser sizeChooser;
    ShopData shopData;
    RichStatisticsCollector statColl;

    /**The number of samples to be sampled on each size.*/
    int numSamples;

    /**The array of sizes that are to be sampled.*/
    int [] sizes;

    /**The batch size.*/
    static int batchSize;

    /** Creates new BatchRunner */
    public BatchRunner(ShopAlgorithm shopAlgorithm_,ShopData shopData_,
                                        RandomTimeMaker randomTimeMaker_,ProblemSizeChooser sizeChooser_,
                                        int numSamples_, int [] sizes_,
                                        String jbsFileName_,String outputFileName_)throws Exception {
        shopAlgorithm=shopAlgorithm_;
        shopData=shopData_;
        randomTimeMaker = randomTimeMaker_;
        sizeChooser=sizeChooser_;
        numSamples=numSamples_;
        sizes=sizes_;
        jbsFileName=jbsFileName_;
        outputFileName=outputFileName_;

        simulator = new FastShopRun(shopAlgorithm,shopData);

        simulator.setRandomTimeMaker(randomTimeMaker);
        simulator.setProblemSizeChooser(sizeChooser);
        shopAlgorithm.setShopStateObject(simulator);
        shopAlgorithm.setShopSimulationObject(simulator);
        shopAlgorithm.setShopData(shopData);

        statColl= new RichStatisticsCollector(	shopData,simulator,jbsFileName,
                                              	randomTimeMaker.getClass().getName(),
						shopAlgorithm.getClass().getName());
        simulator.addShopChangeListener(statColl);
    }//END OF METHOD

    protected void doIt()throws Exception{
        int counter=0;
        int k=0;
        ShopStatistics [] st= new ShopStatistics[batchSize];
        for(int i=0;i<sizes.length;i++){//loop on all shop sizes
            for(int j=0;j<numSamples;j++){
		if(sizeChooser instanceof ProportionalProblemSizeChooser)
                	((ProportionalProblemSizeChooser)sizeChooser).setN(sizes[i]);
                else if(sizeChooser instanceof WeissPropSizeChooser)
                    ((WeissPropSizeChooser)sizeChooser).setN(sizes[i]);
                //else we are dealing with a "large" shop and size choosing ain't needed
                simulator.go();
                st[k++]=statColl.getStats();
                counter++;
                if(counter%batchSize==0){
                    ObjectOutputStream oout=new ObjectOutputStream(new FileOutputStream(
									outputFileName+(counter/batchSize)));
                    for(k=0;k<st.length;k++)
                        oout.writeObject(st[k]);
                    oout.close();
                    k=0;
                }//end of if block of writing batch
            }//end of loop on all samples
        }//end of loop on all shop sizes

        ObjectOutputStream oout=new ObjectOutputStream(new FileOutputStream(//the file name
						                                	outputFileName+(counter/batchSize+1)));
        //write all of the objects
        for(int i=0;i<k;i++)
              oout.writeObject(st[i]);
                    oout.close();

    }//end of doIt() method


    /**Defines the parameters that are to be given at the command line.*/
    static final String USAGE=
	"java -server haifa.shopsim.lab.BatchRunner  -<i|l|p>"+
        "\n(for identical/large/proportional)"+
	"\nIn the case of -i or -p: "+
	"\n<jbs file> <outputfileprefix>  <batchSize> <SR|FIA|DWF|PRB|RJA|FBFS|LBFS> <0 | 0.25 | 1.0 | w | P3 | P2> <{n}> <{N1,N2,..}>"+
	"\nIn the case of -l: <I> <a> <Mean1,....,MeanI> <N> <outputfile> <batchSize> <alg(as above)> <RV (as above)> <n>"+
	"\nNote that in the case of '-l' the batchSize is ignored and set to 1";


   	/**Usage is as seen in USAGE */
    	public static void main(String [] args) throws Exception{
       		 if(args.length<8){
       		     System.err.println("Too few args.\n"+
       	             "The usage is:\n" + USAGE);
       		     System.exit(1);
       		 }

		if(args[0].equals("-i")){
			doIdentical(args);
		}else if(args[0].equals("-p")){
			doProp(args);
		}else if(args[0].equals("-l")){
			doLarge(args);
		}else{
			System.err.println("First arg may be -i (identical), -l (large) or -p (proportional)");
			System.exit(1);
		}
	}//end of main method




	public static void doIdentical(String [] args)throws Exception {

        	//HANDLE ARGUMENT: THE FILE NAME
        	FileReader fileReader;
        	ShopData dat= new FastShopDataFromJBSFile(fileReader =new FileReader(args[1]));
        	fileReader.close();


        	batchSize=Integer.parseInt(args[3]);


        	ProportionalProblemSizeChooser chooser=new ProportionalProblemSizeChooser(dat);
            	int [] p=new int[dat.getR()];
            	for(int i=0;i<p.length;i++)
                	p[i]=1;
            	chooser.setPr(p);


        	int n=Integer.parseInt(args[6]);

        	int N[] = new int[args.length-7];

        	for(int i=0;i<N.length;i++)
            		N[i]=Integer.parseInt(args[i+7]);

        	BatchRunner br = new BatchRunner(setAlgorithm(args[4]),dat,
						setRV(args[5]),chooser,n,N,args[1],args[2]);
        	br.doIt();

    	}//END OF METHOD


	public static void doProp(String [] args)throws Exception{
                System.out.println("starting proportional batch runner. (using WeissPropSizeChooser)");
        	//HANDLE ARGUMENT: THE FILE NAME
        	FileReader fileReader;
        	ShopData dat= new FastShopDataFromJBSFile(fileReader =new FileReader(args[1]));
        	fileReader.close();

        	batchSize=Integer.parseInt(args[3]);

        	WeissPropSizeChooser chooser=new WeissPropSizeChooser(dat);

        	int n=Integer.parseInt(args[6]);

        	int N[] = new int[args.length-7];

        	for(int i=0;i<N.length;i++)
            		N[i]=Integer.parseInt(args[i+7]);

        	BatchRunner br = new BatchRunner(setAlgorithm(args[4]),dat,
						setRV(args[5]),chooser,n,N,args[1],args[2]);
        	br.doIt();
	}//end of doProp

        /**Reads parameters accroding to "-l" specification and runs batch runner.*/
	public static void doLarge(String [] args) throws Exception{
		int II=Integer.parseInt(args[1]);
		int a = Integer.parseInt(args[2]);
		double [] means = new double[II];
		for(int i=0;i<II;i++){
			means[i]=Double.parseDouble(args[3+i]);
			//System.out.println("parsed for machine " + (i+1) + " mean value of " + means[i]);
		}
		int NN = Integer.parseInt(args[3+II]);



        	//localBatchSize=Integer.parseInt(args[5+II]);
        	batchSize=1;//stupid patch on problem

		//algorithm is in spot 7+II
		//rv is in spot 8+II

        	int n=Integer.parseInt(args[8+II]);
		int [] temp= new int[1];
		temp[0]=NN;


		for(int i=0;i<n;i++){
			RLikeNShopData dat =new RLikeNShopData(II,a,means,NN);
			//System.out.println("The generator shop data is :\n"+dat);
        	BatchRunner br = new BatchRunner(	setAlgorithm(args[6+II]),
							dat,setRV(args[7+II]),
							new DefaultProblemSizeChooser(dat),
							1,temp,"LargeR("+II+","+a+")",args[4+II]+"_"+i+"_");
        	br.doIt();
		}
	}//end of doLarge() method

        /**Returns a shop algorithm based on the argument.*/
	private static ShopAlgorithm setAlgorithm(String  arg){
        	ShopAlgorithm alg=null;
        	if(arg.equalsIgnoreCase("SR")){
            		alg=new SimpleRandomAlgorithm();
        	}else if(arg.equalsIgnoreCase("FIA")){
            		alg=new MakespanFIAalgorithm();
        	}else if(arg.equalsIgnoreCase("DWF")){
            		alg = new DWFluidAlgorithm();
        	}else if(arg.equalsIgnoreCase("PRB")){
            		alg= new SmartRandomAlgorithm();
                }else if(arg.equalsIgnoreCase("RJA")){
                    alg= new RandomJobAlgorithm();
        	}else if(arg.equalsIgnoreCase("FBFS")){
            		alg = new FBFSPriorityAlgorithm();
        	}else if(arg.equalsIgnoreCase("LBFS")){
            		alg =  new LBFSPriorityAlgorithm();
        	}else{
            		System.err.println("Unknown algorithm: " + arg);
            		System.exit(1);
        	}
		return alg;
	}//end of method

        /**Returns an RV object based on the argument.*/
	public static RandomTimeMaker setRV(String arg){
      		RandomTimeMaker rnd=null;
        	if(arg.equalsIgnoreCase("0")){
            		rnd = new DefaultRandomTimeMaker();
        	}else if(arg.equalsIgnoreCase("0.25")){
            		rnd= new NormalCV025TimeMaker();
        	}else if(arg.equalsIgnoreCase("1.0")){
            		rnd = new ExpRandomTimeMaker();
        	}else if(arg.equalsIgnoreCase("w")){
            		rnd = new WeibullHalfRandomTimeMaker();
        	}else if(arg.equalsIgnoreCase("P3")){
            		rnd = new Pareto3MomentsRandomTimeMaker();
        	}else if(arg.equalsIgnoreCase("P2")){
            		rnd = new Pareto2MomentsRandomTimeMaker();
        	}else{
            		System.err.println("Unknown random variable: " + arg);
            		System.exit(1);
        	}
		return rnd;
	}//END OF METHOD

}//END OF CLASS