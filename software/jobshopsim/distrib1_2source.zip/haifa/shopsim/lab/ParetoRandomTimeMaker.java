package haifa.shopsim.lab;

import java.util.*;


/**Allows generation of heavy-tail R.V's.  That is R.V's that do not have exponetial moments.  The paretto
distribution is used. The classes uses a pareto with paremeters alpha and mean which
sets the lamda
. With survival function (lamda/(lamda+x))^alpha.
 *@version 0.60*/
public class ParetoRandomTimeMaker extends AbstractRandomTimeMaker {

    protected double alpha;

    /**The negative inverse of alpha*/
    private final double negAlphaInv;

    /**Contstructs based on alpha parameter. */
    public ParetoRandomTimeMaker(double alpha_) {
		alpha=alpha_;
		negAlphaInv=-1/alpha;
    }//end of cot'r

    /** Returns a random pareto variable with mean.*/
    public double getTime(double mean) {
		double lamda=mean*(alpha-1);
		return lamda*(Math.pow(random.nextDouble(),negAlphaInv)-1);
    }
}//END OF CLASS