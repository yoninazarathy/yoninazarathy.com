package haifa.shopsim.lab;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**This class is a PrintWriter that prints the output to it's own window, it runs on it's own thread and uses a pipe to get the data.
 *@version 0.60
 */
public  class LogWindow extends PrintWriter implements Runnable{

    protected  JFrame frame;
    protected  JTextArea textArea;
    protected  Thread t;
    protected BufferedReader bufferedReader;
    
    /**Always give this co'transient a brand new PipedWriter.*/
    public LogWindow(PipedWriter stupidParam, String windowName,boolean visible) {
        super(stupidParam);
        try{
            bufferedReader  = new BufferedReader (new PipedReader(stupidParam));
            frame = new JFrame(windowName);
            frame.getContentPane().add(new JScrollPane(textArea = new JTextArea()));
            textArea.setEditable(false);
            frame.setSize(500,300);
            frame.addWindowListener(new WindowAdapter()
						{
							public void windowClosing(WindowEvent we)
							{
								frame.setVisible(false);
							}
				});
            frame.setVisible(visible);
        }catch(Exception e){
            System.err.println(e);
            e.printStackTrace();
        }
    }
    
    public void setVisible(boolean visible){
        frame.setVisible(true);
    }

    /**Startts Log Window*/
    public void activate(){
        t=new Thread(this);
        t.start();
    }
    
    public void destroy(){
        t.stop();
        frame.setVisible(false);
        frame.dispose();
    }
    
    public void run(){
        try{
        while(true){
            String line = bufferedReader.readLine();
            textArea.append(line+"\n");
            if(frame.isVisible())//if frame is visible scroll text all the way to last entry.
                textArea.setCaretPosition(textArea.getCaretPosition()+line.length());
        }
        } catch(IOException e){
          return;//leave thread because pipe is probably broken
        }catch(Exception e){
            System.err.println(e);
            e.printStackTrace();  
        }
    }//end of run()
}//END OF CLASS