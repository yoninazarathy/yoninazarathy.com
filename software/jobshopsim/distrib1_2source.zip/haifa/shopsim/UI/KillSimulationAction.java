package haifa.shopsim.UI;

import javax.swing.*;
import java.awt.event.*;

class KillSimulationAction extends AbstractAction implements UIStringConstants{
                MainGUI mainGUI;
		public KillSimulationAction(MainGUI mainGUI_){
			super("Kill Simulation");
                        mainGUI=mainGUI_;
		}

		public void actionPerformed(ActionEvent ae){
                        if(mainGUI.shopTraceMaker != null)
                            mainGUI.shopTraceMaker.kill();
                        mainGUI.fixLoadedState();
                        mainGUI.commandLabel.setText(SIMULATION_ABORTED_STRING);
		}
                
}//END OF INNER CLASS 