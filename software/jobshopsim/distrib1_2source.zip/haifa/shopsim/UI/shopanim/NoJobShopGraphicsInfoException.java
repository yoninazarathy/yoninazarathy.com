package haifa.shopsim.UI.shopanim;

/**Signifies that a .jbs file does not have information regarding graphics of the job shop.
 @version 1.1
 */
public class NoJobShopGraphicsInfoException extends Exception {
}