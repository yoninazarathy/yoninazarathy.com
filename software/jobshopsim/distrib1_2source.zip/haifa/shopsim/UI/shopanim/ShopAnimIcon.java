package haifa.shopsim.UI.shopanim;

import javax.swing.*;
import java.awt.*;
import java.util.*;

/**An icon that is to be drawn in the shop animation area.
 *@version 1.1
 */
public abstract class ShopAnimIcon implements javax.swing.Icon, ShopAnimConstants{
    protected int width;
    protected int height;
    protected static Random random=new Random();
    
    final static int JOB_CROSS_SIZE = 2;    
    
    /**May have values NORTH,EAST, SOUTH or WEST or NOT_SET.*/
    protected int orientation=NOT_SET; 

    public int getOrientation(){
      return orientation;  
    }
    
    public void setOrientation(int orientation_){
        orientation=orientation_;
    }
    
    public int getIconWidth() {
        return width;
    }
    
    public int getIconHeight() {
        return height;
    }
    
    public void setIconWidth(int width_){
        width=width_;
    }
    
    public void setIconHeight(int height_){
        height=height_;
    }
    
    /**Should be implemented by the baseclasses.  Must not paint outside of the range (x,y)  --  (x+width-1,y+height-1).*/
    public abstract void paintIcon(Component p1,Graphics p2,int x,int y);
    
        
    protected  void drawCross(int xx,int yy,Graphics g){
            //g.drawLine(xx-JOB_CROSS_SIZE,yy,xx+JOB_CROSS_SIZE,yy);
            //g.drawLine(xx,yy-JOB_CROSS_SIZE,xx,yy+JOB_CROSS_SIZE);        
            g.setColor(Color.magenta);
            g.fillOval(xx-JOB_CROSS_SIZE,yy-JOB_CROSS_SIZE,JOB_CROSS_SIZE*2,JOB_CROSS_SIZE*2);
    }
    
    protected Point getRandomPoint(int xx,int yy,int width,int height){
        int x=random.nextInt(width)+xx;
        int y=random.nextInt(height)+yy;
        return new Point(x,y);
    }
}//END OF ABSTRACT CLASS