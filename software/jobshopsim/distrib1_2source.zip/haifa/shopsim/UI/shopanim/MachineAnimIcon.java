package haifa.shopsim.UI.shopanim;

import javax.swing.*;
import java.awt.*;


/**Icon representing machine, responsible for drawing machine, buffers and jobs.
 *@version 1.1
 */
public   class MachineAnimIcon extends ShopAnimIcon{
    /**The number of buffers/queues/classes that this machine supports.*/
    protected int numBuffers;
    
    protected int machineNumber;
    
    /**Stores the angle (A multiple of 30 degrees) at which the each of the buffers is drawn.*/
    protected int [] angles;
    
    /**Says how many jobs in each buffer.  If a buffer is processing, the job is still counted.*/
    protected int [] queueSizes;
    
    /**The index of the processing buffer (0,...,numBuffers-1) or -1 if machine is idle.*/
    protected int processingBuffer;

    protected int circleWidth;
    protected int circleHeight;
    
    final static int SIZE_AROUND_CIRCLE=20;
    final static int BUFFER_RECT_HEIGHT=12;
    final static int BUFFER_ANGLE_SPREAD=11;
    final static int STEP_START_Q=10;
    final static int STEP_Q=5;
    
    /**If there are more jobs than that in Q then they are not drawn.*/
    final static int MAX_JOBS_TO_DRAW=100;
    
    final static Color IDLE_CIRCLE_COLOR=Color.blue;
    final static Color WORKING_CIRCLE_COLOR=Color.red;
    final static Color BUFFER_COLOR=Color.yellow;
    
    public MachineAnimIcon(){
    }
    
    /** Creates new MachineAnimIcon with numBuffers_ buffers.  The angles are set to  0,30,60,90,120,...,30*(numBuffers-1) */
    public MachineAnimIcon(int numBuffers_) {
        setNumBuffers(numBuffers_);
    }
    
    /** Creates new MachineAnimIcon with numBuffers_ buffers. The angles are set from the angles array. */
    public MachineAnimIcon(int numBuffers_,int [] angles_) {
        if(angles_.length != numBuffers)
            throw new IllegalArgumentException("numBuffers should equal angles_.length");
        setNumBuffers(numBuffers_);
        setAngles(angles_);
    }
    
    public void setMachineNumber(int machineNumber_){
        machineNumber=machineNumber_;
    }
    
    
    /**Sets the number of buffers. It also resets all queues to 0, and causes machine to be not processing.
     The angles are set to  0,30,60,90,120,...,30*(numBuffers-1).*/
    public void setNumBuffers(int numBuffers_){
      numBuffers=numBuffers_;
      queueSizes=new int[numBuffers];
      processingBuffer=-1;
      angles=new int[numBuffers];
      for(int i=0;i<numBuffers;i++){
            angles[i]=i*30;
            queueSizes[i]=0;
      }
    }
    
    public void setAngles(int [] angles_){
      angles=angles_;  
    }
    
    public void setIconWidth(int width_){
        super.setIconWidth(width_);
        circleWidth=width-2*SIZE_AROUND_CIRCLE;
        
    }
    
    public void setIconHeight(int height_){
        super.setIconHeight(height_);
        circleHeight=height-2*SIZE_AROUND_CIRCLE;
    }
    
    public void setQueueSizes(int [] queueSizes_){
        queueSizes=queueSizes_;
    }
    
    public void setQueueSize(int queueIndex, int numInQ){
        queueSizes[queueIndex]=numInQ;
    }
    
    /**Set the buffer which is processing.  Pass -1 if machine is idle.*/
    public void setProcessingBuffer(int buffer){
      this.processingBuffer=buffer;  
    }
    
    public Point getOperationPoint(int bufferIndex,int x, int y){
        float angle=(3.14f/180)*(90-angles[bufferIndex]);//make it like a math angle   and in radians

         int circleX,circleY;
        circleX=x+(width-circleWidth)/2;
        circleY=y+(height-circleHeight)/2;
        int r = circleWidth/2;
        int centerX=circleX+r;
        int centerY=circleY+r;

        float w,h;
        w=(float)(Math.cos(angle))*r;
        h=(float)(Math.sin(angle))*r;
        h=-h;

        int delta=4;
        
        float  w1,h1;
        h1=h*(1+delta/r);
        w1=w*(1+delta/r);
        return new Point((int)(centerX+w1),(int)(centerY+h1));
    }
    
    public void paintIcon(Component comp,Graphics g,int x,int y) {
        //g.setColor(Color.black);
        //g.drawRect(x,y,width,height);//these two lines are good for debugging
        
        int circleX,circleY;
        circleX=x+(width-circleWidth)/2;
        circleY=y+(height-circleHeight)/2;
        if(this.processingBuffer==-1)
            g.setColor(IDLE_CIRCLE_COLOR);
        else
            g.setColor(WORKING_CIRCLE_COLOR);
        g.fillOval(circleX,circleY,circleWidth,circleHeight);
        //System.out.println("In MachineAnimIcon.paintIcon(): The current thread: " + Thread.currentThread());
        
          //draw all buffers
        int radius = circleWidth/2;
        int centerX=circleX+radius;
        int centerY=circleY+radius;
        for(int i=0;i<angles.length;i++)
            drawBuffer(centerX,centerY,radius,i,g);
        
            g.setColor(Color.white);
            g.setFont(new Font("Serif",Font.BOLD,12));
            g.drawString(Integer.toString(machineNumber),centerX-4,centerY+4);
    }//END OF PAINT ICON() METHOD
    
    private void drawBuffer(int x, int y, int r,int bufferIndex,Graphics g){
        float angle=(3.14f/180)*(90-angles[bufferIndex]);//make it like a math angle   and in radians
        float angle1=angle-BUFFER_ANGLE_SPREAD*(3.14f/180);
        float angle2=angle+BUFFER_ANGLE_SPREAD*(3.14f/180);
        
        float w,h;
        w=(float)(Math.cos(angle))*r;
        h=(float)(Math.sin(angle))*r;
        
        h=-h;
        
        float h1,h2;
        h1=(float)(Math.sin(angle1))*r;
        h2=(float)(Math.sin(angle2))*r;
        
        h1=-h1;h2=-h2;
        
        float w1,w2;
        w1=(float)(Math.cos(angle1))*r;
        w2=(float)(Math.cos(angle2))*r;
        
        
        float delta=((float)BUFFER_RECT_HEIGHT)/2;
        
        float hm1s,hm1l,hm2s,hm2l;
        hm1s=h1*(1-delta/r);
        hm1l=h1*(1+delta/r);
        hm2s=h2*(1-delta/r);
        hm2l=h2*(1+delta/r);

        float wm1s,wm1l,wm2s,wm2l;
        wm1s=w1*(1-delta/r);
        wm1l=w1*(1+delta/r);
        wm2s=w2*(1-delta/r);
        wm2l=w2*(1+delta/r);
        
        int [] xpoints = new int[4];
        int [] ypoints = new int[4];
        
        xpoints[0]=x+(int)wm1s;
        xpoints[1]=x+(int)wm1l;
        xpoints[2]=x+(int)wm2l;
        xpoints[3]=x+(int)wm2s;
        
        ypoints[0]=y+(int)hm1s;
        ypoints[1]=y+(int)hm1l;
        ypoints[2]=y+(int)hm2l;
        ypoints[3]=y+(int)hm2s;
        
        g.setColor(Color.yellow);
        g.fillPolygon(xpoints,ypoints,4);
        
        g.setColor(Color.black);
        
        int numInQ=queueSizes[bufferIndex];
        if(processingBuffer==bufferIndex){
            numInQ--;
            int xx=x+(int)w;
            int yy=y+(int)h;
            drawCross(xx,yy,g);
        }
        
        if(numInQ>0){
            float wm=w*(1+(float)STEP_START_Q/r);
            float hm=h*(1+(float)STEP_START_Q/r);
            if(numInQ <= MAX_JOBS_TO_DRAW){
                drawCross(x+(int)wm,y+(int)hm,g);
                for(int i=2;i<=numInQ ;i++){
                             wm=w*(1+(float)(STEP_START_Q+(i-1)*STEP_Q)/r);
                             hm=h*(1+(float)(STEP_START_Q+(i-1)*STEP_Q)/r);
                             drawCross(x+(int)wm,y+(int)hm,g);
                }
            }else{
                drawCross(x+(int)wm,y+(int)hm,g);
                for(int i=2;i<=MAX_JOBS_TO_DRAW;i++){
                             wm=w*(1+(float)(STEP_START_Q+(i-1)*STEP_Q)/r);
                             hm=h*(1+(float)(STEP_START_Q+(i-1)*STEP_Q)/r);
                             drawCross(x+(int)wm,y+(int)hm,g);                
                }
            }
        }//end of drawing of jobs in queue
    }//END OF METHOD
}//END OF CLASS
