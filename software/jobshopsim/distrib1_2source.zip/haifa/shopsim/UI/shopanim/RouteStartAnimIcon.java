package haifa.shopsim.UI.shopanim;

import javax.swing.*;
import java.awt.*;

/**A drawing representin a route start.
 *@version 1.1
 */
public class RouteStartAnimIcon extends RouteAnimIcon{

    int triCornersX[] = new int[3];
    int triCornersY[] = new int[3];
    final static int DIST_FROM_SIDE=10;
    
    
    /** Creates new RouteStartAnimIcon */
    public RouteStartAnimIcon(int routeNumber_,int orientation_) {
        super(routeNumber_,orientation_);
    }

    public void setOrientation(int orientation_){
      orientation=orientation_;
      reCalcLineTipPoint();
    }  
    
    protected void reCalcLineTipPoint(){
      if(orientation==NORTH){
          lineTipPoint=new Point(width/2,height-DIST_FROM_SIDE);
      }else if(orientation==EAST){
          lineTipPoint=new Point(DIST_FROM_SIDE,height/2);          
      }else if(orientation==SOUTH){
          lineTipPoint=new Point(width/2,DIST_FROM_SIDE);                    
      }else if(orientation==WEST){
                    lineTipPoint=new Point(width-DIST_FROM_SIDE,height/2);                    
      }        
    }

    
    
    public void paintIcon(Component comp,Graphics g,int x,int y) {
        g.setColor(Color.black);
        //g.drawRect(x,y,width,height);//good for debugging
        calcTriCorners(x,y);
        g.setColor(Color.orange);
        g.fillPolygon(triCornersX,triCornersY,3);//draw the triangle
        
        g.setColor(Color.white);
        g.drawString(Integer.toString(routeNumber),x+width/2,y+width/2);
        g.setColor(Color.black);
        Point lineTip=getLineTipPoint(x,y);
        g.fillOval(lineTip.x-ROUTE_TIP_RADIUS,lineTip.y-ROUTE_TIP_RADIUS,ROUTE_TIP_RADIUS*2,ROUTE_TIP_RADIUS*2);
    }
 
   
    private void calcTriCorners(int x, int y){
      if(orientation==NORTH){
          triCornersX[0]=x+DIST_FROM_SIDE;
          triCornersY[0]=y+DIST_FROM_SIDE;
          triCornersX[1]=x+width-DIST_FROM_SIDE;
          triCornersY[1]=y+DIST_FROM_SIDE;
          triCornersX[2]=x+width/2;
          triCornersY[2]=y+height-DIST_FROM_SIDE;
      }else if(orientation==EAST){
          triCornersX[0]=x+width-DIST_FROM_SIDE;
          triCornersY[0]=y+DIST_FROM_SIDE;
          triCornersX[1]=x+width-DIST_FROM_SIDE;
          triCornersY[1]=y+height-DIST_FROM_SIDE;
          triCornersX[2]=x+DIST_FROM_SIDE;
          triCornersY[2]=y+height/2;
      }else if(orientation==SOUTH){
          triCornersX[0]=x+DIST_FROM_SIDE;
          triCornersY[0]=y+height-DIST_FROM_SIDE;
          triCornersX[1]=x+width-DIST_FROM_SIDE;
          triCornersY[1]=y+height-DIST_FROM_SIDE;
          triCornersX[2]=x+width/2;
          triCornersY[2]=y+DIST_FROM_SIDE;
      }else if(orientation==WEST){
          triCornersX[0]=x+DIST_FROM_SIDE;
          triCornersY[0]=y+DIST_FROM_SIDE;
          triCornersX[1]=x+DIST_FROM_SIDE;
          triCornersY[1]=y+height-DIST_FROM_SIDE;
          triCornersX[2]=x+width-DIST_FROM_SIDE;
          triCornersY[2]=y+height/2;
          
      }else{
            //do what???
      }
    }    
    
}//END OF CLASS
