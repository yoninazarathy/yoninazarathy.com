package haifa.shopsim.UI.shopanim;

import java.awt.*;

/**A drawing representing a route start or route end.
 *@version 1.1
 */
public abstract class RouteAnimIcon extends ShopAnimIcon{

    final static int ROUTE_TIP_RADIUS=5;
    
    /**Signifies the location of the lineTip, relative to the top left corner of the icon.*/
    protected Point lineTipPoint;
    
    protected int numJobsInIcon;
    
    protected  int routeNumber;

    
    public RouteAnimIcon(int routeNumber_){
        routeNumber=routeNumber_;
        setOrientation(NOT_SET);
    }
    
    public RouteAnimIcon(int routeNumber_, int orientation_){
        routeNumber=routeNumber_;
        setOrientation(orientation_);
    }
    
    public void setNumJobsInIcon(int numJobsInIcon_){
        numJobsInIcon=numJobsInIcon_;
    }
    
    public void setIconWidth(int width_){
        width=width_;
        reCalcLineTipPoint();
    }
    
    public void setIconHeight(int height_){
        height=height_;
        reCalcLineTipPoint();
    }    
    
    /**Returns the point at which a line (representing the route) is to connect.*/
 
    public Point getLineTipPoint(int x,int y){
        return new Point(lineTipPoint.x+x,lineTipPoint.y+y);
    }
    
    protected abstract void reCalcLineTipPoint();
}//END OF ABSTRACT CLASS
