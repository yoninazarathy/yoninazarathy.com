package haifa.shopsim.UI.shopanim;

import javax.swing.*;
import java.awt.*;
import java.util.*;

/**A drawing represeting a route end.
 *@version 1.1
 */
public class RouteEndAnimIcon extends RouteAnimIcon{

    final static float FRACTION_OF_DIM=.6f;
    final static int BOX_CURVE=8;
    final static int HEIGHT_MARGIN=10;
    final static int WIDTH_MARGIN=10;
    final static int V_DIST_BETWEEN_JOBS=5;
    final static int H_DIST_BETWEEN_JOBS=5;
    
    private int widthOfRect;
    private int heightOfRect;
    
    /**stores Point objects relative to the top left corner of the roundRect that is drawn.*/
    Collection pointsWithJobs;
    
    /** Creates new RouteStartAnimIcon */
    public RouteEndAnimIcon(int routeNumber_,int orientation_) {
        super(routeNumber_,orientation_);
        pointsWithJobs=new ArrayList();
    }
       
    public void setIconWidth(int width_){
        width=width_;
        widthOfRect=(int)(FRACTION_OF_DIM*width);
        reCalcLineTipPoint();
    }
    
    public void setIconHeight(int height_){
        height=height_;
        heightOfRect=(int)(FRACTION_OF_DIM*height);
        reCalcLineTipPoint();
    }
    
     public void setNumJobsInIcon(int numJobsInIcon_){
        int diff=numJobsInIcon_-numJobsInIcon;
        numJobsInIcon=numJobsInIcon_;
        for(int i=0;i<diff;i++){
            pointsWithJobs.add(getRandomPoint(WIDTH_MARGIN,HEIGHT_MARGIN,
                                                        widthOfRect-2*WIDTH_MARGIN,heightOfRect-2*HEIGHT_MARGIN));
        }
    }//END OF METHOD    

    public void paintIcon(Component comp,Graphics g,int x,int y) {
        g.setColor(Color.black);
        int x1,y1;
        x1=x+(width-widthOfRect)/2;
        y1=y+(height-heightOfRect)/2;
        g.setColor(Color.orange);
        g.fillRoundRect(x1,y1,widthOfRect,heightOfRect, BOX_CURVE,BOX_CURVE);
        
        synchronized(pointsWithJobs){
            Iterator it = pointsWithJobs.iterator();
            while(it.hasNext()){
                Point point =(Point)it.next();
                int x2,y2;
                x2=point.x+x1;
                y2=point.y+y1;
                g.setColor(Color.black);
                drawCross(x2,y2,g);
            }
        }
        g.setColor(Color.black);
        Point lineTip=getLineTipPoint(x,y);
        g.fillOval(lineTip.x-ROUTE_TIP_RADIUS,lineTip.y-ROUTE_TIP_RADIUS,ROUTE_TIP_RADIUS*2,ROUTE_TIP_RADIUS*2);

    }//END OF PAINT ICON METHOD
 
        
    protected void reCalcLineTipPoint(){
      if(orientation==NORTH){
          lineTipPoint=new Point(width/2,height-(height-heightOfRect)/2);
      }else if(orientation==EAST){
          lineTipPoint=new Point((width-widthOfRect)/2,height/2);          
      }else if(orientation==SOUTH){
          lineTipPoint=new Point(width/2,(height-heightOfRect)/2);                    
      }else if(orientation==WEST){
                    lineTipPoint=new Point(width-(width-widthOfRect)/2,height/2);                    
      }            
    }
}//END OF CLASS