package haifa.shopsim.UI.shopanim;

/**Constants for the ShopAnimation, determine the speicfication of the size of the grid.
 *Currently allows upt to 25 machines but only 10 routes.
*@version 1.1
 */
public interface ShopAnimConstants {
    
    final static int NUM_MACHINE_SPOTS_HEIGHT =5;
    final static int NUM_MACHINE_SPOTS_WIDTH=5;

    final static int NORTH=0;
    final static int EAST=1;
    final static int SOUTH=2;
    final static int WEST=3;
    
    final static int NOT_SET=-1;
}