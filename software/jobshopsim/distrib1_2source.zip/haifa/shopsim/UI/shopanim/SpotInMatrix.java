package haifa.shopsim.UI.shopanim;

/**Simplify an (i,j) coordinate in a matrix.
 *@version 1.1*/
class SpotInMatrix extends Object {
       SpotInMatrix(int ii_,int jj_){
            ii=ii_;
            jj=jj_;
        }
        int ii;
        int jj;
}