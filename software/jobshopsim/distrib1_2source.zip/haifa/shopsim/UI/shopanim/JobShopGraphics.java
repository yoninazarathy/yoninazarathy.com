package haifa.shopsim.UI.shopanim;

import haifa.shopsim.*;

import java.io.*;
import java.util.*;

/**Represents graphics information as read from a .jbs file.
 *@version 1.1
 */
public class JobShopGraphics implements ShopAnimConstants {

    protected int numMachines;
    
    protected HashMap [] locationsMaps;
    protected HashMap spotMap;
    int routeStartsSides [];
    int routeStartsIndexes [];
    int routeEndsSides [];
    int routeEndsIndexes[];

    /** Creates new JobShopGraphics  based on a reader.  Uses the shopData.*/
    public JobShopGraphics(Reader reader_,ShopData shopData) 
    throws NoJobShopGraphicsInfoException,JobShopFileFormatException {
		
                locationsMaps = new HashMap[shopData.getI()];
                for(int i=0;i<shopData.getI();i++)
                    locationsMaps[i] = new HashMap();
                
                spotMap = new HashMap();
                routeStartsSides= new int[shopData.getR()];
                routeStartsIndexes= new int[shopData.getR()];
                routeEndsSides= new int[shopData.getR()];
                routeEndsIndexes= new int[shopData.getR()];
                
        
                StreamTokenizer st = new StreamTokenizer(
								new BufferedReader(reader_));
		st.commentChar('#');//set comment character
try{//wait for IOExceptions
    
        while(true){//loop untill finding the token: Graphics
                    st.nextToken();
                    if(st.ttype==st.TT_EOF)//if never met the token: Graphics
                            throw new NoJobShopGraphicsInfoException();

                    if(st.ttype==st.TT_WORD)
                        if(st.sval.equalsIgnoreCase("Graphics")){
                                break;//bingo 
                        }
        }//end of while loop
        
        //START READING GRAPHICS FROM HERE
		for(int i=0;i<shopData.getI();i++){//loop on all machines
			/*Read "Machine" string*/
			if(st.nextToken() != StreamTokenizer.TT_WORD  ||
                        !st.sval.equalsIgnoreCase("Machine")){
				throw new JobShopFileFormatException();
                        }

			/*Read "Machine" number*/
			if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
			int mnum=(int)st.nval;
                        
                        //read vertical index of machine
                        if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
                        int vindex=(int)st.nval;
                        
                        //read horizontal index of machine
                        if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
                        int hindex=(int)st.nval;

                        spotMap.put(new Integer(mnum),new SpotInMatrix(vindex,hindex));
                        
                        int numOps=shopData.getSizeCi(mnum);
                        for(int o=0;o<numOps;o++){//loop on all operations of machine
                            //read route number of operation
                            if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
                            int route=(int)st.nval;
                            
                            //read step number of operation
                            if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
                            int step=(int)st.nval;

                            //read the degrees for the operation
                            if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
                            int degrees=(int)st.nval;
                            
                            locationsMaps[mnum-1].put(new Operation(route,step),new Integer(degrees));
                        }//end of loop on all operations of machine i
                }//end of loop on all machines

                int numRoutes = shopData.getR();
                for(int r=0;r<numRoutes;r++){
			/*Read "Route" string*/
			if(st.nextToken() != StreamTokenizer.TT_WORD  ||
                        !st.sval.equalsIgnoreCase("Route")){
				throw new JobShopFileFormatException();
                        }

			/*Read "Route" number*/
			if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
			int rnum=(int)st.nval-1;                    
                    
                        /*Read "EAST/WEST/NORTH/SOUTH" string for route start*/
			if(st.nextToken() != StreamTokenizer.TT_WORD)
				throw new JobShopFileFormatException();
                        if(st.sval.equalsIgnoreCase("NORTH"))
                            routeStartsSides[rnum]=NORTH;
                        else if(st.sval.equalsIgnoreCase("EAST")) 
                            routeStartsSides[rnum]=EAST;
                        else if(st.sval.equalsIgnoreCase("WEST")) 
                            routeStartsSides[rnum]=WEST;
                        else if(st.sval.equalsIgnoreCase("SOUTH")) 
                            routeStartsSides[rnum]=SOUTH;
                        
                        /*Read index number for route start*/
			if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
			routeStartsIndexes[rnum]=(int)st.nval;

                 
                        /*Read "EAST/WEST/NORTH/SOUTH" string for route end*/
			if(st.nextToken() != StreamTokenizer.TT_WORD)
				throw new JobShopFileFormatException();
                        if(st.sval.equalsIgnoreCase("NORTH"))
                            routeEndsSides[rnum]=NORTH;
                        else if(st.sval.equalsIgnoreCase("EAST")) 
                            routeEndsSides[rnum]=EAST;
                        else if(st.sval.equalsIgnoreCase("WEST")) 
                            routeEndsSides[rnum]=WEST;
                        else if(st.sval.equalsIgnoreCase("SOUTH")) 
                            routeEndsSides[rnum]=SOUTH;
                        
                        /*Read index number for route end*/
			if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
			routeEndsIndexes[rnum]=(int)st.nval;                        
                }
        
}catch(IOException e){
    e.printStackTrace();
}catch(NoJobShopGraphicsInfoException e){
    throw e;
}
    }//END OF COT'R
       

    

    SpotInMatrix getMachineSpot(int machineNumber){
        return (SpotInMatrix)spotMap.get(new Integer(machineNumber));
    }
    
    /**Returns a map where the keys are operation objects and the values are degrees(0,30,60,....,330) in Integer objects.*/
    Map getMachineBuffersLocations(int machineNumber){
        return locationsMaps[machineNumber-1];
    }//END OF METHOD
    
    /**Returns the side (NORTH,EAST, SOUTH or WEST) of the routeNumber's start or end. If startOrEnd==0 returns start,
     else returns end.*/
    int getRouteSide(int routeNumber, int startOrEnd){
        if(startOrEnd==0)
            return routeStartsSides[routeNumber-1];
        else
            return routeEndsSides[routeNumber-1];
    }
       
    /**Returns the index of the routeNumber's start or end. If startOrEnd==0 returns start, else returns end.*/
    int getRouteIndex(int routeNumber, int startOrEnd){
         if(startOrEnd==0)
            return routeStartsIndexes[routeNumber-1];
        else
            return routeEndsIndexes[routeNumber-1];
    }
}//END OF CLASS