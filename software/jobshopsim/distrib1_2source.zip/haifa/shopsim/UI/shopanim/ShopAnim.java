package haifa.shopsim.UI.shopanim;

import haifa.shopsim.*;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/**A graphical view of a Job Shop.  Gets ShopChangeEvents but does not use the information in them.  It rather
 *uses a refrence to a ShopState object for this purpuse.
 @version 1.1
 */
public class ShopAnim extends JPanel implements ShopAnimConstants, ShopChangeListener{

    /**A reference to the the object that stores the graphics information of the job shop.*/
    protected JobShopGraphics jobShopGraphics;
    
    /**A reference to the object that stores the information of the job shop.*/
    protected ShopData shopData;
    
    /**A reference to the shopstate object.*/
    protected ShopState shopState;
    
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////DRAWING INFORMATION//////////////////////////////////////////////////    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
    
    /**A matrix of refernces to Machine Icons.  The references may either be null or lead to some icon.*/
    protected MachineAnimIcon [][] machines;
    
    /**References to route tip icons.  This array of arrays is composed of NORTH,SOUTH,EAST,WEST.*/
    protected RouteAnimIcon [][] routeTips;
    
    Point [][] routeTipsCoords;
    
    Point [][] machineCoords;
    
    /**Maps machine indexes (Integer objects) to MachineAnimIcon objects.*/
    HashMap machinesMap;
    
    HashMap machinesSpotMap;
    
    /**Maps each buffer to an index (Integer). The index is used by MachineAnimIcons. This means that the keys, buffers of the type
     (r,o) match values which are Integers 0,1,2. The meaning of the integers is the values that the machine icons use to reference the queues.*/
    HashMap bufferIndexesMap;
    
    /**Maps route indexs (Integer) to (Integer) objects.*/
    HashMap routeStartsIndexesMap;
    
    /**Maps route indexs (Integer) to (Integer) objects.*/
    HashMap routeEndsIndexesMap;

    /**Maps route indexs (Integer) to (Integer) objects. where the values are EAST/WEST/NORTH/SOUTH*/
    HashMap routeStartsSidesMap;
    
    /**Maps route indexs (Integer) to (Integer) objects. where the values are EAST/WEST/NORTH/SOUTH*/
    HashMap routeEndsSidesMap;
    
    /**An array that specifies at each moment, which routes are to be drawn.*/
    boolean [] routesToView;
    
    /**An array that specifies at each moment, which machines are to be drawn.*/
    boolean [] machinesToView;
    
    JCheckBox [] machinesCheckBoxes;
    JCheckBox [] routesCheckBoxes;
    
    
    
    private int iconWidth;
    private int iconHeight;
    private int firstStreetWidth;
    private int firstStreetHeight;

    protected final static int DRAWING_WIDTH=700;
    protected final static int DRAWING_HEIGHT=700;
    
    protected final static int STREET_WIDTH=4;
    protected final static int STREET_HEIGHT=4;
    
    protected  int totalStreetWidth=(NUM_MACHINE_SPOTS_WIDTH+3)*STREET_WIDTH;    
    protected  int totalStreetHeight=(NUM_MACHINE_SPOTS_HEIGHT+3)*STREET_HEIGHT;
    //protected  int TOTAL_STREET_WIDTH=(NUM_MACHINE_SPOTS_WIDTH+3)*STREET_WIDTH;
    //protected  int TOTAL_STREET_HEIGHT=(NUM_MACHINE_SPOTS_HEIGHT+3)*STREET_HEIGHT;
    
///////////////////////////////////////////////////////////////////////////////////
////////////////////////GUI COMPONENTS//////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
    /*The panel on which the drawing of the job shop occurs.*/
    private JPanel drawingPanel;
    
    /**The panel on which there are two panels, one for machines and one for routes whole routes.*/
    private JPanel routeChoosePanel;
    
    private JPanel wholeRoutesPanel;
    private JPanel machinesPanel;
    private JPanel allNonePanel;
    
    private JButton allButton;
    private JButton noneButton;
///////////////////////////////////////////////////////////////////////////////////
////////////////////////CONSTRUCTORS////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
    
    /** Creates new ShopAnim */
    public ShopAnim(ShopData shopData_,JobShopGraphics jobShopGraphics_) {
        shopData = shopData_;
        jobShopGraphics=jobShopGraphics_;
        setUpDataStructures();
        setUpGUI();
    }//END OF COT'R
    
   
    /**Sets up all of the GUI components.*/
    private void setUpGUI(){
        setLayout(new BorderLayout());
        drawingPanel=new JPanel(new FlowLayout());
        drawingPanel.setBackground(Color.cyan);
        drawingPanel.setOpaque(true);
        drawingPanel.setPreferredSize(new Dimension(DRAWING_WIDTH,DRAWING_HEIGHT));
        drawingPanel.setMaximumSize(new Dimension(DRAWING_WIDTH,DRAWING_HEIGHT));
        drawingPanel.setMinimumSize(new Dimension(DRAWING_WIDTH,DRAWING_HEIGHT));
        drawingPanel.setMaximumSize(new Dimension(DRAWING_WIDTH,DRAWING_HEIGHT));
        JScrollPane sp=new JScrollPane(drawingPanel);
        add(sp,BorderLayout.CENTER);
        
        setMinimumSize(new Dimension(1,15+9*shopData.getR()));
        
        routeChoosePanel=new JPanel();
        wholeRoutesPanel = new JPanel();
        wholeRoutesPanel.setLayout(new GridLayout(shopData.getR(),1));
       
        //wholeRoutesPanel.setMinimumSize(new Dimension(30,20+12*shopData.getR()));
        
        
        machinesPanel= new JPanel();
        machinesPanel.setLayout(new GridLayout(shopData.getI(),1));
        
        machinesCheckBoxes=new JCheckBox[shopData.getI()];
        for(int i=1;i<=shopData.getI();i++)
            machinesPanel.add(machinesCheckBoxes[i-1] = new MachineCheckBox(i));
        
        routesCheckBoxes = new JCheckBox[shopData.getR()];
        for(int r=1;r<=shopData.getR();r++)
            wholeRoutesPanel.add(routesCheckBoxes[r-1] =new RouteCheckBox(r));
        
        allNonePanel=new JPanel(new GridLayout(1,2,5,5));
        allNonePanel.add(allButton=new JButton("All"));
        allNonePanel.add(noneButton=new JButton("None"));
        routeChoosePanel.setLayout(new BorderLayout());
        routeChoosePanel.add(wholeRoutesPanel,BorderLayout.WEST);
        routeChoosePanel.add(machinesPanel,BorderLayout.EAST);
        routeChoosePanel.add(allNonePanel,BorderLayout.SOUTH);
        routeChoosePanel.add(new JLabel("View:",SwingConstants.CENTER),BorderLayout.NORTH);
        
        allButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                for(int i=0;i<machinesToView.length;i++){
                  machinesToView[i]=true;  
                  machinesCheckBoxes[i].setSelected(true);
                }
                for(int i=0;i<routesToView.length;i++){
                  routesToView[i]=true;  
                  routesCheckBoxes[i].setSelected(true);
                }
                            ShopAnim.this.repaint();
            }
        });
        
        noneButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                for(int i=0;i<machinesToView.length;i++){
                  machinesToView[i]=false;  
                  machinesCheckBoxes[i].setSelected(false);
                }
                for(int i=0;i<routesToView.length;i++){
                  routesToView[i]=false;  
                  routesCheckBoxes[i].setSelected(false);
                }
                            ShopAnim.this.repaint();
            }
        });

    }
    
    /**sets up all of the datastrucutures and allocates Icons. Bases data on the shopData and jobShopGraphics.*/
    private void setUpDataStructures(){
        
        //SET UP ARRAYS THAT HOLD Icons with nulls.
        machines = new MachineAnimIcon[NUM_MACHINE_SPOTS_HEIGHT][NUM_MACHINE_SPOTS_WIDTH];
        machineCoords = new Point[NUM_MACHINE_SPOTS_HEIGHT][NUM_MACHINE_SPOTS_WIDTH];
        
        routeTips = new RouteAnimIcon[4][];//4 for NORTH,SOUTH,EAST and WEST
        routeTipsCoords = new Point[4][];
        
        routeTips[NORTH]=new RouteAnimIcon[NUM_MACHINE_SPOTS_WIDTH];
        routeTips[SOUTH]=new RouteAnimIcon[NUM_MACHINE_SPOTS_WIDTH];
        routeTips[EAST]=new RouteAnimIcon[NUM_MACHINE_SPOTS_HEIGHT];
        routeTips[WEST]=new RouteAnimIcon[NUM_MACHINE_SPOTS_HEIGHT];

        routeTipsCoords[NORTH]=new Point[NUM_MACHINE_SPOTS_WIDTH];
        routeTipsCoords[SOUTH]=new Point[NUM_MACHINE_SPOTS_WIDTH];
        routeTipsCoords[EAST]=new Point[NUM_MACHINE_SPOTS_HEIGHT];
        routeTipsCoords[WEST]=new Point[NUM_MACHINE_SPOTS_HEIGHT];
        
        routesToView = new boolean[shopData.getR()];
        machinesToView = new boolean[shopData.getI()];
        
        int numMachines=shopData.getI();
        machinesMap=new HashMap(numMachines);
        machinesSpotMap = new HashMap(numMachines);
        bufferIndexesMap=new HashMap(shopData.getK());
        for(int i=1;i<=numMachines;i++){//loop on all machines.
          MachineAnimIcon theMachineIcon=new MachineAnimIcon();
          theMachineIcon.setMachineNumber(i);
          SpotInMatrix spot=jobShopGraphics.getMachineSpot(i);
          machinesSpotMap.put(new Integer(i),spot);
          machines[spot.ii-1][spot.jj-1]=theMachineIcon;//put icon ref in arrays that are used for display
          machinesMap.put(new Integer(i),theMachineIcon);//put icon ref in map for finding it based on machine num
          
          //NOW SET UP THE OPERATIONS OF MACHINE i
         java.util.List list= shopData.getCi(i);//get Operations of machines i
         Iterator it = list.iterator();
         
         //get a map with keys operations of the machine and values integers specifining degrees
         Map map=jobShopGraphics.getMachineBuffersLocations(i);
         Iterator mit=map.entrySet().iterator();
         
         int [] angles = new int[list.size()];
         theMachineIcon.setNumBuffers(list.size());
         int a=0;
         while(it.hasNext()){//iterate over all operations of machine i
            Operation op = (Operation)it.next();//get operation
             angles[a] = ((Integer)map.get(op)).intValue();
             bufferIndexesMap.put(op,new Integer(a++));
         }
         theMachineIcon.setAngles(angles);
        }//END OF LOOP SETTING UP ALL MACHINES

        
        //NOW TAKE CARE OF ROUTES
        routeStartsIndexesMap= new HashMap();
        routeEndsIndexesMap= new HashMap();
        routeStartsSidesMap= new HashMap();
        routeEndsSidesMap= new HashMap();
        
        int index,side;
        for(int r=1;r<=shopData.getR();r++){//loop on all routes
            side=jobShopGraphics.getRouteSide(r,0);
            index=jobShopGraphics.getRouteIndex(r,0)-1;
            routeStartsSidesMap.put(new Integer(r),new Integer(side));
            routeStartsIndexesMap.put(new Integer(r),new Integer(index));
            routeTips[side][index] = new RouteStartAnimIcon(r,side);
            
            side=jobShopGraphics.getRouteSide(r,1);
            index=jobShopGraphics.getRouteIndex(r,1)-1;
            routeEndsSidesMap.put(new Integer(r),new Integer(side));
            routeEndsIndexesMap.put(new Integer(r),new Integer(index));
            routeTips[side][index] = new RouteEndAnimIcon(r,side);
        }
        
        
        /*
         //FILL EVERYTHING  (USEFULL FOR DEBUGGING)
        for(int i=0;i<machines.length;i++)
            for(int j=0;j<machines[i].length;j++)
                machines[i][j]= new MachineAnimIcon(12);
        
         for(int i=0;i<routeTips.length;i++)
            for(int j=0;j<routeTips[i].length;j++)
                routeTips[i][j]= new RouteStartAnimIcon();*/
     }//END OF setUpDataStructures METHOD

     public JPanel getRouteChoosePanel(){
       return routeChoosePanel;  
     }
     
   public void shopChanged(ShopChangeEvent sce) {
       Map Qmap=shopState.getQMap();
       Iterator it = Qmap.entrySet().iterator();
       while(it.hasNext()){
                 Map.Entry entry = (Map.Entry)it.next();  
                Operation op = (Operation)entry.getKey();
         try{  
                int num = ((Integer)entry.getValue()).intValue();
                MachineAnimIcon iconToChange = (MachineAnimIcon)machinesMap.get(new Integer(shopData.getMachine(op)));
                int buffIndex = ((Integer)bufferIndexesMap.get(op)).intValue();
                iconToChange.setQueueSize(buffIndex, num);
         }catch(Exception e){
             e.printStackTrace();System.err.println(op);System.err.println(machinesMap);
         }
       }
       
       Operation [] ops = shopState.getMachineActivities();
       for(int i=0;i<ops.length;i++){
           int buff;
           if(ops[i]==null)
               buff=-1;
           else
                buff=((Integer)bufferIndexesMap.get(ops[i])).intValue();  
            ((MachineAnimIcon)machinesMap.get(new Integer(i+1))).setProcessingBuffer(buff);;
       }

       for(int r=1;r<=shopData.getR();r++){//loop on all routes and update route ends
            int side=((Integer)routeEndsSidesMap.get(new Integer(r))).intValue();
            int index=((Integer)routeEndsIndexesMap.get(new Integer(r))).intValue();
            int numJobs=shopState.getNumFinishedJobs(r);
            routeTips[side][index].setNumJobsInIcon(numJobs);
       }
       //System.out.println("In ShopAnim.shopChanged(): The current thread: " + Thread.currentThread());
       //this.paintImmediately(this.getVisibleRect());
       repaint();
    }     
    
    public void setShopState(ShopState shopState_){
        shopState=shopState_;
    }
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////GRAPHICS METHODS/////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////

     public void paint(Graphics g){
      //System.out.println("In ShopAnim.paint(): The current thread: " + Thread.currentThread());
        // try{Thread.sleep(200);}catch(Exception e){}
      super.paint(g);
      calcDims();
      drawMachines(g);
      drawRouteTips(g);
      drawRoutes(g);
    }//END OF PAINT() METHOD
    
    protected void drawMachines(Graphics g){
     int x,y;
      y=firstStreetHeight+iconHeight+STREET_HEIGHT+1;
      for(int i=0;i<NUM_MACHINE_SPOTS_HEIGHT;i++){
          x=firstStreetWidth+iconWidth+STREET_WIDTH+1;
          for(int j=0;j<NUM_MACHINE_SPOTS_WIDTH;j++){
              if(machines[i][j]  != null){//if there is a machine to paint
                machines[i][j].setIconWidth(iconWidth);  
                machines[i][j].setIconHeight(iconHeight);
                machines[i][j].paintIcon(drawingPanel,g,x,y);
                machineCoords[i][j]=new Point(x,y);
              }
              x+=iconWidth+STREET_WIDTH;
          }
          y+=iconHeight+STREET_HEIGHT;
      }        
    }//END OF METHOD
    
    protected void drawRouteTips(Graphics g){
        int x,y;
        
        //do NORTH
        x=firstStreetWidth+iconWidth+STREET_WIDTH+1;
        y=firstStreetHeight+1;
        for(int i=0;i<routeTips[NORTH].length;i++){
            if(routeTips[NORTH][i]!=null){  
                routeTips[NORTH][i].setIconWidth(iconWidth);  
                routeTips[NORTH][i].setIconHeight(iconHeight);
                routeTips[NORTH][i].paintIcon(drawingPanel,g,x,y);
                routeTipsCoords[NORTH][i]=new Point(x,y);
            }
            x+=iconWidth+STREET_WIDTH;
        }
 
        //continue on to doing EAST
         y=firstStreetHeight+iconHeight+STREET_HEIGHT+1;
        for(int i=0;i<routeTips[WEST].length;i++){
            if(routeTips[EAST][i]!=null){  
                routeTips[EAST][i].setIconWidth(iconWidth);  
                routeTips[EAST][i].setIconHeight(iconHeight);
                routeTips[EAST][i].paintIcon(drawingPanel,g,x,y);
                routeTipsCoords[EAST][i]=new Point(x,y);
            }
            y+=iconHeight+STREET_HEIGHT;
        }                
        
        
        //do WEST
        x=firstStreetWidth+1;
        y=firstStreetHeight+iconHeight+STREET_HEIGHT+1;
        for(int i=0;i<routeTips[WEST].length;i++){
            if(routeTips[WEST][i]!=null){  
                routeTips[WEST][i].setIconWidth(iconWidth);  
                routeTips[WEST][i].setIconHeight(iconHeight);
                routeTips[WEST][i].paintIcon(drawingPanel,g,x,y);
                routeTipsCoords[WEST][i]=new Point(x,y);                
            }
            y+=iconHeight+STREET_HEIGHT;
        }
        
        //continue on to doing SOUTH
        x=firstStreetWidth+iconWidth+STREET_WIDTH+1;
        for(int i=0;i<routeTips[NORTH].length;i++){
            if(routeTips[SOUTH][i]!=null){  
                routeTips[SOUTH][i].setIconWidth(iconWidth);  
                routeTips[SOUTH][i].setIconHeight(iconHeight);
                routeTips[SOUTH][i].paintIcon(drawingPanel,g,x,y);
                routeTipsCoords[SOUTH][i]=new Point(x,y);                    
            }
            x+=iconWidth+STREET_WIDTH;
        }
     }//END OF METHOD
    
    protected void calcDims(){
    
        //protected  int totalStreetWidth=(NUM_MACHINE_SPOTS_WIDTH+3)*STREET_WIDTH;    
       // protected  int totalStreetHeight=(NUM_MACHINE_SPOTS_HEIGHT+3)*STREET_HEIGHT;

        
      int widthForIcons = getWidth() - totalStreetWidth;
      int heightForIcons = getHeight() - totalStreetHeight;
      
      if(getWidth()>DRAWING_WIDTH)
           widthForIcons =  DRAWING_WIDTH- totalStreetWidth;
      
      if(getHeight()>DRAWING_HEIGHT)
          heightForIcons = DRAWING_HEIGHT - totalStreetHeight;
      
      iconWidth=widthForIcons/(NUM_MACHINE_SPOTS_WIDTH+2);
        firstStreetWidth=STREET_WIDTH+(widthForIcons%(NUM_MACHINE_SPOTS_WIDTH+2))/2;
        
      iconHeight=heightForIcons/(NUM_MACHINE_SPOTS_HEIGHT+2);
        firstStreetHeight=STREET_HEIGHT+(heightForIcons%(NUM_MACHINE_SPOTS_HEIGHT+2))/2;
        
        //System.out.println("iconWidth:"+iconWidth+"\ticonHeight:"+iconHeight);
        //System.out.println("firstStreetWidth:"+firstStreetWidth+"\tfirstStreetHeight:"+firstStreetHeight);
    }

    protected void drawRoutes(Graphics g){
        for(int r=0;r<routesToView.length;r++){  
            if(routesToView[r]==true){  
                drawRoute(r+1,g);
            }
        }

        for(int i=0;i<routesToView.length;i++){  
            if(machinesToView[i]==true){  
          
                drawRouteMachine(i+1,g);
            }
        }
    }//END OF METHOD
    
    protected void drawRoute(int rnum,Graphics g){
        g.setColor(Color.black);
        
        int index=((Integer)routeStartsIndexesMap.get(new Integer(rnum))).intValue();
        int side=((Integer)routeStartsSidesMap.get(new Integer(rnum))).intValue();
        Point startP=routeTipsCoords[side][index];
        Point start=routeTips[side][index].getLineTipPoint(startP.x,startP.y);
        
        index=((Integer)routeEndsIndexesMap.get(new Integer(rnum))).intValue();
        side=((Integer)routeEndsSidesMap.get(new Integer(rnum))).intValue();
        Point endP=routeTipsCoords[side][index];
        Point end=routeTips[side][index].getLineTipPoint(endP.x,endP.y);
        
        Iterator it = shopData.getRoute(rnum).iterator();
        Point prevPoint=start;
        while(it.hasNext()){//iterate over all operations of route
            Operation op = (Operation)it.next();
            int mnum=shopData.getMachine(op);
            MachineAnimIcon theIcon = (MachineAnimIcon)machinesMap.get(new Integer(mnum));
            int bindex =((Integer)bufferIndexesMap.get(op)).intValue();

            SpotInMatrix spot = ((SpotInMatrix)machinesSpotMap.get(new Integer(mnum)));
            Point machinePoint = machineCoords[spot.ii-1][spot.jj-1];
            Point thePoint=theIcon.getOperationPoint(bindex, machinePoint.x,machinePoint.y);
            g.drawLine(prevPoint.x,prevPoint.y,thePoint.x,thePoint.y);
            prevPoint=thePoint;
        }
        
        g.drawLine(prevPoint.x,prevPoint.y,end.x,end.y);
    }
    
    protected void drawRouteMachine(int machine,Graphics g){
        g.setColor(Color.black);
        //System.out.println("drawRouteMachine " + machine + " called");
        
        MachineAnimIcon theIcon = (MachineAnimIcon)machinesMap.get(new Integer(machine));
        
        Collection col = shopData.getCi(machine);
        Iterator it = col.iterator();
  
        
        while(it.hasNext()){//iterate over all operations of route
            Operation op = (Operation)it.next();
            int bindex =((Integer)bufferIndexesMap.get(op)).intValue();
            SpotInMatrix spot = ((SpotInMatrix)machinesSpotMap.get(new Integer(machine)));
            Point machinePoint = machineCoords[spot.ii-1][spot.jj-1];
            Point thePoint=theIcon.getOperationPoint(bindex, machinePoint.x,machinePoint.y);
            //so thePoint is the location of the buffer on the machine.
            
            if(op.getStep()==1){//if this is the first step in the route
                int index=((Integer)routeStartsIndexesMap.get(new Integer(op.getRoute()))).intValue();
                int side=((Integer)routeStartsSidesMap.get(new Integer(op.getRoute()))).intValue();
                Point startP=routeTipsCoords[side][index];
                Point start=routeTips[side][index].getLineTipPoint(startP.x,startP.y);
                //so start is the location of the route start
                g.drawLine(thePoint.x,thePoint.y,start.x,start.y);
            }else{//if this is not the first step in the route
                    Operation prevOp=new Operation(op.getRoute(),op.getStep()-1);
                    int pm = shopData.getMachine(prevOp);
                    
                    int bin =((Integer)bufferIndexesMap.get(prevOp)).intValue();
                    SpotInMatrix ms = ((SpotInMatrix)machinesSpotMap.get(new Integer(pm)));
                    Point mp = machineCoords[ms.ii-1][ms.jj-1];
           
                    
                    MachineAnimIcon pi = (MachineAnimIcon)machinesMap.get(new Integer(pm));                    
                    Point tp=pi.getOperationPoint(bindex, mp.x,mp.y);                             
                    g.drawLine(thePoint.x,thePoint.y,tp.x,tp.y);
            }
        }//end of loop on all operations of machine
    }//end of method
///////////////////////////////////////////////////////////////////////////////////////////    
///////////////////////////////////MAIN IS FOR TESTING//////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
    
    /**For testing.*/
    public static void main(String [] args){
        /*JFrame frame = new JFrame("Testing of ShopAnim");
        frame.setSize(500,515);
        frame.getContentPane().add(new ShopAnim());
        frame.getContentPane().setLayout(new FlowLayout());
        	frame.addWindowListener(new WindowAdapter()
						{
							public void windowClosing(WindowEvent we)
							{
								System.exit(1);
							}
				});
        
        frame.setVisible(true);*/
    }//end of main() method
    
    class RouteCheckBox extends JCheckBox implements ItemListener{
        int routeNum;
        RouteCheckBox(int routeNum_){  
            super("Route " + Integer.toString(routeNum_));
            routeNum=routeNum_;
            addItemListener(this);
        }
        
        public void itemStateChanged(java.awt.event.ItemEvent p1) {
            routesToView[((RouteCheckBox)p1.getItem()).routeNum-1]=isSelected();
            ShopAnim.this.repaint();
        }
    }//END OF INNER CLASS
    
        class MachineCheckBox extends JCheckBox implements ItemListener{
        int mNum;
        MachineCheckBox(int mNum_){  
            super("Machine " + Integer.toString(mNum_));
            mNum=mNum_;
            addItemListener(this);
        }
        
        public void itemStateChanged(java.awt.event.ItemEvent p1) {
            machinesToView[((MachineCheckBox)p1.getItem()).mNum-1]=isSelected();
           // System.out.println("Set machineCheck box at " +(((MachineCheckBox)p1.getItem()).mNum-1) + " to " + isSelected());
            ShopAnim.this.repaint();
        }
    }//END OF INNER CLASS
    
}//END OF CLASS