package haifa.shopsim.UI;

import haifa.shopsim.lab.*;
import javax.swing.table.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**Action that occurs when a new Nr is set in the mainGUI.
 *@version 1.1
 */
class SetNrAction extends AbstractAction{
                MainGUI mainGUI;
		public SetNrAction(MainGUI mainGUI_){
			super("Set Number of Jobs");
                        mainGUI=mainGUI_;
		}

		public void actionPerformed(ActionEvent ae){
                        setNr();
		}
                
        JTable jt;

        int [] nr;
        
        protected void setNr(){
          nr = mainGUI.generalProblemSizeChooser.getNr();
        
          jt= new JTable(nr.length,2);
          
          TableModel model=jt.getModel();
          for(int i=0;i<nr.length;i++){
            jt.setValueAt("Route " + (i+1),i,0);
            jt.setValueAt(Integer.toString(nr[i]),i,1);
          }
          JPanel panel = new JPanel(new BorderLayout());
          JScrollPane sp=new JScrollPane(jt);
          sp.setMaximumSize(new Dimension(200,300));
          panel.add(sp,BorderLayout.CENTER);
          JPanel bottom=new JPanel(new GridLayout(2,2,5,5));
          panel.add(bottom,BorderLayout.SOUTH);
          
          JButton reset = new JButton("Reset");
          JButton increaseAll= new JButton("Increase by 1");
          JButton decreaseAll = new JButton("Decrease by 1");
          JButton doubleAll = new JButton("Double");
          JButton halfAll= new JButton("Half");
          bottom.add(increaseAll);
          bottom.add(decreaseAll);
          bottom.add(doubleAll);
          bottom.add(halfAll);
          
         increaseAll.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent ae){
                          for(int i=0;i<nr.length;i++){
                                jt.setValueAt("Route " + (i+1),i,0);
                                int newInt=Math.min(Integer.parseInt(((String)(jt.getModel()).getValueAt(i,1)))+1,mainGUI.MAX_JOBS);
                                jt.setValueAt(Integer.toString(newInt),i,1);
                            }                 
              }
          });
          
          decreaseAll.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent ae){
                          for(int i=0;i<nr.length;i++){
                                jt.setValueAt("Route " + (i+1),i,0);
                                int newInt=Math.min(Math.max(Integer.parseInt(((String)(jt.getModel()).getValueAt(i,1)))-1,0),mainGUI.MAX_JOBS);
                                jt.setValueAt(Integer.toString(newInt),i,1);
                            }                 
              }
          });
          
          doubleAll.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent ae){
                          for(int i=0;i<nr.length;i++){
                                jt.setValueAt("Route " + (i+1),i,0);
                                int newInt=Math.min(Integer.parseInt(((String)(jt.getModel()).getValueAt(i,1)))*2, mainGUI.MAX_JOBS);
                                jt.setValueAt(Integer.toString(newInt),i,1);
                            }                 
              }
          });
          
          halfAll.addActionListener(new ActionListener(){
              public void actionPerformed(ActionEvent ae){
                          for(int i=0;i<nr.length;i++){
                                jt.setValueAt("Route " + (i+1),i,0);
                                int newInt=Integer.parseInt(((String)(jt.getModel()).getValueAt(i,1)))/2;
                                jt.setValueAt(Integer.toString(newInt),i,1);
                            }                 
              }
          });
          
         JOptionPane optionPane= new JOptionPane(panel,
                                                                                    JOptionPane.PLAIN_MESSAGE);
          JDialog dialog = optionPane.createDialog(mainGUI.mainPanel,"Set the number of jobs per route...");
                   dialog.setResizable(false);
                   dialog.show();
                   for(int i=0;i<nr.length;i++){
                       try{
                            nr[i]=Integer.parseInt(((String)model.getValueAt(i,1)));
                       }catch(Exception e){
                         System.err.println(e);  
                       }
                       
                   }
        }//END OF DO ACTION METHOD
}//END OF INNER CLASS 