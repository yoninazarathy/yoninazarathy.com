package haifa.shopsim.UI;

import javax.swing.*;
import java.awt.event.*;

/**
 *A close action for the MainGUI
 * @author  Yoni
 * @version 1.0
 */
class CloseAction extends AbstractAction{
                MainGUI mainGUI;
		public CloseAction(MainGUI mainGUI_){
			super("Close (reset) Shop");
                        mainGUI=mainGUI_;
		}
		public void actionPerformed(ActionEvent ae){
                    closeShopData();
                }
        
        /**Brings application to state it was at startup.*/
        private void closeShopData(){
             mainGUI.fixResetState();
        }

}//END OF INNER CLASS