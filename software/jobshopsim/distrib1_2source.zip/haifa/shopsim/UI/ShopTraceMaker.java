package haifa.shopsim.UI;

import  haifa.shopsim.*;
import java.util.*;
import eduni.simdiag.*;

/**This class is a thread that constntly waits for ShopChangedEvents and converts them to proper events for the Gantt Chart. It is basically an 
 interaface between Fred Howells SimJava events that pass betweeen entites and this projects ShopChangedEvents.
 *@version 1.1*/
class ShopTraceMaker extends java.lang.Thread implements
    eduni.simdiag.Traceable, ShopChangeListener {

    /**A refrence to the Shop Data Object.*/
    protected ShopData shopData;
    
    /**The shopChange event that is currently being handled.*/
    protected ShopChangeEvent shopChangeEvent;
    
    /**Used for wait and notify when waiting on new traces*/
    private boolean gotShopEvent = false;
    
    /**Used for wait and notify when waiting for display commands*/
    private boolean gotDisplayCommand=false;
    
    /**True as long as thread is running.*/
    private boolean running;
    
    /**A vector of the listeners to this trace.*/
    private Vector traceListeners = new Vector();
    
    /**The number of forwardedTraces.*/
    private int numForwardedTraces;
    
    /**The number of display traces.*/
    private int numDisplayTraces;
    
    /** Creates new ShopTraceMaker */
    public ShopTraceMaker(ShopData shopData_) {
        shopData=shopData_;
    }
    
    /**Stops the ShopTraceMaker, should be called.*/
    public void kill(){
        running = false;
        //System.out.println("The number of forwarded traces was: " + numForwardedTraces);
        //System.out.println("The number of display traces was: " + numDisplayTraces);
    }

    
    public void run(){
        running =true;
        synchronized(this){
            forwardTrace( new TraceEventObject(this,LAYOUT) );
            forwardTrace(new TraceEventObject(this,"States: Idle Working"));
            forwardTrace(new TraceEventObject(this,"$bars"));
            for(int i=1;i<=shopData.getI();i++)
                forwardTrace(new TraceEventObject(this,"Machine"+i+" States:"));
            forwardTrace(new TraceEventObject(this,"$events"));
            for(int i=1;i<=shopData.getI();i++)
                forwardTrace(new TraceEventObject(this,"u:Machine" +i +" at 0.0: P Idle"));
        }//end of first synchrnized block
        synchronized(this){
             while(running){  
                //wait for another shop event to be produced or display command
                while(gotShopEvent==false){
                    try{wait();}catch(InterruptedException e){}
                }
                double time = shopChangeEvent.getTime();
                if(shopChangeEvent instanceof MachineStartedEvent){
                    MachineStartedEvent mse = (MachineStartedEvent)shopChangeEvent;
                    forwardTrace(new TraceEventObject(this,"u:Machine" +mse.getMachineNumber()
                                                        +" at " +time +": P "+"Working"));
                }else if(shopChangeEvent instanceof MachineFinishedEvent){
                    MachineFinishedEvent mfe = (MachineFinishedEvent)shopChangeEvent;
                    forwardTrace(new TraceEventObject(this,"u:Machine" +mfe.getMachineNumber()
                                                    +" at " +time +": P Idle"));
                }
                //in case of other events no trace is to be sent
                gotShopEvent = false;
                notifyAll();
            }//end of while(running)
        }//end of synchronized
    }//END OF RUN() METHOD
    
    
    /**Handle incoming shopchangeevents.*/
    synchronized public void shopChanged(ShopChangeEvent sce) {
        while(gotShopEvent==true){
            try{   wait();}catch(InterruptedException e){}
        }
        shopChangeEvent = sce;
        gotShopEvent=true;
        notifyAll();
    }    
    
    /**Causes the ShopTraceMaker to send a dispaly trace, this method blocks untill the display trace was sent.*/
    public void sendDisplayTrace(){
            numDisplayTraces++;
            forwardTrace( new TraceEventObject(this,DISPLAY) );    
    }

    /** Javabeans trace event output */
    public synchronized void addTraceListener(TraceListener l) {
        traceListeners.addElement(l);
    }
    
    /** Javabeans trace event output */
    public synchronized void removeTraceListener(TraceListener l) {
        traceListeners.removeElement(l);
    }
    
    /** Sends trace event onwards to any listeners */
    public void forwardTrace(TraceEventObject e) {
        Vector l;
        TraceEventObject weo = new TraceEventObject(this,e);
        synchronized(this) { l = (Vector)traceListeners.clone(); }
        for (int i=0; i<l.size(); i++) {
            TraceListener wl = (TraceListener) l.elementAt(i);
            wl.handleTrace(weo);
        }
        numForwardedTraces++;
    }
}//END OF CLASS