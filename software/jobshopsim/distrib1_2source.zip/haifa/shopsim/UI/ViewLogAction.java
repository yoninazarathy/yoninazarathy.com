package haifa.shopsim.UI;

import haifa.shopsim.lab.*;

import javax.swing.*;
import java.awt.event.*;
import java.io.*;

/**
Use for displaying a pop-up window showing the algorithm's log.
 * @author  Yoni
 * @version 1.1
 */
class ViewLogAction extends AbstractAction{
                MainGUI mainGUI;
		public ViewLogAction(MainGUI mainGUI_){
			super("View Kernel Log");
                        mainGUI=mainGUI_;
		}

		public void actionPerformed(ActionEvent ae){
                    if(mainGUI.logWindow==null){
                            mainGUI.logWindow = new LogWindow(new PipedWriter(),"Job Shop Simulator: Kernel Log",false);
                            mainGUI.logWindow.activate();
                    }
                    mainGUI.logWindow.setVisible(true);
		}
}//END OF INNER CLASS