package haifa.shopsim.UI;

import javax.swing.*;
import java.awt.*;

/**
Designed to fill the areas of the GUI with a label when they are not enabled.
 * @author  Yoni
 * @version 1.1
 */
public class VacantLabel extends JLabel{
            VacantLabel(String text){
                                super(text,SwingConstants.CENTER)  ;
                                setBackground(Color.black);
                                setForeground(Color.white);
                                setOpaque(true);
            }
}//END OF INNER CLASS: VACANTLABEL