package haifa.shopsim.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/*Displays the helpString in a simple Dialog window.
 *@version 1.1
 */
class SimpleHelpAction extends AbstractAction implements UIStringConstants{
                MainGUI mainGUI;
                String helpString;
                String helpTitle;
		public SimpleHelpAction(MainGUI mainGUI_,String helpTitle_,String helpString_){
			super(helpTitle_);
                        helpTitle=helpTitle_;
                        mainGUI=mainGUI_;
                        helpString=helpString_;
		}

		public void actionPerformed(ActionEvent ae){
                    JTextArea textArea=new JTextArea(helpString);
                    textArea.setOpaque(false);
                    textArea.setEditable(false);
                    textArea.setLineWrap(true);
                    textArea.setWrapStyleWord(true);
                    textArea.setCaretPosition(0);
                    
                    textArea.setForeground(Color.blue);
                    textArea.setFont(new Font("Dialog",Font.BOLD,16));
                    JScrollPane scrollPane = new JScrollPane(textArea);
                    scrollPane.setPreferredSize(new Dimension(700,300));
                    JOptionPane optionPane= new JOptionPane(scrollPane,
                                                                                    JOptionPane.PLAIN_MESSAGE);

                    JDialog dialog = optionPane.createDialog(mainGUI.mainPanel,helpTitle);
                    dialog.setResizable(false);
                    dialog.show();
		}
}//END OF INNER CLASS 