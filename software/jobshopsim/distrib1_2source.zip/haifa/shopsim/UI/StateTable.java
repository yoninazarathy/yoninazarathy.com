package haifa.shopsim.UI;

import haifa.shopsim.*;

import haifa.global.*;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;

/**This class displays the state of the algorithm on the ShopState.
 The Panel is repainted every time a ShopChange event is recieved.
 *@version 1.1
 */
class StateTable extends JPanel implements ShopChangeListener{

        /**A reference to the shopState object.*/
	protected ShopState shopState;
        
        /**A reference to the shopData object.*/
	protected ShopData shopData;
        
        //////////GUI COMPONENTS IN THE JPANEL//////////
	protected JPanel topPanel;
		protected JLabel timeLabel;
		protected JLabel busyLabel;
	protected JTable bufferTable;
	protected JLabel bottomLabel;

        /**A vector of vectors, each vector being a row in the table.*/
        Vector rowData;
        
        /**Maps Operations to elements (Vectors) of the rowData vector.*/
        HashMap rowMap;
        
        /////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////CONSTRUCTOR//////////////////////
        /////////////////////////////////////////////////////////////////////////////
        
        StateTable(ShopData shopData_,ShopState shopState_) {
			shopData = shopData_;
			setShopState(shopState_);

                        //for heading of table
			Vector collNames = new Vector(2);
			collNames.add("(r,o) on \u03C3(r,o)"); //this unicode value means sigma
			collNames.add("Queue Size");
			
                        //for data of table
                        rowData = new Vector(shopData.getK());//will have one element (vector) for each buffer
                        rowMap = new HashMap(shopData.getK());
                        //System.out.println(shopState.getQMap());
                        for(int i=1;i<=shopData.getI();i++){//loop on all machines so that buffers are inserted machine by machine
                                Iterator it=shopState.getQMap().entrySet().iterator();
			        //Iterator it = shopState.getQMap().keySet().iterator();
			        //Iterator val = shopState.getQMap().values().iterator();
			        while(it.hasNext()){
                                        Map.Entry entry = (Map.Entry)it.next();

                                        Operation op=(Operation)entry.getKey();
                                        Integer numInBuffer= (Integer)entry.getValue();

                                        int machine = shopData.getMachine(op);
                                        if(machine==i){
				            Vector row = new Vector(2);
				            row.add(op.toString()+ " on " + machine);
				            row.add(numInBuffer);
			        	    rowData.add(row);
                                            rowMap.put(op,row);
                                        }
			        }
                        }//end of for loop on all machines
                        
                        ///SET UP GUI
                        setLayout(new BorderLayout());
                        add(topPanel = new JPanel(new GridLayout(2,1)),BorderLayout.NORTH);
				topPanel.add(timeLabel = new JLabel("",SwingConstants.CENTER));
				topPanel.add(busyLabel = new JLabel());

			timeLabel.setBackground(Color.black);
			timeLabel.setForeground(Color.white);
			timeLabel.setOpaque(true);
			timeLabel.setFont(new Font("Dialog",Font.BOLD,16));
			timeLabel.setText("TIME: " + shopState.getTime());

			busyLabel.setBackground(Color.white);
			busyLabel.setForeground(Color.black);
			busyLabel.setOpaque(true);
			busyLabel.setText("BM: " + shopState.getBusyMachines());

			add(new JScrollPane(bufferTable = new JTable(rowData,collNames)),BorderLayout.CENTER);
                       // bufferTable.setAutoResizeMode(bufferTable.AUTO_RESIZE_OFF);
                        
			add(bottomLabel = new JLabel(""),BorderLayout.SOUTH);

			bottomLabel.setBackground(Color.cyan);
			bottomLabel.setForeground(Color.black);
			bottomLabel.setOpaque(true);
			bottomLabel.setText("Finished Jobs: " + shopState.getTotalFinishedJobs());

			bufferTable.setColumnSelectionAllowed(false);
                        
                        this.setPreferredSize(new Dimension(167,200));
	}//END OF COT'R
        
        
	/**Updates shopState refrence and refreshes display.*/
	public void setShopState(ShopState shopState_){
		shopState=shopState_;
		repaint();
	}

	/**Responds to an event.*/
	public void shopChanged(ShopChangeEvent sce){
                //System.out.println("STATE TABLE GOT: " + sce);
		repaint();
	}

	/**Uses info in shopState*/
	public void repaint(){
		//ask if not null because maybe cot'r still hasn't been called
		if(bufferTable != null){
			timeLabel.setText("TIME: " + shopState.getTime());
			busyLabel.setText("BM: " + HaifaArrays.toStringArray(shopState.getBusyMachines()));
			bottomLabel.setText("Finished Jobs: " + shopState.getTotalFinishedJobs());
                        
			Iterator it = shopState.getQMap().entrySet().iterator();
			while(it.hasNext()){
                                Map.Entry entry =  ((Map.Entry)it.next());
                                Integer value = (Integer)entry.getValue();
                                Vector row =(Vector)rowMap.get(entry.getKey());
				row.set(1,value);//1 is for the position of the num jobs in the row
			}
                        bufferTable.repaint();
		}//end of if() block
		super.repaint();
	}//end of repaint();


}//END OF CLASS
