package haifa.shopsim.UI;

import haifa.shopsim.*;

/**
 This class is a functor that holds the method that is done after a run.
It is the shopRun that calls this method.
 * @author  Yoni
 * @version 1.1
 */
public class PostGUIRunAction implements PostRunAction{
                MainGUI mainGUI;
                
                public PostGUIRunAction(MainGUI mainGUI_){
                    mainGUI=mainGUI_;
                }
            
		public void doAction(){
                        if(mainGUI.shopTraceMaker != null)
                            mainGUI.shopTraceMaker.kill();
                        mainGUI.logWindow.println(mainGUI.stat);
			mainGUI.fixFinishedState();
		}
}//END OF INNER CLASS