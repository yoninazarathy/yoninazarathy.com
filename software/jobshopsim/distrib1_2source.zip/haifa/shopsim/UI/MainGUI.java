package haifa.shopsim.UI;

import haifa.shopsim.*;
import haifa.shopsim.fastkernel.*;
import haifa.shopsim.algorithms.*;
import haifa.shopsim.lab.*;
import haifa.shopsim.UI.shopanim.*;
import haifa.global.*;
import eduni.simdiag.*;

import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import javax.swing.filechooser.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.*;


/**This class is one of the several usuable products of the JobShopSimualtion Project.
It is the Algorithm testing/educational tool. It is the class that should be run
as the main class when running this tool as a stand alone application.
It may also be run as an applet.<P>
When run as an applet, job shop files may be loaded only from the host at
which the applet is sitting. This should suffice for demonstration purpuses.
see the init() method.<P>
Applet code should be:
<PRE>
 ...
		param name = "SHOP_DATA1" value = "shop1.jbs*A three machine problem"
		param name = "SHOP_DATA2" value = "10x10.jbs*The famous 10 by 10 problem"
...

</PRE>
<P>
 *This GUI features the following states of execution:
 *<ol> 
 <li> Reset State  
 *<li> Loaded State
 *<li> Alg Selected State
 *<li>Running State
 *<li> Finished State
 *</ol>
 *
 *@version 1.1
*/
public class MainGUI  extends JApplet implements UIStringConstants{

//////////THE STATES IN WHICH THE GUI MAY BE FOUND/////////////////
        /**This is the state immidiently after opening or after closing a shop.  Everything is Reset.*/
        protected final int RESET_STATE = 1;
        
        /**This state implies that a shop is loaded but not running and an algorithm is still not selected.*/
        protected final int LOADED_STATE = 2;
        
        /**This state implies that an algorithm is selected and also a shop is loaded.*/
        protected final int ALG_SELECTED_STATE = 3;
        
        /**This state implies that a shop is currently running.*/
        protected final int RUNNING_STATE = 4;
        
        /**This state implies that a simulation run was running and is now finished. It is similar to the ALG_SELECTED_STATE in the 
         sense that both an algoirthm and a shop data are present*/
        protected final int FINISHED_STATE = 5;
        
        /**The variable that states the state in which the MainGUI is found.*/
        protected int state;

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

	/**If the user chooses exit during an applet, it is brought to this page.*/
	protected  static final String  HOME_PAGE = "http://rstat.haifa.ac.il/~yonin/thesis/jobshopsim/shopsim.html";

        /**The highest multiplicty that the GUI enviornment allows.*/
         protected static final int MAX_JOBS=100000;        
        
	/**False if applet true if application*/
	protected static boolean isApplication;

	/**Used when working with a JFrame and setting a menu.*/
	protected JRootPane rootPane;

///////////////////////////////////////////////////////////////////
//////////COMPONENETS OF GUI /////////////////////////
///////////////////////////////////////////////////////////////////        
        
//////////BASIC AREAS OF GUI////////////////        
        /**Location in which the GUI algorithm appears.*/
        protected JPanel algPanel;
        
        /**For shopState table.*/
      	protected JPanel shopStateArea;
        
        /**For gantt chart.*/
        protected JPanel ganttArea;
        
        /**For animation.*/
	protected JPanel animArea;
        
//////////////MAIN PANELS AND SPLIT PANES OF GUI/////////////////        
	protected JPanel mainPanel;
	protected JLabel commandLabel;
        protected JPanel centerTopPanel;
        protected JPanel centerBottomPanel;
        
        /**Splits between Algorithm and animation/stateTable.*/
        protected JSplitPane upperSplitPane;
        
        /**Splits between the upper splitPane and the shopData,gantt.*/
        protected JSplitPane centerSplitPane;
        
        /**Vertical split between shopdata and gantt.*/
        protected JSplitPane bottomSplitPane;
        
///////////////////////MENU BAR COMPONENTS//////////////
        protected JMenuBar menuBar = new JMenuBar();
	protected JMenu fileMenu = new JMenu("File");
        protected JMenu simulationMenu = new JMenu("Simulation");
	protected JMenu algorithmMenu = new JMenu("Algorithm");
        protected JMenu helpMenu = new JMenu("Help");
            
        protected JMenu rvMenu;
        protected ButtonGroup rvGroup= new ButtonGroup();
        protected ButtonGroup algGroup = new ButtonGroup();
 
         /**Action events of the file menu. Each of these has a corresponeding inner class.*/
	Action [] fileMenuActions = {
				new OpenAction(this),
                                new CloseAction(this),
				new ExitAction(this)
				};
         protected static final int OPEN_ITEM_POS =0;
         protected static final int CLOSE_ITEM_POS =1;
         protected static final int EXIT_ITEM_POS =2;

        protected SpeedControlAction speedControlAction;         
         
        /**Action events of the simulation menu. Each of these has a corresponeding inner
	class.*/
	Action [] simulationMenuActions = {
				new StartSimulationAction(this),
                                new KillSimulationAction(this),
                                speedControlAction = new SpeedControlAction(this),
                                new ViewLogAction(this),
                                new SetNrAction(this)
				};                
        protected static final int START_ITEM_POS =0;                                
        protected static final int STOP_ITEM_POS =1;                                
        protected static final int SPEED_ITEM_POS=2;
        protected static final int VIEW_ITEM_POS =3;                                
        protected static final int SET_NR_ITEM_POS =4; 
         
        /**Action events of the Help menu. */
	Action [] helpMenuActions = {
				new SimpleHelpAction(this,"Using the Job Shop Simulator",USING_SIM_TEXT),
                                new SimpleHelpAction(this,"The On-Line Algorithms",ALGORITHMS_TEXT),
                                new SimpleHelpAction(this,"Creating your own .jbs files",JBS_FILES_TEXT),
                                new SimpleHelpAction(this,"About",ABOUT_TEXT),
                                };                 
        
///////////////////////////SIMULATION RELATED GUI DATA MEMBERS//////////////
         /**The animation.*/
        protected ShopAnim shopAnim;
        
        /**The Graphics information (to be read from .jbs file).  May be null if no graphics are read.*/
        protected JobShopGraphics jobShopGraphics;

        /**A reference to the stateTable*/
	protected JComponent stateTable;

        /**Results from the kernel, algorithms and stat collector are printed to this window.*/
        protected  LogWindow logWindow;

        /**Listens to shop events and transaltes them to trace events as seen by the gantt chart in the simJava package.*/
        protected ShopTraceMaker shopTraceMaker;
        
        /**Gets events from ShopSimulation and updates listeners according to speed control.*/
        protected ShopViewUpdater shopViewUpdater;

        /**Used to display Gantt Chart. Taken from the simJava package.*/
        protected TimingDiagram timingDiagram;

        /**The text area in which the shop data is displayed.*/
	protected JTextArea shopDataTextArea;        
        
        /**Slider used by speed control. The SpeedControlAction displays this slider.*/
        protected JSlider speedSlider;

/////////////////////////ENGINE RELATED DATA MEMBERS///////////////////        
	/**A reference to the ShopSimulation object (the object that runs the simulation).*/
	protected ThreadFastShopRun threadFastShopRun;
        
	/**A refrence to the currently selected shopAlgorithm, may be null.*/
	protected GUIAlgorithm currentAlgorithm;
        
	/**A reference to the data regarding the current job shop, may be null if no shop data is set.*/
	protected ShopData shopData;
        
        /**The statistics Collector.*/
        protected StatisticsCollector stat;
        
        /**The random variable generator.*/
        protected RandomTimeMaker randomTimeMaker;

        /**The size chooser used to determine how many jobs are on each route.*/
        protected GeneralProblemSizeChooser  generalProblemSizeChooser ;
        
//////////////OTHER DATA MEMEBERS///////////////////////////        
        /**A reference to the default random variable button.*/
        protected AbstractButton defaultRV;        
        
        protected Vector algButtunsVector=new Vector();
        protected AlgorithmSelectionAction lastAsa;
        protected ActionEvent lastAe;
        protected JPanel patchPanel;        
        protected Map urlFilesMap;
        
//////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////CONSTRUCTORS///////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////        
	/**Sets up GUI. Returns 'this'. This is basically like a co'tr*/
	public MainGUI setUp(JRootPane rootPane_){
		    rootPane = rootPane_;
                
                    //load classes now for higher response later
                    new JobShopClassLoaderToVM();
                
                    //SET UP SKELETON OF GUI
		    mainPanel = new JPanel(new BorderLayout(5,5));
		    mainPanel.add(commandLabel = new JLabel(WELCOME_STRING,
	       	                                                        SwingConstants.CENTER),BorderLayout.NORTH);
        	    commandLabel.setBackground(Color.yellow);
	            commandLabel.setForeground(Color.red);
		    commandLabel.setOpaque(true);
		    commandLabel.setFont(new Font("Dialog",Font.BOLD,18));
                    algPanel = new JPanel(new BorderLayout(5,5));
                    algPanel.setMinimumSize(new Dimension(10,80));
                    centerSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
                    mainPanel.add(centerSplitPane,BorderLayout.CENTER);
                    centerSplitPane.add(upperSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT));
                    centerBottomPanel = new JPanel(new BorderLayout(5,5));
                    centerSplitPane.add(centerBottomPanel);
                    shopStateArea = new JPanel(new BorderLayout(5,5));
                    ganttArea = new JPanel(new BorderLayout(5,5));
                    ganttArea.setPreferredSize(new Dimension(500,100));
                    animArea = new JPanel(new BorderLayout(5,5)); 
                    animArea.setMaximumSize(new Dimension(550,550));
                    shopStateArea.setMinimumSize(new Dimension(80,100));
                     shopDataTextArea = new JTextArea();
                     //shopDataTextArea.setMinimumSize(new Dimension(220,150));
                     //shopDataTextArea.setPreferredSize(new Dimension(220,150));
                     JScrollPane sp=new JScrollPane(shopDataTextArea);
                     sp.setPreferredSize(new Dimension(275,100));

                     centerBottomPanel.add(bottomSplitPane=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT));
                     bottomSplitPane.add(sp);
                     bottomSplitPane.add(ganttArea);
                        
                     JScrollPane spp=new JScrollPane(animArea);
                     centerTopPanel=new JPanel(new BorderLayout(5,5));
                     centerTopPanel.add(spp,BorderLayout.CENTER);
                     centerTopPanel.add(shopStateArea,BorderLayout.WEST);
                        
                     upperSplitPane.add(algPanel);
                     upperSplitPane.add(centerTopPanel);
                        
                     shopDataTextArea.setEditable(false);
                     shopDataTextArea.setFont(new Font("Dialog",Font.BOLD,16));
                     commandLabel.setFont(new Font("Dialog",Font.BOLD,16));

                      centerSplitPane.setOneTouchExpandable(true);
                      upperSplitPane.setOneTouchExpandable(false);
                      centerSplitPane.setDividerSize(16);
                       upperSplitPane.setDividerSize(10);
                       bottomSplitPane.setOneTouchExpandable(true);
                       bottomSplitPane.setDividerSize(20);
                       bottomSplitPane.invalidate();
                       mainPanel.invalidate();
                        
                       ///////////SET UP MENU BAR
                       menuBar.add(fileMenu);
                       int start=0;//stupid patch for menu in applet
                       if(isApplication==false){//if applet
                             setUpDataFilesMenuForApplet();
                             start=1;//in applet the first menu item should be changed to a special one
                        }
			for(int i=start;i<fileMenuActions.length;i++)
				fileMenu.add(fileMenuActions[i]);
                        menuBar.add(algorithmMenu);
                        setUpAlgorithmsMenu();
                        menuBar.add(simulationMenu);
                        for(int i=0;i<simulationMenuActions.length;i++)
                            simulationMenu.add(simulationMenuActions[i]);
                        rvMenu=new JMenu("Select Distribution");
                        AbstractButton but=null;
                        rvMenu.add(but=new JRadioButtonMenuItem(new RVSelectionAction(this,RVSelectionAction.CV_0_RV)));
                        but.setSelected(true);
                        rvGroup.add(but);
                        defaultRV=but;
                        rvMenu.add(but=new JRadioButtonMenuItem(new RVSelectionAction(this,RVSelectionAction.CV_025_RV)));
                        rvGroup.add(but);                
                        rvMenu.add(but=new JRadioButtonMenuItem(new RVSelectionAction(this,RVSelectionAction.CV_10_RV)));
                        rvGroup.add(but);                
                        rvMenu.add(but=new JRadioButtonMenuItem(new RVSelectionAction(this,RVSelectionAction.WEIBULL_RV)));
                        rvGroup.add(but);                
                        rvMenu.add(but=new JRadioButtonMenuItem(new RVSelectionAction(this,RVSelectionAction.P_3_RV)));
                        rvGroup.add(but);
                        rvMenu.add(but=new JRadioButtonMenuItem(new RVSelectionAction(this,RVSelectionAction.P_2_RV)));
                        rvGroup.add(but);
                        simulationMenu.add(rvMenu);
                        menuBar.add(helpMenu);
                        for(int i=0;i<helpMenuActions.length;i++)
                                helpMenu.add(helpMenuActions[i]);
                        rootPane.setJMenuBar(menuBar);
                    
                        //ensure that we are in a reset state.
                        fixResetState();
		        return this;
	}//END OF setUp METHOD
        
        private void setUpAlgorithmsMenu(){
    		///////THIS NASTY CODE  (below)USES ANONYMOUS INNER CLASES TO OVERIRED
		////// ALGORITHM SELECTION ACTION CLASSES FOR SPECIFIC ALGORITHMS
		///// TO ADD MORE ALGORITHMS' ADD TO THE CODE BELOW
            AbstractButton but=null;
		algorithmMenu.add(but=new JRadioButtonMenuItem(new AlgorithmSelectionAction(this,
								UserGUIAlgorithm.StaticGetAlgorithmName(),0){
                        		                    		public GUIAlgorithm allocateAlgorithm(){
                                                                            algPanel.setMinimumSize(new Dimension(10,20+shopData.getR()*25));
			                                        		return 	new UserGUIAlgorithm(shopData,commandLabel);
			}}));
                        algGroup.add(but);
                        algButtunsVector.add(but);
		algorithmMenu.add(but=new JRadioButtonMenuItem(new AlgorithmSelectionAction(this,
							SimpleRandomAlgorithm.StaticGetAlgorithmName(),1){
                						public GUIAlgorithm allocateAlgorithm(){
                                                                    algPanel.setMinimumSize(new Dimension(10,45));
		                					return 	new GUIforComputerAlgorithm(
				        					new SimpleRandomAlgorithm(shopData),commandLabel);
					                				
									                
			}}));
                        algGroup.add(but);
                        algButtunsVector.add(but);
                        algorithmMenu.add(but=new JRadioButtonMenuItem(new AlgorithmSelectionAction(this,
							SmartRandomAlgorithm.StaticGetAlgorithmName(),1){
                						public GUIAlgorithm allocateAlgorithm(){
                                                                    algPanel.setMinimumSize(new Dimension(10,45));
		                					return 	new GUIforComputerAlgorithm(
				        					new SmartRandomAlgorithm(shopData),commandLabel);
					                				
									                
			}}));
                        algGroup.add(but);
                        algButtunsVector.add(but);
                        
                        
                        algorithmMenu.add(but=new JRadioButtonMenuItem(new AlgorithmSelectionAction(this,
							RandomJobAlgorithm.StaticGetAlgorithmName(),1){
                						public GUIAlgorithm allocateAlgorithm(){
                                                                    algPanel.setMinimumSize(new Dimension(10,45));
		                					return 	new GUIforComputerAlgorithm(
				        					new RandomJobAlgorithm(shopData),commandLabel);
					                				
									                
			}}));
                        algGroup.add(but);
                        algButtunsVector.add(but);                        
                        
                        
                        
                 algorithmMenu.add(but=new JRadioButtonMenuItem(new AlgorithmSelectionAction(this,
							FBFSPriorityAlgorithm.StaticGetAlgorithmName(),1){
                						public GUIAlgorithm allocateAlgorithm(){
                                                                    algPanel.setMinimumSize(new Dimension(10,45));
		                					return 	new GUIforComputerAlgorithm(
				        					new FBFSPriorityAlgorithm(shopData),commandLabel);
					                				
			}}));       
                        algGroup.add(but);
                        algButtunsVector.add(but);
                 algorithmMenu.add(but=new JRadioButtonMenuItem(new AlgorithmSelectionAction(this,
							LBFSPriorityAlgorithm.StaticGetAlgorithmName(),1){
                						public GUIAlgorithm allocateAlgorithm(){
                                                                    algPanel.setMinimumSize(new Dimension(10,45));
		                					return 	new GUIforComputerAlgorithm(
				        					new LBFSPriorityAlgorithm(shopData),commandLabel);
					                				
			}}));  
                        algGroup.add(but);
                        algButtunsVector.add(but);

                        
                algorithmMenu.add(but=new JRadioButtonMenuItem(new AlgorithmSelectionAction(this,
							MakespanFIAalgorithm.StaticGetAlgorithmName(),1){
                						public GUIAlgorithm allocateAlgorithm(){
                                                                    algPanel.setMinimumSize(new Dimension(10,45));
		                					return 	new GUIforComputerAlgorithm(
				        					new MakespanFIAalgorithm(shopData),commandLabel);
					                				
			}}));
                algGroup.add(but);
                algButtunsVector.add(but);
                algorithmMenu.add(but=new JRadioButtonMenuItem(new AlgorithmSelectionAction(this,
							DWFluidAlgorithm.StaticGetAlgorithmName(),1){
                						public GUIAlgorithm allocateAlgorithm(){
                                                                    algPanel.setMinimumSize(new Dimension(10,45));
		                					return 	new GUIforComputerAlgorithm(
				        					new DWFluidAlgorithm(shopData),commandLabel);
					                				
			}})); 
                        algGroup.add(but);
                        algButtunsVector.add(but);
                        /////END OF NASTY CODE FOR ADDING ALGORITHMS TO SHOP
                        ////ALGORITHMS TO SHOP
        }//end of setUpAlgorithmsMenu method

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////METHODS THAT SET THE  GUI STATES///////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        protected void fixResetState(){
            
            speedSlider=null;
            
            shopDataTextArea.setText(NO_SHOP_DATA_STRING);
            commandLabel.setText(WELCOME_STRING);

            ((JMenuItem)fileMenu.getItem(OPEN_ITEM_POS)).setEnabled(true);
            ((JMenuItem)fileMenu.getItem(CLOSE_ITEM_POS)).setEnabled(false);
            simulationMenu.setEnabled(false);
            algorithmMenu.setEnabled(false);
            
            animArea.removeAll();
            animArea.add(new VacantLabel(VACANT_ANIM_AREA_STRING));
            ganttArea.removeAll();
            ganttArea.add(new VacantLabel(VACANT_GANTT_AREA_STRING));
            algPanel.removeAll();
            algPanel.add(new VacantLabel(VACANT_ALG_AREA_STRING));
            shopStateArea.removeAll();
            shopStateArea.add(new VacantLabel(VACANT_SHOP_STATE_AREA_STRING));
            algPanel.setMinimumSize(new Dimension(10,45));
            
            randomTimeMaker= new DefaultRandomTimeMaker();//set shop to determinsitic
            defaultRV.setSelected(true);
            
            if(isApplication)
                frame.setTitle(FRAME_TITLE);
            
            if(threadFastShopRun != null){
                threadFastShopRun.kill();
                 threadFastShopRun=null;
            }

            if(logWindow!=null){
              logWindow.destroy();
              logWindow=null;
            }
            
             if(patchPanel!=null){
                centerTopPanel.remove(patchPanel);
                patchPanel=null;
             }
            
              shopData = null;
              if(shopTraceMaker!=null){
                    shopTraceMaker.kill();
                    shopTraceMaker=null;
               }
            
               if(shopAnim!=null)
               shopAnim=null;

                state=RESET_STATE;
                bottomSplitPane.setDividerLocation(550);
                System.gc();
        }//END OF METHOD
        
        protected void fixLoadedState(){
                fullyEnableMenu(algorithmMenu);
                commandLabel.setText(JOB_SHOP_LOADED_STRING);
                simulationMenu.setEnabled(true);
                ((JMenuItem)simulationMenu.getItem(START_ITEM_POS)).setEnabled(false);
                ((JMenuItem)simulationMenu.getItem(SET_NR_ITEM_POS)).setEnabled(true);
                ((JMenuItem)simulationMenu.getItem(STOP_ITEM_POS)).setEnabled(false);
                ((JMenuItem)simulationMenu.getItem(VIEW_ITEM_POS)).setEnabled(true);
                rvMenu.setEnabled(true);
                ((JMenuItem)fileMenu.getItem(CLOSE_ITEM_POS)).setEnabled(true);
                ((JMenuItem)fileMenu.getItem(OPEN_ITEM_POS)).setEnabled(false);
            
                algPanel.setMinimumSize(new Dimension(10,45));
                
                animArea.removeAll();
                animArea.add(new VacantLabel(VACANT_ANIM_AREA_STRING));
                ganttArea.removeAll();
                ganttArea.add(new VacantLabel(VACANT_GANTT_AREA_STRING));
                algPanel.removeAll();
                algPanel.add(new VacantLabel(VACANT_ALG_AREA_STRING));
                shopStateArea.removeAll();
                shopStateArea.add(new VacantLabel(VACANT_SHOP_STATE_AREA_STRING));
            
                algorithmMenu.removeAll();
                setUpAlgorithmsMenu();
            
                if(patchPanel!=null){
                            centerTopPanel.remove(patchPanel);
                            patchPanel=null;
                }
                
                if(threadFastShopRun != null){
                     threadFastShopRun.kill();
                     threadFastShopRun=null;
                }

                if(shopTraceMaker!=null){
                    shopTraceMaker.kill();
                    shopTraceMaker=null;
                }
                timingDiagram=null;
                stateTable=null;
                            
                shopDataTextArea.setText("---Topology and job info of shop---\n"+	shopData.toString());
                shopDataTextArea.setCaretPosition(0);
                state=LOADED_STATE;
                System.gc();
                mainPanel.updateUI();
        }//END OF METHOD
        
        protected void fixAlgSelectedState(){
                fullyEnableMenu(algorithmMenu);
                fullyEnableMenu(simulationMenu);
                ((JMenuItem)simulationMenu.getItem(STOP_ITEM_POS)).setEnabled(false);

                 rvMenu.setEnabled(true);
                 ((JMenuItem)fileMenu.getItem(CLOSE_ITEM_POS)).setEnabled(true);
            ((JMenuItem)fileMenu.getItem(OPEN_ITEM_POS)).setEnabled(false);
            commandLabel.setText(ALG_SELECTED_STRING);
            currentAlgorithm.reset();
            currentAlgorithm.setEnabled(false);
            
            if(patchPanel!=null){
                centerBottomPanel.remove(patchPanel);
                patchPanel=null;
            }
            
            mainPanel.updateUI();
            
            state=ALG_SELECTED_STATE;
        }
        
        protected void fixRunningState(){
                         algorithmMenu.setEnabled(false);
                         ((JMenuItem)simulationMenu.getItem(START_ITEM_POS)).setEnabled(false);
                         ((JMenuItem)simulationMenu.getItem(SET_NR_ITEM_POS)).setEnabled(false);
                         rvMenu.setEnabled(false);
                         ((JMenuItem)simulationMenu.getItem(STOP_ITEM_POS)).setEnabled(true);
                         ((JMenuItem)simulationMenu.getItem(VIEW_ITEM_POS)).setEnabled(true);
                         
                         ((JMenuItem)fileMenu.getItem(CLOSE_ITEM_POS)).setEnabled(true);
                         ((JMenuItem)fileMenu.getItem(OPEN_ITEM_POS)).setEnabled(false);
                         
                        currentAlgorithm.setEnabled(true);
                        mainPanel.updateUI();
                        state=RUNNING_STATE;
        }//END OF METHOD
        
        protected void fixFinishedState(){
                        currentAlgorithm.setEnabled(false);
                        currentAlgorithm.reset();
                        algorithmMenu.setEnabled(true);
                        ((JMenuItem)simulationMenu.getItem(START_ITEM_POS)).setEnabled(true);
                        ((JMenuItem)simulationMenu.getItem(SET_NR_ITEM_POS)).setEnabled(true);
                        rvMenu.setEnabled(true);
                         ((JMenuItem)simulationMenu.getItem(STOP_ITEM_POS)).setEnabled(false);
                         ((JMenuItem)simulationMenu.getItem(VIEW_ITEM_POS)).setEnabled(true);
                         commandLabel.setText(SIMULATION_FINISHED_STRING);
                         
                         if(threadFastShopRun!=null){
                                   threadFastShopRun.kill();
        			   threadFastShopRun=null;
                        }
                         
                          if(shopTraceMaker!=null){
                                shopTraceMaker.kill();
                                shopTraceMaker=null;
                          }
                         
                          if(algPanel!=null)
                                    algPanel.removeAll();

                         
                        state=FINISHED_STATE;
                        mainPanel.updateUI();
                        System.gc();
        }//END OF METHOD
        
       ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////ACTION METHODS/////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        /**Loads and allocates shopData.*/
        protected void loadShopData(Reader reader) throws Exception{
                 try{
			shopData = new FastShopDataFromJBSFile(reader);
                 }catch(JobShopFileFormatException e){//in case of error show dialog
                   System.err.println("Error in Job shop file: "+e);
                   JOptionPane optionPane= new JOptionPane("Contents of Job Shop File could not be interpreted. (line "+
                                                                                        e.getLineNo()+")",
                                                                                    JOptionPane.ERROR_MESSAGE);
                   JDialog dialog = optionPane.createDialog(mainPanel,"Error");
                   dialog.setResizable(false);
                   dialog.show();
                    throw e;
		}catch(Exception e){
			System.err.println(e);
		}    
                generalProblemSizeChooser = new GeneralProblemSizeChooser();
                int temp[] = new int[shopData.getR()];
                for(int r=0;r<temp.length;r++)
                    temp[r]=1;
                generalProblemSizeChooser.setNr(temp);
                fixLoadedState();
        }
        
        /**Loads and allocates jobShopGraphics.  Assumes that shopData is already set properly. If there*/
        protected void loadShopGraphics(Reader reader)throws Exception{
                 try{
			jobShopGraphics = new JobShopGraphics(reader,shopData);
		}catch(Exception e){
        		jobShopGraphics=null;//means not to do animation	
                        e.printStackTrace();
		}    
                
                if(jobShopGraphics==null){//if graphics were not properly loaded
                    JOptionPane optionPane= new JOptionPane(
                    "Shop Data file does not contain proper information for Graphics.",
                                                                                    JOptionPane.ERROR_MESSAGE);
                   JDialog dialog = optionPane.createDialog(mainPanel,"Animation will be supressed");
                   dialog.setResizable(false);
                   dialog.show();
                   throw new Exception();
                }
                fixLoadedState();
        }//END OF loadShopGraphics() method                        
        
        ///////////////////////////////////////////////////////////////////////////
	///////////////////////ADDITIONAL METHODS///////////////////
	///////////////////////////////////////////////////////////////////////////
        
	/**Changes the command label*/
	public void setCommandLabel(String cmd){
		commandLabel.setText(cmd);
	}
        
         protected void fullyEnableMenu(JMenu menu){
            for(int i=0;i<menu.getItemCount();i++)
                            ((JMenuItem)menu.getItem(i)).setEnabled(true);
            menu.setEnabled(true);
        }
        
        protected void notifyAboutSpeed(){
                            int val=speedSlider.getValue();
                            shopViewUpdater.setRawSpeed(val);
                            if(currentAlgorithm != null && currentAlgorithm instanceof GUIforComputerAlgorithm)
                                ((GUIforComputerAlgorithm)currentAlgorithm).setBusyAnimSpeed(val);
        }
        
//////////////////////////////////////////////////////////////////////////////////
///////////////CODE THAT IS SPECIFIC FOR APPLETS///////////////
//////////////////////////////////////////////////////////////////////////////////

	/**Reads parameters, sets up, etc...*/
	public void init(){
		isApplication=false;
		int num=1;
                
                urlFilesMap=new HashMap();
                
		while(true){
			String parName = "SHOP_DATA" + Integer.toString(num++);
			String param = getParameter(parName);
			if(param==null)
				break;
                        
                        urlFilesMap.put(param.substring(param.indexOf('*')+1),param.substring(0,param.indexOf('*')));
                        
		}
		if(urlFilesMap.isEmpty()){
			System.err.println("SHOP_DATA# parameters aren't set!!!");
			getContentPane().add(new
					JLabel("Job Shop Simulation:  ERROR WITH PARAMETER, CHECK HTML SOURCE",
					SwingConstants.CENTER));
			return;
		}
		getContentPane().add(setUp(getRootPane()).mainPanel);
	}//END OF init() method

        protected void setUpDataFilesMenuForApplet(){
            JMenu fileNamesList = new JMenu("Open Shop");
            Iterator it = urlFilesMap.entrySet().iterator();
            
            while(it.hasNext()){
                Map.Entry entry = (Map.Entry)it.next();
              JMenuItem item = new JMenuItem((String)entry.getKey());
              fileNamesList.add(item);
              item.addActionListener(new ActionListener(){
                  public void actionPerformed(ActionEvent ae){
                      String urlString =(String) urlFilesMap.get(ae.getActionCommand());
                      
                    try{
                            Reader reader;
                    	    URL url = new URL(urlString);
				    reader = new InputStreamReader(
							url.openConnection().getInputStream());
                            loadShopData(reader);
				    reader = new InputStreamReader(
							url.openConnection().getInputStream());
                                 loadShopGraphics(reader);
                    }catch(NoJobShopGraphicsInfoException e){
                      return;  
                    }catch(Exception e){
                      System.err.println(e); 
                      fixResetState();
                    }
                  }
              });
            }
            fileMenu.add(fileNamesList);
        }
        
	public void start(){
		//QQQQ
	}

	public void stop(){
		//QQQQ
	}

	public void destory(){
		//QQQQ
	}

	/**Kills the applet and goes to HOME_PAGE with the browser.*/
	protected void exitApplet(){
		stop();
		try{
			getAppletContext().showDocument(new URL(HOME_PAGE));
		}catch(Exception e){
			mainPanel.setVisible(false);
		}
	}


	///////////////////////////////////////////////////////////////////////////
	////////////CODE THAT IS SPECIFIC FOR A STAND-ALONE APPLICATION////////////
	///////////////////////////////////////////////////////////////////////////

            protected static JFrame frame;
        
	/***/
	public static void main(String [] a){
		isApplication = true;
                frame = new JFrame(FRAME_TITLE);
                
		frame.getContentPane().add(new MainGUI().setUp(frame.getRootPane()).mainPanel);
		frame.setSize(800,600);
		frame.addWindowListener(new WindowAdapter()
						{
							public void windowClosing(WindowEvent we)
							{
								exitApplication();
							}
				});
		frame.setVisible(true);
	}

	/**Called to exit. Currently just kills the JVM.*/
	protected static void exitApplication(){
		System.exit(0);
	}
}//END OF CLASS