package haifa.shopsim.UI;

/**
 *
 * @author  Yoni
 * @version 1.0
 */

import haifa.shopsim.*;
import haifa.shopsim.UI.shopanim.*;

import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.io.*;

/**Handles the Open Action of the File menu. This action is designed to open new
	shop data files. A distiction is made whether this is an application or an applet.
	In an application, files are loaded from the file system, whereas in an applet,
	a URL of a file is to be specified.
 @version 1.1*/
class OpenAction extends AbstractAction implements UIStringConstants{
                private File homeDir;
                private JFileChooser fileChooser;
                private MainGUI mainGUI;
		public OpenAction(MainGUI mainGUI_){
			super("Open shop");
                        mainGUI=mainGUI_;
                        if(mainGUI.isApplication){
                        homeDir = new File(".");
                         fileChooser = new JFileChooser(homeDir);
                         fileChooser.addChoosableFileFilter(new javax.swing.filechooser.FileFilter(){
                             //ANON. INNER CLASS TO CHOOSE JOB SHOP CLASS FILES "jbs"
                       
                             public boolean accept(File f){
                               if(f.isDirectory())
                                   return true;
                               String suffix = getSuffix(f);
                               if(suffix != null && suffix.equalsIgnoreCase("jbs"))
                                   return true;
                               return false;
                             }
                             
                             private String getSuffix(File f){
                                 String s = f.getPath();
                                 int i = s.lastIndexOf('.');
                                 if(i>0 && i<s.length()-1)
                                  return s.substring(i+1);
                                 return null; //no suffix
                             }
                             public String getDescription(){
                                 return "job shop files (*.jbs)";
                             }
                             
                         });
                        }//end of if on application
		}
                
		public void actionPerformed(ActionEvent ae){
                    if(mainGUI.isApplication){
			int state = fileChooser.showOpenDialog(null);
                        File file = fileChooser.getSelectedFile();
                        
                        if(file !=null &&
                        state== JFileChooser.APPROVE_OPTION){
                          Reader reader;
                              try{//READ DATA
			        reader = new InputStreamReader(
				                        new FileInputStream(file));
			         mainGUI.loadShopData(reader);
                                 mainGUI.frame.setTitle(FRAME_TITLE+"  ["+file.getName()+"]"); 
                                 
                                 reader = new InputStreamReader(
				                        new FileInputStream(file));//again for the graphics
                                 mainGUI.loadShopGraphics(reader);
                          }catch(NoJobShopGraphicsInfoException e){
                              return;
                          }catch(Exception e){
                             e.printStackTrace();
                          }//end of try block
		    }//end of if block on if file is to be opened
                    }//END OF if is an application
                }//END OF ACTION PERFORMED METHOD
                

                
	}//END OF INNER CLASS