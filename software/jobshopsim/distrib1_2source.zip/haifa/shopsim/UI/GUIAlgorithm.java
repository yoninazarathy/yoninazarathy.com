package haifa.shopsim.UI;

import haifa.shopsim.*;

/**A shop algorithm that has some sort of GUI represnting it.
 *@version 1.1
 */
public interface GUIAlgorithm extends ShopAlgorithm{
    public void setEnabled(boolean enabled);       
}