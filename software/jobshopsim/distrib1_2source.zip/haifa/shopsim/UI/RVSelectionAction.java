package haifa.shopsim.UI;

import haifa.shopsim.lab.*;

import javax.swing.*;
import java.awt.event.*;


/**
 *Action that occurs when user selects a new random variable in the MainGUI
 * @author  Yoni
 * @version  1.0
 */
class RVSelectionAction extends AbstractAction{
                MainGUI mainGUI;

                final static String CV_0_RV= "C.V. = 0";
                final static String CV_025_RV= "C.V. = 0.25";
                final static String CV_10_RV= "C.V. = 1.0";                
                final static String WEIBULL_RV="Weibull 1/2";
                final static String P_3_RV=   "Pareto with 3 moments";
                final static String P_2_RV=   "Pareto with 2 moments";
                
		/**The constructor uses an algorithm name.*/
		RVSelectionAction(MainGUI mainGUI_,String rvName){
			super(rvName);
                        mainGUI=mainGUI_;
		}

		/**Does what is specified at the class explanation above.*/
		public void actionPerformed(ActionEvent ae){
                    String sel = ae.getActionCommand();
                    System.out.println(sel);
                    if(sel.equals(CV_0_RV))
                        mainGUI.randomTimeMaker=new DefaultRandomTimeMaker();
                    else if(sel.equals(CV_025_RV))
                        mainGUI.randomTimeMaker=new NormalCV025TimeMaker();
                    else if(sel.equals(CV_10_RV))
                        mainGUI.randomTimeMaker=new ExpRandomTimeMaker();
                    else if(sel.equals(WEIBULL_RV))
                        mainGUI.randomTimeMaker=new WeibullHalfRandomTimeMaker();
                    else if(sel.equals(P_3_RV))
                        mainGUI.randomTimeMaker=new Pareto3MomentsRandomTimeMaker();
                    else if(sel.equals(P_2_RV))
                        mainGUI.randomTimeMaker=new Pareto2MomentsRandomTimeMaker();
		}
}