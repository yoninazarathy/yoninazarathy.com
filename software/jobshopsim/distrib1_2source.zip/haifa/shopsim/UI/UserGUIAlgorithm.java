package haifa.shopsim.UI;

import haifa.shopsim.*;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**The GUIAlgorithm is actually not an algorithm, but a user control
through which the user may be asked to control the shops at discrete simulation
epochs.
 @version 1.1
 */
public class UserGUIAlgorithm extends JPanel implements GUIAlgorithm{

         ////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////ALGORITHM TYPE DATA MEMEBERS/////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////
    
        /**A reference to the ShopState object.*/
	ShopState shopState;
        
        ShopSimulation shopSimulation;
        
        /**A reference to the shopData object.*/
	ShopData shopData;
        
        /**log.*/
	PrintWriter log;
        
        //////////////////////////////////////////////////////////////////////////////////
        //////////////////////GUI COMPONENETS/////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////
        
        /**A reference to the label on which commands to the user are to be displayed.*/
	JLabel commandLabel;
        
        /**The keys are buttons and the values are operations.*/
	HashMap buttonMap;
        
        /**The "rest" button.*/
	JButton restButton;
       
        
        JButton askAgainButton;
        
        JPanel leftPanel;
        
        /**Horizontal panels, one for each route.*/
	JPanel [] routePanels;
        
        /**The panel that holds all of the routes.*/
	JPanel stepsPanel;
        
        JPanel mainPanel;
        
        //////////////////////////////////////////////////////////////////////////////////
        ///////OPERATION SPECIFIC DATA MEMBERS///////////////////////
        //////////////////////////////////////////////////////////////////////////////////
       
	private Operation nextOperation;

	private boolean restClicked;
        
        private boolean askAgainClicked;

	private boolean quitFlag=false;

        ////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////CONSTRUCTORS/////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////
        
         /**Constructor.*/
        UserGUIAlgorithm(	ShopData shopData_,
					JLabel commandLabel_) {
			System.out.println("GUI Algorithm Cot'r");
			shopData = shopData_;
			commandLabel = commandLabel_;

                        this.setLayout(new BorderLayout());
                        mainPanel=new JPanel();
                        this.add(new JScrollPane(mainPanel),BorderLayout.CENTER);
                        
                        
			int R = shopData.getR();
			int K = shopData.getK();

                        Font font = new Font("Serif",Font.BOLD,12);
                        
			buttonMap = new HashMap(K);
			mainPanel.setLayout(new BorderLayout());
                        leftPanel = new JPanel(new BorderLayout());
                        leftPanel.add(restButton = new JButton("Rest"),BorderLayout.EAST);
                        leftPanel.add(askAgainButton = new JButton("Ask Again"),BorderLayout.WEST);
			mainPanel.add(leftPanel,BorderLayout.WEST);
                            restButton.setFont(font);
                            askAgainButton.setFont(font);
			mainPanel.add(stepsPanel = new JPanel(),BorderLayout.CENTER);
			stepsPanel.setLayout(new GridLayout(R,1));
			routePanels = new JPanel[R];
			int k=0;
			OperationButtonL bl = new OperationButtonL();
			for(int r=0;r<shopData.getR();r++){
				stepsPanel.add(routePanels[r] = new JPanel(new FlowLayout(FlowLayout.LEFT)));
				java.util.List ops = null;
				try{
					ops = shopData.getRoute(r+1);
				}catch(Exception e){
					System.err.println(e);
					System.exit(1);
				}
				Iterator it = ops.iterator();
				while(it.hasNext()){
					Operation o = (Operation)it.next();
					JButton b = new JButton(o.toString() + " on " +shopData.getMachine(o));
					buttonMap.put(b,o);
                                             b.setFont(font);
					routePanels[r].add(b);
					b.addActionListener(bl);
				}
			}
			restButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					restClicked=true;
					synchronized(UserGUIAlgorithm.this){
                                                        setEnabled(false);
							UserGUIAlgorithm.this.notify();
					}
				}

			});
                        askAgainButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					askAgainClicked=true;
					synchronized(UserGUIAlgorithm.this){
                                                        setEnabled(false);
							UserGUIAlgorithm.this.notify();
					}
				}

			});
	}//END OF CONSTRUCTOR

        ////////////////////////////////////////////////////////////////////////////////
        ////////////////////ALGORITHM TYPE METHODS////////////////////
        ////////////////////////////////////////////////////////////////////////////////
        
         /**Tells the algorithm that it is ready for inquiry by the algorithm client (kernel). .*/
        public void setEnabled(boolean enabled){
                Set b = buttonMap.keySet();
                Iterator it = b.iterator();
                while(it.hasNext())
                    ((JButton)it.next()).setEnabled(enabled);
                restButton.setEnabled(enabled);
                askAgainButton.setEnabled(enabled);
        }
        
        public void setShopStateObject(ShopState shopState_){
		shopState=shopState_;
	}
        
        public void setShopSimulationObject(ShopSimulation shopSimulation_){
            shopSimulation = shopSimulation_;
        }

	public void setShopData(ShopData shopData_){
		shopData=shopData_;
	}

	public void setLog(PrintWriter log_){
		log=log_;
	}
       
        public void reset(){}
        
        
	/**Returns true when the algorithm decided that it is time to quit.*/
	public boolean quitCalled(){
		return quitFlag;
	}

	/***/
	public String explanationString(){
		return null;
	}
        
        /**Returns false since the user's actions are not specified in the algorithm.*/
	public boolean isDeterministic(){
		return false;
	}

	public static String StaticGetAlgorithmName(){
		return "User Controlled";
	}

	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}

	public String toString(){
		return getAlgorithmName();
	}
 
	private void setEnabledDisabled(int machineNumber){
		Collection sch = shopState.getSchedulableOperations();
                //log.println("In GUIAlgoirthm: schedulabledOperations:"+sch);
		Iterator it = buttonMap.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry me = (Map.Entry)it.next();
			int mN = shopData.getMachine((Operation)me.getValue());
			if(sch.contains(me.getValue()) && machineNumber == mN)
				((JButton)me.getKey()).setEnabled(true);
			else
				((JButton)me.getKey()).setEnabled(false);
		}
                restButton.setEnabled(true);
                askAgainButton.setEnabled(true); 
                
	}//END OF METHOD

	/**Very simply reads a command from console and returns a ShopCommmand object.*/
	public ShopCommand whatNow(int machineNumber){
                //log.println("whatNow("+machineNumber+") called in GUIAlgorithm");
		commandLabel.setText("Please schedule machine #"+machineNumber );
		setEnabledDisabled(machineNumber);
                //log.println("In GUIAlgorithm, finished setting enabled disabled buttons");
		synchronized(this){
			while(nextOperation == null && restClicked==false && askAgainClicked==false)
				try{wait();}catch(InterruptedException e){}
		}
		if(restClicked){
			restClicked=false;
			return new ShopCommand(machineNumber,ShopCommand.CODE_REST);
                }else if(askAgainClicked){
                    askAgainClicked=false;
                    for(int i=1;i<=shopData.getI();i++)
                        if(i!= machineNumber)
                            shopSimulation.askAgainAtCurrentTime(i);
                    return whatNow(machineNumber);
                }else{
                        Operation temp = nextOperation;
                        nextOperation = null;
			return new ShopCommand(machineNumber,temp);
		}
	}//END OF WHATNOW() METHOD

	class OperationButtonL implements ActionListener{
		public void actionPerformed(ActionEvent ae){
			nextOperation = (Operation)buttonMap.get(ae.getSource());
			synchronized(UserGUIAlgorithm.this){
                                 setEnabled(false);
				UserGUIAlgorithm.this.notify();
			}
		}
	}//END OF INNER CLASS
}//END OF CLASS