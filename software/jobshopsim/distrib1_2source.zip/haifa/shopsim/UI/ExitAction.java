package haifa.shopsim.UI;

import javax.swing.*;
import java.awt.event.*;

/**This action calls the exitApplication() method in the case of an application.
In the case of an applet, the applet is stopped and the HOME_PAGE url is browsed to.
 * @author  Yoni
 * @version 1.1*/
class ExitAction extends AbstractAction{
                MainGUI mainGUI;
		public ExitAction(MainGUI mainGUI_){
			super("Exit");
                        mainGUI=mainGUI_;
		}
		public void actionPerformed(ActionEvent ae){
			if(mainGUI.isApplication)
				mainGUI.exitApplication();
			else
				mainGUI.exitApplet();
		}
}//END OF INNER CLASS