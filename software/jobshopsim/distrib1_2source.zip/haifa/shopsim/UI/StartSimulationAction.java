package haifa.shopsim.UI;

import eduni.simdiag.*;
import haifa.shopsim.fastkernel.*;
import haifa.shopsim.*;
import haifa.shopsim.UI.shopanim.*;
import haifa.global.*;
import haifa.shopsim.lab.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/*Action that starts a simulation.  This action allocates, a new ShopSimnulation object and 
 *other several new entites required for the simulation.
 *@version 1.1
 */
class StartSimulationAction extends AbstractAction implements UIStringConstants{
                MainGUI mainGUI;
		public StartSimulationAction(MainGUI mainGUI_){
			super("Start Simulation");
                        mainGUI=mainGUI_;
		}

		public void actionPerformed(ActionEvent ae){
                    if(mainGUI.state==mainGUI.FINISHED_STATE){//If a simulation has been just run
                        mainGUI.shopStateArea.removeAll();
                        mainGUI.ganttArea.removeAll();
                        mainGUI.stateTable=null;
                        mainGUI.timingDiagram=null;
                        mainGUI.lastAsa.actionPerformed(mainGUI.lastAe);
                    }
                        mainGUI.currentAlgorithm.setEnabled(true);
                        mainGUI.ganttArea.removeAll();
                        mainGUI.ganttArea.add(mainGUI.timingDiagram= new TimingDiagram(),BorderLayout.CENTER);
                        
                        mainGUI.shopStateArea.removeAll();
                        
                        mainGUI.animArea.removeAll();
                        if(mainGUI.jobShopGraphics!=null){
                            mainGUI.animArea.add(mainGUI.shopAnim = new ShopAnim(mainGUI.shopData,mainGUI.jobShopGraphics),BorderLayout.CENTER);
                            if(mainGUI.patchPanel!=null)
                                mainGUI.centerTopPanel.remove(mainGUI.patchPanel);
                            mainGUI.centerTopPanel.add(mainGUI.patchPanel = mainGUI.shopAnim.getRouteChoosePanel(),BorderLayout.EAST);
                        }else{
                            mainGUI.shopStateArea.add(new VacantLabel(ANIM_SUPPRESSED_STRING));
                            mainGUI.shopAnim=null;
                        }
                        
                        if(mainGUI.logWindow!=null){
                                mainGUI.logWindow.destroy();
                                mainGUI.logWindow=null;
                            }                        
                        
                            mainGUI.logWindow = new LogWindow(new PipedWriter(),"Job Shop Simulator: Kernel Log",false);
                            mainGUI.logWindow.activate();

                            mainGUI.currentAlgorithm.setLog(mainGUI.logWindow);
                            
                        try{
                            mainGUI.threadFastShopRun = new ThreadFastShopRun(mainGUI.currentAlgorithm
									                        ,mainGUI.shopData,
									                        new PostGUIRunAction(mainGUI),mainGUI.logWindow);
                            
                        }catch(Exception e){
                            DoError.printAndQuit("allocating threadFastShopRun",e);
                        }
                          
                        System.out.println("setting shop simulation object on " + mainGUI.currentAlgorithm);
                        mainGUI.currentAlgorithm.setShopSimulationObject(mainGUI.threadFastShopRun);
                         
                        mainGUI.stat = new StatisticsCollector(mainGUI.shopData,mainGUI.threadFastShopRun);
                        mainGUI.threadFastShopRun.addShopChangeListener(mainGUI.stat);
                        mainGUI.threadFastShopRun.setProblemSizeChooser(mainGUI.generalProblemSizeChooser);
                        mainGUI.threadFastShopRun.setRandomTimeMaker(mainGUI.randomTimeMaker);
                        
                         mainGUI.shopTraceMaker = new ShopTraceMaker(mainGUI.shopData);
                         mainGUI.threadFastShopRun.addShopChangeListener(mainGUI.shopViewUpdater =
                                            new ShopViewUpdater(mainGUI.shopTraceMaker));
                         if(mainGUI.speedSlider==null)
                             mainGUI.speedControlAction.setUpSpeedSlider();
                         mainGUI.notifyAboutSpeed();
                        
                        if(mainGUI.shopAnim!=null){//may be null if no shop graphics are defined
                            mainGUI.shopAnim.setShopState(mainGUI.threadFastShopRun);
                            mainGUI.shopViewUpdater.addShopChangeListener(mainGUI.shopAnim);
                        }
                 
                        mainGUI.stateTable=new StateTable(mainGUI.shopData,mainGUI.threadFastShopRun);
                        mainGUI.shopStateArea.add(mainGUI.stateTable);
                        mainGUI.shopViewUpdater.addShopChangeListener((StateTable)mainGUI.stateTable);
                        
                        mainGUI.threadFastShopRun.addShopChangeListener(mainGUI.shopTraceMaker);
                        mainGUI.shopTraceMaker.addTraceListener(mainGUI.timingDiagram);
                        mainGUI.shopTraceMaker.start();
                        mainGUI.currentAlgorithm.reset();
                        mainGUI.currentAlgorithm.setShopStateObject(mainGUI.threadFastShopRun);
                        System.gc();
			mainGUI.threadFastShopRun.go();
                        mainGUI.mainPanel.updateUI();
                        mainGUI.fixRunningState();
		}
}//END OF INNER CLASS        