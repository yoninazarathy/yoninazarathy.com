package haifa.shopsim.UI;

import haifa.shopsim.*;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**The GUIAlgorithm is actually not an algorithm, but a user control
through which the user may be asked to control the shops at discrete simulation
epochs.
 *@version 1.1
 */
class GUIforComputerAlgorithm extends JPanel implements GUIAlgorithm{

	private ShopAlgorithm shopAlgorithm;

	private JLabel nameLabel;
	
        private JButton stepButton;
	private JButton goButton;
	private JButton pauseButton;
	
        private JLabel commandLabel;
	private JPanel centerPanel;
	private JPanel buttonPanel;

	private BusyAnimation animLeft;
	private BusyAnimation animRight;

	private boolean go;
	private boolean step;
        
	GUIforComputerAlgorithm(ShopAlgorithm shopAlgorithm_,
							JLabel commandLabel_) {

			shopAlgorithm = shopAlgorithm_;
			commandLabel = commandLabel_;

			setLayout(new BorderLayout(5,5));
                        setBackground(Color.black);
                        setForeground(Color.white);
                        setOpaque(true);
                        
                        centerPanel = new JPanel(new BorderLayout(5,5));
                        centerPanel.setBackground(Color.black);
                        centerPanel.setForeground(Color.white);
                        centerPanel.setOpaque(true);
			nameLabel = new JLabel(shopAlgorithm.getAlgorithmName() ,SwingConstants.CENTER);
                        //nameLabel.setFont(new Font("Dialog",Font.BOLD,16));
                        nameLabel.setBackground(Color.green);
                        nameLabel.setForeground(Color.black);
			nameLabel.setOpaque(true);
                        
                        buttonPanel = new JPanel(new GridLayout(1,3,5,5));
                        buttonPanel.setBackground(Color.black);
                        buttonPanel.setForeground(Color.white);
                        buttonPanel.setOpaque(true);

			buttonPanel.add(stepButton = new JButton("Step"));
			buttonPanel.add(goButton = new JButton("Go"));
			buttonPanel.add(pauseButton = new JButton("Pause"));
                        centerPanel.add(nameLabel,BorderLayout.NORTH);
                        centerPanel.add(buttonPanel,BorderLayout.SOUTH);
			stepButton.addActionListener(new StepL());
			goButton.addActionListener(new GoL());
			pauseButton.addActionListener(new PauseL());


			add(animLeft = new BusyAnimation(),BorderLayout.WEST);
			add(animRight = new BusyAnimation(),BorderLayout.EAST);
                        add(centerPanel,BorderLayout.CENTER);
                        setEnabled(true);
                         reset();
	}

        public void setBusyAnimSpeed(int speed){
          animLeft.setSpeed(speed);
          animRight.setSpeed(speed);
        }
        
        
        /**Tells the algorithm that it is ready for inquiry by the algorithm client (kernel). .*/
        public void setEnabled(boolean enabled){
           // shopAlgorithm.setEnabled(enabled);
            if(enabled  == false){
                    goButton.setEnabled(false);
                    stepButton.setEnabled(false);
                    pauseButton.setEnabled(false);
                    go=false;
                    step=false;
                    animLeft.stop();
		    animRight.stop();
            }else{//enabled == true
                    goButton.setEnabled(true);
                    stepButton.setEnabled(true);
                    pauseButton.setEnabled(false);
             }
        }   
                
          /**Resets the algorithm.*/
        public void reset(){
          shopAlgorithm.reset();
          go=false;
          step = false;
          animRight.reset();
          animLeft.reset();
        }


	class GoL implements ActionListener{
		public void actionPerformed(ActionEvent ae){
			animLeft.start();
			animRight.start();
			goButton.setEnabled(false);
			stepButton.setEnabled(false);
			pauseButton.setEnabled(true);
			go=true;
			synchronized(GUIforComputerAlgorithm.this){
				GUIforComputerAlgorithm.this.notify();
			}
		}
	}

	class PauseL implements ActionListener{
			public void actionPerformed(ActionEvent ae){
				animLeft.stop();
				animRight.stop();
				pauseButton.setEnabled(false);
				goButton.setEnabled(true);
				stepButton.setEnabled(true);
				go=false;
				synchronized(GUIforComputerAlgorithm.this){
					GUIforComputerAlgorithm.this.notify();
				}
			}
	}

	class StepL implements ActionListener{
			public void actionPerformed(ActionEvent ae){
				animLeft.step();
				animRight.step();
				step=true;
				synchronized(GUIforComputerAlgorithm.this){
					GUIforComputerAlgorithm.this.notify();
				}
			}
	}

	/**Passes on to hosted shop algorithm.*/
	public ShopCommand whatNow(int machineNumber){
                commandLabel.setText("Use the step, go and pause buttons below");
		synchronized(this){
			while(go==false && step==false)
				try{wait();}catch(InterruptedException e){}
		}
		step=false;
                //System.out.println("In whatNow() of GUI for comp alg.");
		return shopAlgorithm.whatNow(machineNumber);
	}

////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////METHODS PASSED TO HOSTED ALGORITHM///////////
////////////////////////////////////////////////////////////////////////////////////////////////////        

	/**Passes on to hosted shop algorithm*/
	public void setShopStateObject(ShopState shopState_){
		shopAlgorithm.setShopStateObject( shopState_);;
	}
        
        public void setShopSimulationObject(ShopSimulation shopSimulation_){
            shopAlgorithm.setShopSimulationObject(shopSimulation_);
        }        

	/**Passes on to hosted shop algorithm*/
	public void setShopData(ShopData shopData_){
		shopAlgorithm.setShopData(shopData_);
	}

	/**Passes on to hosted shop algorithm*/
	public void setLog(PrintWriter log_){
		shopAlgorithm.setLog(log_);
	}
        
	/***/
	public String explanationString(){
		return shopAlgorithm.explanationString();
	}

        /**Returns false since the user's actions are not specified in the algorithm.*/
	public boolean isDeterministic(){
		return shopAlgorithm.isDeterministic();
	}

	public String getAlgorithmName(){
		return shopAlgorithm.getAlgorithmName();
	}

	public String toString(){
		return getAlgorithmName();
	}
}//END OF CLASS