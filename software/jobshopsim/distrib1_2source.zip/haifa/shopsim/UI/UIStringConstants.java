package haifa.shopsim.UI;

/**
 *String messages that are displayed by the MainGUI at certrtain times. This includes the strings
 *that are help (quite large strings).
 * @author  Yoni 
 * @version 1.2
 */
interface UIStringConstants {
        static final  String FRAME_TITLE = "Job Shop Simulator, Haifa University, Israel, version 1.2";
        static final String  WELCOME_STRING = "To select a job shop, use the File menu above.";
        
        static final String VACANT_ANIM_AREA_STRING="Animation Area";
        static final String VACANT_GANTT_AREA_STRING="Gantt Chart Area";
        static final String VACANT_ALG_AREA_STRING="Algorithm Control Area";
        static final String VACANT_SHOP_STATE_AREA_STRING="Shop State Area";
        
        static final String JOB_SHOP_LOADED_STRING= "To select an algorithm, use the Algorithm  menu above.";
        static final String ALG_SELECTED_STRING= "To start the simulation kernel, select \"Start Simulation\" from the Simulation menu above.";
        static final String SIMULATION_ABORTED_STRING= "Simulation Aborted. To start again, reselect an algorithm.";
        static final String NO_SHOP_DATA_STRING = "Shop File Information Area:"+
                                                                                                            "\nNo Job Shop Loaded";
        static final String ANIM_SUPPRESSED_STRING="No animation";
        static final String SIMULATION_FINISHED_STRING="Simulation is complete. To restart,  use the menus above.";
        static final String ABOUT_TEXT=
                "Job Shop Simulator\n"+
                "Haifa University, Israel.\n"+
                "\n"+
                "Version 1.2  July  2001.\n"+
                "Home Page: http://rstat.haifa.ac.il/~yonin/thesis/jobshopsim/shopsim.html\n"+
                "\n"+
                "Supervised By Prof. Gideon Weiss (gweiss@rstat.haifa.ac.il)\n"+
                "and programmed by Yoni Nazarathy (ynazarty@study.haifa.ac.il).\n"+
                "\n"+
                "Uses the Gantt Chart from simjava by Fred Howell (http://www.dcs.ed.ac.uk/home/fwh).\n"+
                "\n"+
                "Note that the simulation kernel is also designed to run without the GUI and is being used\n"+
                "for job shop experimentation and investigation.";
        
        final static String JBS_FILES_TEXT=
        "A .jbs (Job Shop) file is a file that describes the meaned topology of a high volume job shop problem"+
        " instance. This file is read by the Job Shop Simulator (JSS) and used to perform the simulations."+
        " The file is to be created any text editor, it may then be opened by the JSS when run as "+
        "an application or put on a web server when the JSS is run as an applet. There are several example"+
        " files available with the installation, these may also be found on the web.\n"+
        "\n-------------------------------------\n"+
        "The file format uses the following guidelines:\n"+
        "The file is divided into three logical parts: The shop dimension part "+
        "(specifies how many machines and how many routes are in the shop), the routes part"+
        " (specifies the steps and mean durations of each route) and  the graphics part"+
        " (specifies the information that tells the shop animation how to display the shop)"+
        " (this part is optional).\n\n"+
        "Comments may appear in the file in lines that follow the '#' character.\n\n"+
        "All number may be of a floating point form: 3.14 or an integer form: 354\n\n"+
        "All directives may be either lowercase, uppercase or a mix.\n\n"+
        "All information should be separated by white space (space,tab or enter).\n"+
       "\n-------------------------------------\n"+
        "In the shop dimension part (the start of the file) you should specify two"+
        " integer numbers, the first is the number of machines and the second is the number of routes.\n"+
       "\n-------------------------------------\n"+
        "In the routes part you should have a number of route entries that is "+
        "the same as the number of routes specified in the shop dimension part.  Each "+
        "route entry should look like this:\n\n"+
        "Route 14\n"+
        "3 5 9 3 8\n"+
        "Means\n"+
        "3.4 3 5 2 5.0\n\n"+
        "The first line of numbers are the machine indexes for route 14, the "+
        "second line is the processing means for each of the steps.  Thus the route entry "+
        "means that route #14 is composed of 5 steps with the given machines and processing times.\n"+
       "\n-------------------------------------\n"+
        "The third part (after the route part) is the graphics part.  This part is "+
        "optional (it may be omitted).  Note that for shops with more than 10 routes or more than "+
        "25 machines you may not specify graphics information. There is also a limit of up to 12 buffers "+
        "(operations) per machine.\n\n"+
        "The graphics part starts with the word 'Graphics'.  When the JSS reads the "+
        ".jbs file, it uses the 'Graphics' word to understand that you have put graphic information."+
        " After the word 'Graphics', you should put two parts, the machines part and the routes part.\n\n"+
        "The machine part consist of entries that tell the JSS, where and how to display each machine.  "+
        "The route part tells the JSS where and how to display the route ends and starts (squares and "+
        "triangles respectively).\n"+
       "\n-------------------------------------\n"+
        "The machine part consists of machine entries, one for each machine and the route "+
        "parts consists of route entries, one for each route.  You must make sure that the number "+
        "of entries matches the number of machines and number of routes.\n"+
        "Each machine entry looks like this:\n\n"+
        "Machine 5\n"+
        "3   2\n"+
        "1 4	30\n"+
        "2 5 	60\n"+
        "4 8 	120\n"+
        "7 3	240\n\n"+
        "This is the entry for machine #5.  The first two number specify the location of"+
        " the machine on the graphics grid (a 5 by 5 grid).  This should be a coordinate "+
        "of the type (i,j)  i=1,...,5  j=1,...,5. It is your responsibility to make sure that there"+
        " is no other machine with the same graphics coordinate.  (You now see why there is a limit of"+
        " 25 machines (for graphics info). The next four lines in the machine entry are directives for "+
        "displaying the buffers in the machine. Each machine may have up to 12 buffers (a buffer is"+
        " synonymous with an operation).  The machine in the example above has the buffers (1,4),(2,5),(4,8)"+
        " and (7,3).  On the screen, the buffers are displayed as yellow trapezoids placed on the "+
        "circumference of the machines.  For each buffer, we specify an angle at which it is to be"+
        " displayed (notice that the angles are multiples of 30 degrees).  Since a"+
        " circle has 360 degrees, there is a limit of up to 12 buffers per"+
        " machine  ( a graphics limit, not a simulation limit). An angle of"+
        " 30 degrees, means that the buffer is placed at 1 o'clock.  An angle"+
        " of 270 degrees, means that the buffer is placed at 9 o'clock etc...  "+
        "It is your responsibility to make sure that the shop data, really"+
        " matches the buffers that you specified (the JSS will not catch this "+
        "and stall if there is a mismatch). Thus in the above example, buffers (1,4),"+
        " (2,5), (4,8) and (7,3) should be the buffers that are specified in the routes (1,2,4 and 7) to"+
        " be on machine #5.\n"+
       "\n-------------------------------------\n"+
        "After specifying machine entries for each of the machines, you should specify route"+
        " entries. Each route is characterized by an start (triangle) and end (square).  The "+
        "route tips (start and ends) are to be placed on the perimeter of the 5 by 5 grid that"+
        " is allocated for the machines. Excluding the corners this leaves room for 20 route "+
        "ends (a total of 10 routes). Let's look at an example route entry:\n"+
        "Route 8\n"+
        "NORTH 3\n"+
        "SOUTH 5\n"+
        "\nThis entry is for route #8.  It says that the start should be on the north side "+
        "at location 3 (index of 1 to 5, west to east and north to south).  The end in the example "+
        "above is place on the south side on location 5.  You may have put 'EAST' or 'WEST' instead "+
        "of NORTH and SOUTH, or any combination. Just make sure that two route tips are not "+
        "assigned to the same spot.\n"+
       "\n-------------------------------------\n"+
        "It is recommended that you use the file 3machine2routes.jbs as an example. Note"+
        " that if you want to create elegant graphics info it is recommended that you use "+
        "paper and pencil to lay out the file.\n\n"+
        "Remember that the JSS does not fully check the correctness of the .jbs file,"+
        "this means that giving it a bad file (e.g. graphics do not fully match the shop data)"+
        " may cause the program to stall.";
        
        final static String USING_SIM_TEXT=
        "The Job Shop Simulator (JSS) is an interactive simulation program "+
        "designed to simulate the Job Shop Problems in which the number of "+
        "routes is fixed and the number of jobs on each route is large. For a "+
        "full description of the design and applications of the JSS, go to "+
        "http://rstat.haifa.ac.il/~yonin/thesis/jobshopsim/shpsim.html.\n"+
        "\n------------------------------------\n"+
        "The JSS's workspace is composed of the following parts:\n\n"+
        "The Algorithm Area\n"
        +"The Gantt Chart Area\n"
        +"The Shop State Area\n"
        +"The Shop Data Area\n"
        +"The Animation Area\n"+
        "\nNote that you may use the sliders that separate these areas to \n"+
        "resize, hide or reshow these areas.\n"+
        "\n------------------------------------\n"+
        "To run a simulation, you must first open a .jbs file. Use the File "
        +"menu to open a file (you may look at the help for .jbs files to see "
        +"the specification of the jbs file). After selecting a .jbs file, the "
        +"JSS loads the file and attempts to understand the information "
        +"written in it. If the information is ill formed, you will be "
        +"notified.  If the .jbs does not contain graphic information you will "
        +"also be notified and the animation will be shown during the course "
        +"of the simulation. If the information is Kosher, the job shop is "
        +"loaded and summarized in the shop data area (bottom left)\n\n"
        +"After successfully opening a file, you should select an algorithm "
        +"from the Algorithm menu.\n\n"
        +"After selecting an algorithm you may set several options from the "
        +"Simulation menu. These are the R.V. to be used to generate "
        +"processing times (around the means specified in the .jbs file), the "
        +"number of jobs in each route and the simulation speed.  Note when "
        +"setting the number of jobs on each route you may actually edit the "
        +"text fields so that there is an uneven number of jobs on the routes "
        +"(make sure to press enter after editing a text field). Note also "
        +"that you do not have to "+"set the simulation speed before starting "
        +"the simulation, this may be "
        +"done while the simulation is running.\n"+
        "\n------------------------------------\n"+
        "When you are ready, select Start Simulation from the simulation "
        +"menu.  This will generate the gantt and animation of the job shop "
        +"(if graphics information is available in the loaded .jbs file). If "
        +"you selected the User Controlled algorithm you may now start to "
        +"schedule the shop by your self.  If you selected any other "
        +"algorithm, click the Go Button to start and use the Step and Pause "
        +"buttons at your will.\n\n"
        +"At any moment, during or after the simulation, you may select View "
        +"Kernel Log to view messages that are displayed by the simulation "
        +"kernel and the algorithm.  Note that when the simulation is "
        +"complete, the statistics collector dumps the collected statistics to "
        +"the Kernel Log.\n"+
        "\n------------------------------------\n"+
        "Note that machines and routes are labeled using the number "
        +"1,2,3,....  Jobs are not labeled because the simulation engine "
        +"treats all jobs on a routes as having the same processing time "
        +"distribution.  Operations are labeled (r,o), where r is the route "
        +"number and o is the operation number.  In the Shop State area you "
        +"may see the current number of jobs in each buffer (each operation), "
        +"the number displayed includes jobs that are currently being "
        +"processed. In the animation, jobs are the little purple dots, "
        +"buffers (operations) are the yellow trapezoids, working machines are "
        +"red circles and idle machines are blue circles.  "
        +"The big "
        +"triangles are route starts and the boxes are route ends.\n"+
        "\n------------------------------------\n"+
        "Note that there are several bugs that have not been tended to:\n\n"
        +"When generating random numbers, or using .jbs files with fractional "
        +"processing times, the simulation time in the shop state has to many "
        +"digits past the decimal point.\n\n"+
        "When setting the number of jobs on each route, you must press return "
        +"after typing in a number in one of the text fields.\n\n"+
        "Various text fields within the shop state and the set number of jobs "
        +"dialog are editable and they should not be.\n\n"+
        "When running long simulations the gantt chart gets \"tired\" because it "
        +"has a lot of information to display, as a result, the simulation slows "
        +"down.  (Current work around: hide the gantt chart).\n\n"+
        "Sometimes, the user interface is not very responsive during the running "
        +"of a simulation. This is due to the fact, that drawing the animation "
        +"is done on the same thread as the GUI's response thread.  (Current "
        +"work around: press pause, before you want to use the GUI).";
        
         final static String ALGORITHMS_TEXT="This is a short description of what each of the algorithms does:\n"+
            "\nUser Controlled Algorithm - \n"+
            "In this algorithm, the user schedules the machines."+
            " This is performed by clicking the desired operation on"+
            " the machine that the user is asked to schedule.  Operations "+
            "are written in the form \"(4,3) on 5\" meaning step 3 on route 4 performed "+
            "on machine 5.  Note that the user may click the Rest button if he wishes "+
            "not to schedule the machine at the current scheduling epoch.  The Ask Again "+
            "button may be used in the following case: Assume that at a certain scheduling "+
            "epoch machines x and y are scheduleable. This means that the user controlled "+
            "algorithm will ask the user to schedule each of these machines.  "+
            "Assume that the user selected Rest for machine x and then it is "+
            "asked to schedule machine y.  Clicking Ask Again will tell the Job"+
            " Shop Simulator (JSS) to ask scheduling on machine x on the current time epoch again.\n\n"+
            "Random Buffer Scheduling Rule (RBSR) -\n"+
            "At any scheduling epoch, the available buffer are drawn put in a pool "+
            "and a random buffer is selected.\n\n"+
            "Proportional Random Buffer Scheduling Rule (PRBSR) -\n"+
            "The same as RBSR but the buffers are drawn according to a "+
            "distribution that is based on the initial number of jobs "+
            "on each route.  Buffers from routes with "+
            "more jobs, are given a higher probability.\n\n"+
            "Random Job Scheduling Rule (RJSR) -\n"+
            "The job to be scheduled at each machine is selected at random (instead of the buffer being selected).\n\n"+
            "FBFS (First Buffer First Serve) -\n"+
            "In any machine with buffers (r1,o1), (r2,o2).  "+
            "The buffer with the smaller o is schedule.  "+
            "If there is a tie than the buffer with the smaller route is scheduled.\n\n"+
            "LBFS (Last Buffer First Serve) -\n"+
            "The opposite of FBFS.\n\n"+
            "Makespan FIA (Fluid Imitation Algorithm) -\n"+
            "This algorithm imitates the optimal fluid draining"+
            " solution by scheduling in a manner that tries to"+
            " ensure that the real state of the shop is similar to the fluid state. \n\n"+
            "Dai And Weiss Makespan Fluid Algorithm -\n"+
            "While this algorithm is not fully implemented (it does"+
            " not complete), you may still use it to see what a nice cyclic schedule"+
            " looks like.  It first creates safety stocks and then works in clean cycles.\n\n";
}

