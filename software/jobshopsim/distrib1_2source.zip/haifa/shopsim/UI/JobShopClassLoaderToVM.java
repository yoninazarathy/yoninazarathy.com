package haifa.shopsim.UI;

import haifa.shopsim.*;
import haifa.shopsim.lab.*;
import haifa.shopsim.fastkernel.*;
import haifa.shopsim.UI.*;
import haifa.shopsim.UI.shopanim.*;

import eduni.simdiag.*;

/**Loads some of the classes to the VM at one shot, this way
 *when the classes are first called, execution is faster.
 *@version 1.1
 */
public class JobShopClassLoaderToVM {

    public JobShopClassLoaderToVM() {
        try{
            String hs = "haifa.shopsim.";

            Class.forName(hs+"Operation");
            Class.forName(hs+"ShopAlgorithm");
            Class.forName(hs+"ShopCommand");
            Class.forName(hs+"ShopData");
            Class.forName(hs+"ShopAlgorithm");
            
            String hsu= "haifa.shopsim.UI.";
            Class.forName(hsu+"GUIAlgorithm");
            Class.forName(hsu+"StateTable");
            Class.forName(hsu+"ShopTraceMaker");
            Class.forName(hsu+"GUIforComputerAlgorithm");
            
            String hsua = "haifa.shopsim.UI.shopanim.";
            Class.forName(hsua+ "JobShopGraphics");
            Class.forName(hsua+ "MachineAnimIcon");
            Class.forName(hsua+ "RouteAnimIcon");
            Class.forName(hsua+ "RouteEndAnimIcon");
            Class.forName(hsua+ "RouteStartAnimIcon");
            Class.forName(hsua+ "ShopAnim");
            Class.forName(hsua+ "SpotInMatrix");
            
            String hsf = "haifa.shopsim.fastkernel.";
            Class.forName(hsf+ "FastShopRun");
            Class.forName(hsf+ "EventQ");
            
            String es="eduni.simdiag.";
            Class.forName(es+ "Diagram");
            Class.forName(es+ "Entries");
            Class.forName(es+ "Entry");
            Class.forName(es+ "Event");
            Class.forName(es+ "TimingDiagram");
        }catch(Exception e){
            System.err.println(e);
        }
    }

}