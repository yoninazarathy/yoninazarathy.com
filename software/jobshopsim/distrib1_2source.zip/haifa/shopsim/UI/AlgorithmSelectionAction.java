package haifa.shopsim.UI;

import haifa.shopsim.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**This class implements an action that occurs when a new algorithm is selected.
	The action first stops the simulation if it is running. It then removes the
	simulation and gc's what it can. A new algorithm is then created.<P>
	The class is abstract in the sense of the allocateAlgorithm method. It is best
	if this class be extended by an anonymous inner class within listeners such that
	the allocateAlgorithm method is extended and allocates the proper algorithm.<P>
	This design prevents allocating all of the available algorithms at start up.
 *
 * @author  Yoni
 * @version 1.1
 */
abstract class AlgorithmSelectionAction extends AbstractAction{

            MainGUI mainGUI;
		/** A reference to the shopAlgorithm which this class handles.*/
		private ShopAlgorithm shopAlgorithm;
                    
                private int index;           
                
		/**The constructor uses an algorithm name.*/
		AlgorithmSelectionAction(MainGUI mainGUI_, String algName, int index_){
			super(algName);
                        mainGUI=mainGUI_;
                        index = index_;
		}

		/**This method is to be overriden by implementations such that it allocates
		the desired algorithm and returns a reference.*/
		abstract public GUIAlgorithm allocateAlgorithm();

		/**Does what is specified at the class explanation above.*/
		public void actionPerformed(ActionEvent ae){
                        mainGUI.lastAsa=this;
                        mainGUI.lastAe=ae;
		     	mainGUI.currentAlgorithm = allocateAlgorithm();
                        JPanel currentAlgorithmPanel = (JPanel)mainGUI.currentAlgorithm;
                        currentAlgorithmPanel.setPreferredSize(new Dimension(1500,150));
                        mainGUI.algPanel.removeAll();
			mainGUI.algPanel.add(currentAlgorithmPanel,BorderLayout.CENTER);
                        
                        int prevState= mainGUI.state;
                         mainGUI.fixAlgSelectedState();
                         if(prevState==mainGUI.FINISHED_STATE)
                             mainGUI.state=mainGUI.FINISHED_STATE;
                         //((JMenuItem)algorithmMenu.getItem(index)).setEnabled(false);
			mainGUI.mainPanel.updateUI();
		}
}//END OF INNER CLASS
        