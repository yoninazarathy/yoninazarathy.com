package haifa.shopsim.UI;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

/**Action that brings up a speed control dialog.
 *@version 1.1
 */
class SpeedControlAction extends AbstractAction{
                MainGUI mainGUI;
                
		public SpeedControlAction(MainGUI mainGUI_){
			super("Speed Control Panel");
                        mainGUI=mainGUI_;
                         if(mainGUI.speedSlider==null)
                                setUpSpeedSlider();
		}
                
                void setUpSpeedSlider(){
                    mainGUI.speedSlider=new JSlider(); 
                    mainGUI.speedSlider.setSnapToTicks(true);
                    mainGUI.speedSlider.setPaintTicks(true);
                    mainGUI.speedSlider.setMinorTickSpacing(5);
                    mainGUI.speedSlider.setMajorTickSpacing(20);
                    mainGUI.speedSlider.setValue(50);
                    mainGUI.speedSlider.setPaintLabels(true);
                    mainGUI.speedSlider.addChangeListener(new ChangeListener(){
                        public void stateChanged(ChangeEvent e){
                            if(mainGUI.speedSlider==null)
                                setUpSpeedSlider();
                            if(mainGUI.shopViewUpdater!= null)
                                mainGUI.notifyAboutSpeed();
                        }
                    });
                }

                
		public void actionPerformed(ActionEvent ae){
                    if(mainGUI.speedSlider==null)
                        setUpSpeedSlider();
                    JPanel panel = new JPanel(new BorderLayout());
                    
                    panel.add(mainGUI.speedSlider,BorderLayout.CENTER);
                          JOptionPane optionPane= new JOptionPane(panel,
                                                                                    JOptionPane.PLAIN_MESSAGE);
                    JDialog dialog = optionPane.createDialog(mainGUI.mainPanel,"Speed Control");
                   dialog.setResizable(false);
                   dialog.show();
		}
	}//END OF INNER CLASS         
        
