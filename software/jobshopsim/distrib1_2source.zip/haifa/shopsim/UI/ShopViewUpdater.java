package haifa.shopsim.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import haifa.shopsim.*;
import haifa.shopsim.fastkernel.*;
import java.util.*;

/**This class is designed to pace information between the simulation engine and the graphics components: animation, table, gant chart, etc..
 <P>
 It allows registration of a shopTraceMaker (that actually passes all of the event objects to the gant chart, and it also allows registration of the
 ShopChangeListeners (these all get time moved events). This means, that except for the gant chart that gets the info though the shop trace maker,
 the other components do not actually get the full information, they rather get TimeMovedEvents. That tell them to update from the shop
 state (which they have refernces to ).
 *<P>
  <P>
 The GUI application controlls this class by using the setRawSpeed() method.  The GUI is to set a speed value between 0 and 100. 0 being the 
 slowest and 100 the fastest.
 *@version 1.1
 */
public class ShopViewUpdater implements ShopChangeListener{

        /**The ShopViewUpdater alwasy sleeps for this time between updates so that the GUI may breath.*/
        protected static final long MANDETORY_SLEEP_TIME=200;
    
        /**Time that shop view updater allows between two events without "forcing" an update of the GUI*/
        protected static final long MILLS_LAST_EVENT=600;
    
        /**The maximal number of appropriate events that are skipped (when rawSpeed=100).*/
        protected static final long MAX_EVENT_SKIP=400;
        
        /**The maximal sleep time between GUI updates (when rawSpeed=0)*/
        protected static final int MAX_SLEEP=2000;
        
        /**Value of 0,...,100, the rawSpeed value recieved from the GUI*/
        protected int rawSpeed;
    
        /**A reference to the shopTrace Maker, this object is asked to send a display trace whenever the other listeners are modified.*/
        protected ShopTraceMaker shopTraceMaker;
        
	/**List of listeners (anim, table, etc...). All these listeners do not get the full events, they rather get time moved events.*/
	protected ArrayList listenerList;

	/**Refrence to the patient shop run object.*/
	protected ThreadFastShopRun threadFastShopRun;
        
        /**Counts the number of shopChangeEvents that occured since the last time the listeners and gantt were updated.*/
        protected int eventCounter;
        
        /**When the rawSpeed>50 this counts the number of appropriate events that are to occur before the shop is updated.*/
        protected int maxEventCount;
       
        
        /**Stores the time of the last event recived from the ShopSimulation.*/
        protected double lastEventTime;

        /**Stores the real world time (in millis) since the last time the system was updated.*/
        protected long lastUpdateTimeMillis;
        
        /**The time to sleep between appropriate event updates (when raw speed is less than 50).*/
        protected long sleepTime;
        
        /**Creates a ShopViewUpdater with a given shopTraceMaker.*/
	public ShopViewUpdater(ShopTraceMaker shopTraceMaker_){
            listenerList=new ArrayList();
            shopTraceMaker=shopTraceMaker_;
	}

        /**Add a listener, a ShopChangeListener that will recieve TimeMovedEvents.*/
        public void addShopChangeListener(ShopChangeListener sce){
          listenerList.add(sce);  
        }
        
        /**Set the rawSpeed (between 0 and 100)*/
        public  void setRawSpeed(int rawSpeed_){
            if(rawSpeed<0 || rawSpeed>100)
                throw new IllegalArgumentException("Raw speed should be an int in the range [0,100]");
            rawSpeed=rawSpeed_;
            if(rawSpeed<50){//set sleepTime
                sleepTime= (int)((50-rawSpeed) *(MAX_SLEEP/50.0));
            }else{//set maxEventCount
                maxEventCount=(int)((rawSpeed-50)*(MAX_EVENT_SKIP/50.0));
            }
        }

	/**Called by the ShopSimulatiom (in this manner it passes a shop change event). The behaviour is as follows:
         *<P>
         *<ul>
         *<li>When the rawSpeed is less than 50 a sleep is imposed, for a duration between MAX_SLEEP and 0 relative to the value of the rawSpeed.<P>
         *<li>When the rawSpeed is 50 the GUI is notified about every appropriate event as it occurs. (By appropriate event, we mean an event that 
         *has a bigger simulation time than the previous event that was sent.)
         *<li>When the rawSpeed is above 50, a number between 0 and MAX_EVENT_SKIP of appropriate event notifications are skipped.
         *</ul>
         *Events that arrive after a time of MILLS_LAST_EVENT since that lastUpdateTimeMillis are automatically thrown to the listeners (and gantt is displayed).
         *This is so when the user "steps" through events (not clicking step faster than MILLS_LAST_EVENT), the GUI updates according to the steps. Note that in this
         *case all events are passed, not just appropriate events.
         *If the event recieved is a ShopStartedEvent or a ShopFinishedEvent, the GUI is always immidaitly updated.
         **/
	public void shopChanged(ShopChangeEvent sce){
            double simTime=sce.getTime();
            
            if(lastUpdateTimeMillis+MILLS_LAST_EVENT<System.currentTimeMillis()){//this means that quite some time passed since last event so update anyway
                update(simTime);
                return;
            }
            if(sce instanceof ShopFinishedEvent || sce instanceof ShopStartedEvent){//if shop finished or shop started
                update(simTime);
                return;
            }
            
            if(simTime == lastEventTime)//if simulation time has not moved there are no "appropriate" events
                return;//we have nothing to update
            
            if(rawSpeed<50){
                System.out.println("Sleeping for " + sleepTime);
                try{Thread.sleep(sleepTime);}catch(Exception e){}
                update(simTime);
                return;
            }else if(rawSpeed==50){//just update every event without sleeping
                update(simTime);
                return;
            }else{//update events every maxEventCount appropriate events.
             eventCounter++;
             if(eventCounter>maxEventCount)
                update(simTime);
                return;
            }
        }//END OF SHOPCHANGED METHOD
         
        /**Fires ShopTimeMovedEvents to all the listeners and tells the shopTraceMaker to display gantt. This method always sleeps for MANDETORY_SLEEP_TIME
         and this is to allow the GUI to breath.*/
        protected void update(double simTime){
            final double f_time=simTime;
            lastUpdateTimeMillis=System.currentTimeMillis();
            try{
                try{Thread.sleep(MANDETORY_SLEEP_TIME);}catch(Exception e2){}
                SwingUtilities.invokeAndWait(new Runnable(){
                    public void run(){
                        Iterator it = listenerList.iterator();
                        while(it.hasNext())
                            ((ShopChangeListener)it.next()).shopChanged(new ShopTimeMovedEvent(this,f_time));
                        shopTraceMaker.sendDisplayTrace();
                   }
                });
                eventCounter=0;
            }catch(Exception e){
                System.out.println("Caught " + e + " in invokeAndWait");
            }
            
        }//end of update method
}//END OF CLASS