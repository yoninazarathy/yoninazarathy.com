package haifa.shopsim.UI;

import javax.swing.*;
import java.awt.*;
import java.util.*;

/**This class implements an animation that may be started, stopped, and killed.  It's speed may
 *also be set.*
 *@version 1.1
 */
public class BusyAnimation extends JPanel implements Runnable{
	int x1,y1;
	int x2,y2;

	Thread t;

        public int sleep;
        
	final int MIN_DELAY = 100;
	final int MAX_DELAY = 900;

	private boolean animating;

	private boolean pause;
        private boolean showing;

	Random random = new Random((int)(Math.random()*10000));
		//set this seed so that two instances of this class that are
		//created toghether will not have the same seed

        
        public void setSpeed(int speed){
            sleep=  (int)(( ((100.0f-speed)/100f)*MAX_DELAY + 1.0f*speed*MIN_DELAY/100f  )) ;
           // System.out.println("value of sleep set to : " + sleep);
        }
        
	public void start(){
		animating = true;
                showing = true;
		t = new Thread(this);
		t.start();
	}

	public void stop(){
		animating = false;
	}

	public void step(){
		nextLine();
                showing=true;
		repaint();
	}

	public BusyAnimation(){
		setBackground(Color.pink);
		setPreferredSize(new Dimension(100,40));
	}

        public void reset(){
            showing=false;
            animating=false;
            repaint();
        }
        
	private void nextLine(){
	        int h = getHeight();
		int w = getWidth();
		if(h < 1 || w < 1)
			return;
		x1 = random.nextInt(w);
		x2 = random.nextInt(w);
		y1 = random.nextInt(h);
		y2 = random.nextInt(h);
	}

	public void run(){
		while(animating){

                        
			try{Thread.sleep((int)sleep);}catch(InterruptedException e){}
			nextLine();
			repaint();
		}
	}

	public void paint(Graphics g){
		super.paint(g);
                if(showing)
		    g.drawLine(x1,y1,x2,y2);
	}

}