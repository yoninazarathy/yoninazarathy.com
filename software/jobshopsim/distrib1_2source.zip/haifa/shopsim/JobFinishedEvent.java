package haifa.shopsim;

import java.util.*;

/**Signifies that a job finished it's processing in the job shop.
 *@version 1.1
 */
public class JobFinishedEvent extends ShopChangeEvent{
	
        /**The route on which the job finished.*/
	private int routeNumber;

        /**Constructor.*/
	public JobFinishedEvent(    Object source,
                                                        double time,
							int routeNumber_){
		super(source,time);
		routeNumber = routeNumber_;
	}

	public String toString(){
		return super.toString() + " route Number:"+ routeNumber;
	}

	public int getRouteNumber(){
		return routeNumber;
	}
}//END OF CLASS