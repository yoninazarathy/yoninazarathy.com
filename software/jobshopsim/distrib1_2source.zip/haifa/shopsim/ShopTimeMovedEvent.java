package haifa.shopsim;

import java.util.*;

/**This event simply signifies that the simulation time moved.
 @version 1.1
 */
public class ShopTimeMovedEvent   extends ShopChangeEvent {

    /** Creates new ShopTimeMovedEvent */
    public ShopTimeMovedEvent(Object source, double time){
		super(source,time);
	}
}//END OF CLASS