package haifa.shopsim;

import java.util.*;
import haifa.global.Debug;


/**This interface is implemented by classes that summrise info regarding the 
 state of the job shop.  It is the ShopState that is used
 by ShopAlgorithms to make scheduling decisions. A shopstate allows to register
 ShopChangeListeners to it and informs them of changes whenever 
 there is a state in the shop.<P>
 *Note that some methods have to do with the dynamic (changing) state of the 
 shop, such as getFreeMachines(), yet other method have
 *to do with the job shop problem instance for example: getInitialNr().
 *@version 1.1
 */
 public interface ShopState{

	/**Returns the time as registered with the state.*/
	public double getTime();

	/**Returns an array of all of the busy machines at the current time. (Machines are numbered starting at 1).*/
	public int [] getBusyMachines();

        /**Returns an array of all of the free machines at the current time.(Machines are numbered starting at 1).*/
        public int [] getFreeMachines();
        
	/**Returns a collection of the schedulable operations. (This is a collection of operation objects).*/
	public Collection getSchedulableOperations();

        /**Returns a collection of the schedulable operations for a specific machine. (This is a collection of operation objects).*/
        public Collection getSchedulableOperations(int machineNumber);
        
	/**Returns the total number of finished jobs.*/
	public int getTotalFinishedJobs();

	/**Returns the number of finsihed jobs on a particular route.*/
	public int getNumFinishedJobs(int route);

        /**Returns a Map whose keys are operation objects (meaning the queues waiting for each opeartion).
         And whose values are Integer objects,
         *the values of the map say how many jobs are waiting in each operation Q.*/
	public Map getQMap();
        
        /**Returns a Map whose keys are operation objects (meaning the queues waiting for each opeartion). 
         And whose values are Integer objects,
         *the values of the map say how jobs are still to pass/complete operation (r,o).*/
        public Map getQPlusMap();
        
        /**Returns true if the machine has jobs upstream (as specified in the QPlusMap) and it's buffers are empty.*/
        public boolean isMachineStarved(int machineNumber);
        
        /**Returns true if the machine does not have anymore jobs left to do in the job shop.*/
        public boolean isMachineDone(int machineNumber);
        
        /**Returns an array of Operation objects, with a length the same as the number of machines in the shop. The i'th spot in this array
         *says what machine i+1 is doing.  If the spot is null, the machine is idle.  If the spot has an operation object the machine is doing that
         *operation.*/
        public Operation [] getMachineActivities();
        
/////////////////////////////////////////////////////////////////////////////////////////////////
//////METHODS HAVING TO DO WITH THE JOB SHOP INSTNACE/////////////
////////////////////////////////////////////////////////////////////////////////////////////////
        
        /**Returns the initial number of jobs on each route.*/
        public int [] getInitialNr();
        
        /**Uses the getInitialNr result and the means in the shop data to calcualte how much time a machine is expected to process.*/
        public double  getExpectedProcessingTime(int machine);

        /**Returns an array with the expectedProcssing time for each machine.*/
        public double [] getExpectedProcessingTimes();
        
        /**Returns the maximum of getExpectedProcessingTimes().*/
        public double getExpectedMachineLowerBound();

///////////////////////////////////////////////////////////
////////////////////////AUXILLARY METHODS//////////////////
///////////////////////////////////////////////////////////
        
	/**Register a listener to the state.*/
	public void addShopChangeListener(ShopChangeListener scl);
        
}//END OF INTERFACE