package haifa.shopsim;

import java.util.*;

/**A shop data implemintation that uses arrays. to store processing times and steps.
  * @version 1.1
 */
public abstract class AbstractShopData implements ShopData{

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////THE DATA ITSELF////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        
	/**Number of machines*/
	protected int I;

        /**Number of routes.*/
        protected int R;
        
	/**Array of routes, each route being an array of operations (an operation is specified by a machine index).*/
	protected int [][] routes;

	/**This is a ragged array of job durations per each step. The dimensions of this array
         are the same as the routes [][] array. It's values are the processing times in each
	step of the route. (maybe considered as means.)*/
	protected double [][] stepDurations;

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////METHODS OF THE INTERFACE/////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////
      
	/**Returns number of machines.*/
	public int getI(){
		return I;
	}

	/**Returns number of routes.*/
	public int getR(){
		return R;
	}

	/**Returns the total number of steps/classes/buffers (sum of Kr)*/
	public int getK(){
		try{
			int K=0;
			for(int r=1;r<=getR();r++)
				K+=getKr(r);
			return K;
		}catch(Exception e){
			System.err.println(e);
			System.exit(1);
			return 0;//needed for compoiler
		}
	}

	/**Returns the processing time of job of r, on step o of it's route.*/
	public double getXto(int t, int o) {
			return stepDurations[t-1][o-1];
	}
        
        public double getXto(Operation op){
                        return stepDurations[op.getRoute()-1][op.getStep()-1];
        }

	public int getKr(int r){
		try{
			return routes[r-1].length;
		}catch(ArrayIndexOutOfBoundsException e){
			throw new IllegalArgumentException();
		}
	}

	public int getMachine(Operation op){
		return routes[op.getRoute()-1][op.getStep()-1];

	}

	/**Returns a List of all operation in machine i. The elements of the list
	are arrays of ShopData.Operation instances*/
	public List getCi(int i){
		ArrayList list = new ArrayList();
		for(int r=0;r<routes.length;r++){//loop on all routes
			for(int k=0;k<routes[r].length;k++){//loop on operations of route r
				if(routes[r][k]==i)
					list.add(new Operation(r+1,k+1));
			}
		}
		return list;
	}

	/**Returns the number of operations in machine i.*/
	public int getSizeCi(int i){
		return getCi(i).size();
	}
        
	/**Returns a List of all ShopData.Operation instances in route r*/
	public List getRoute(int r){
		ArrayList list = new ArrayList();
		for(int o=0;o<routes[r-1].length;o++)//loop on all operations of route r
			list.add(new Operation(r,o+1));
		return list;
	}

	/**Ask is shop is a jobshop with a single route same as getR()==1*/
	public boolean isSingleRoute(){
		return routes.length==1;
	}

                
        public double getMeanOfMachine(int machineNumber){
            List ops = getCi(machineNumber);
            Iterator it = ops.iterator();
            double sum=0.0;
            while(it.hasNext()){
                Operation op = (Operation)it.next();
                sum+=getXto(op);
            }
            return sum;
        }

        
        public double getMeanOfRoute(int routeNumber){
            double sum=0.0;
            for(int o=0;o<stepDurations[routeNumber-1].length;o++)
                sum+=stepDurations[routeNumber-1][o];
            return sum;
        }
        
        
        public double getMaxRouteMean() {
            double max=-1.0;
            for(int r=1;r<=getR();r++){
                double  temp=getMeanOfRoute(r);
                 if(max<temp)
                    max=temp;
            }
            return max;
        }        
     
        public double getMaxMachineMean() {
            double max=-1.0;
            for(int i=1;i<=getI();i++){
                double  temp=getMeanOfMachine(i);
                 if(max<temp)
                    max=temp;
            }
            return max;
        }        


        /** Returns the time that the machine needs to spend working on jobs from the route. */
        public double getMeanOfRouteOnMacine(int machine,int route) {
            Iterator it= getCi(machine).iterator();
            double sum=0.0;
            while(it.hasNext()){
              Operation op = (Operation)it.next();
              if(op.getRoute()==route)
                  sum+=this.getXto(op);
            }
            return sum;
        }        

        /** Returns an array of length getR(), such that each element has getMeanOfRouteOnMachine(machine_,r)  for r=0,...,getR()-1. */
        public double[] getMeanOfRoutesOnMachine(int machine_) {
            double [] ret = new double[getR()];
            for(int r=0;r<getR();r++)
                ret[r]=getMeanOfRouteOnMacine(machine_,r+1);
            return ret;
        }
        
        /** Returns a matrix whose first dimenstion is the number of machines and second dimension is the number of routes.  The rows
        * of the matrix are getMeanOfRoutesOnMachine(i). */
        public double[][] getMeansOfRoutesOnMachines() {
            double [][]ret=new double[getI()][]; 
            for(int i=0;i<getI();i++)
                ret[i]=getMeanOfRoutesOnMachine(i+1);
            return ret;
        }
        
//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////OTHER METHODS/////////////////////////////////        
//////////////////////////////////////////////////////////////////////////////////////////
        
	/**Returns all info regarding jobshop in a displayable string*/
	public String toString(){
		StringBuffer sb=null;
	   try{
		sb = new StringBuffer();
		sb.append("Number of machines:" ).append(I).append("\n");
                sb.append("Number of routes:").append(R).append("\n");
                sb.append("Machine lower bound:").append(this.getMaxMachineMean()).append('\n');
                sb.append("Route lower bound:").append(this.getMaxRouteMean()).append('\n');
		for(int r=0;r<routes.length;r++){
			sb.append("Route # ").append(r+1).append(":");
					
			for(int k=0;k<routes[r].length;k++)
				sb.append(routes[r][k]).append(", ");
			sb.delete(sb.length()-2,sb.length()-1);
			sb.append("\n\tMeans: ");
                        for(int k=0;k<stepDurations[r].length;k++)
				sb.append(stepDurations[r][k]).append(", ");
			sb.delete(sb.length()-2,sb.length()-1);
			sb.append('\n');
		}
		
		for(int i=0;i<I;i++){
			sb.append("Classes in machine #").append(i+1).append(": ");
			sb.append(getCi(i+1)).append('\n');
		}
		sb.delete(sb.length()-1,sb.length()-1);
                sb.append('\n');
                
                sb.append("Durations of routes on machines:\n");
                for(int i=0;i<I;i++){
                    sb.append("Machine #").append(i+1).append(": ");
                    double []durr=getMeanOfRoutesOnMachine(i+1);
                    for(int r=0;r<durr.length;r++)
                        sb.append(durr[r]).append(", ");
                    sb.delete(sb.length()-2,sb.length()-1);
                    sb.append('\n');
                }
	   }catch(Exception e){
		   System.err.println(e);
		   System.exit(1);
	   }
		return sb.toString();
	}        
}//END OF CLASS