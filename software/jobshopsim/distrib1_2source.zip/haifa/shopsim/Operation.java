package haifa.shopsim;

/**This little class holds and identifies an operation in a job shop (route, step).
 *@version 1.1*/
public final class Operation{
    
                /**Used by the hash code generator.*/
                final private int ROUTE_ADD = 100;
                
                /**Used by the hash code generator.*/
                final private int STEP_ADD = 30;
		
                /**The route number.*/
                private int r;
                
                /**The step number.*/
		private int k;
                
                /**Constructs an operation on route r, and step k*/
		public Operation(int r_,int k_){r=r_;k=k_;}
		
                /**Returns a string of the operation.*/
                public String toString(){return "("+r+","+k+")";}

                /**Returns true if the operation equals obj*/
		public boolean equals(Object obj){
			Operation op = (Operation)obj;
			return op.r == r && op.k == k;
		}

                /**Returns a hash code based on the operation. It is designed so that for most operations within a small range, the hash code is unique*/
		public final int hashCode(){
			return (r+ROUTE_ADD)*(k+STEP_ADD);
		}

                /**Returns the route that identifies the operation.*/
		public final int getRoute(){
			return r;
		}

                /**Returns the step that identifies the operation.*/
		public final int getStep(){
			return k;
		}
	}//END OF CLASS