package haifa.shopsim;

import java.util.*;

/**Classes which implement this interface are sensitve to changes in the job shop.
 They are notfied about the changes via ShopChangeEvents.  Note that we are not
 really clear about how much info the classes make out of the ShopChangeEvents
 that they recieve and how much info they make out of the ShopState object
 (assuming they have a reference to it).
 @version 1.1
 */
public interface ShopChangeListener extends EventListener{
	public void shopChanged(ShopChangeEvent sce);
}