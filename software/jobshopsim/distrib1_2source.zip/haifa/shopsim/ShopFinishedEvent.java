package haifa.shopsim;

import java.util.*;

/**Signal that the shop finished all of the jobs.
 *@version 1.1
 */
public class ShopFinishedEvent extends ShopChangeEvent{
	public ShopFinishedEvent(Object source, double time){
		super(source,time);
	}
}//END OF CLASS