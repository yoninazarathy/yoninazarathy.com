package haifa.shopsim;

import haifa.shopsim.lab.*;

/**This is an interface for a Job Shop Simulation Scheme.
 *@version 1.1*/
public interface ShopSimulation {
    
        /**A simualation may not run past this time.*/
	public final double MAX_SIM_TIME = Double.MAX_VALUE;
     
        /**Registers an additional listener with the shop simulation that
         is notified everytime the job shop changes.*/
	public void addShopChangeListener(ShopChangeListener scl);

        /**Starts the job shop simulation.*/
        public void go();
        
        /**Set the ProblemSizeChooser.*/
        public void setProblemSizeChooser(ProblemSizeChooser problemSizeChooser_);
            
        /**Set the randomTimeMaker.*/
        public void setRandomTimeMaker(RandomTimeMaker randomTimeMaker_);
        
        /**Instructs the shop simulation to ask the algorithm for another 
         ShopCommand for the specific machine number
         *at the current simulation time.  This is needed when the algorithm 
         has issued a rest command for the machine
         *and when called again at the current time, it decides that it would 
         like the machine not to rest. Note that
         *the shop simulation object will do the asking again only at cases where
         the machine is scheduled as restiong. <P>
         *If the machine is not scheduled as resting at the current time, then 
         the shop simulation will not ask the algorithm
         *and will return a false value (other wise, it returns a true value).
         */
        public boolean askAgainAtCurrentTime(int machineNumber_);
}//END OF INTERAFCE