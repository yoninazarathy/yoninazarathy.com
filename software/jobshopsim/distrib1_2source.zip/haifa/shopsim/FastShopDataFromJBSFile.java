package haifa.shopsim;

import java.io.*;
import java.util.*;
import java.net.*;

/**Constructs a shop data based on the file format (.jbs).
 *@version 1.1
 */
public class FastShopDataFromJBSFile extends FastAbstractShopData{

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////CONSTRUCTORS/////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////        
        
        /**Does nothing.*/
        protected FastShopDataFromJBSFile(){}
    
	/**Read according to file format.*/
	public FastShopDataFromJBSFile(Reader reader) throws JobShopFileFormatException, IOException{

		StreamTokenizer st = new StreamTokenizer(
								new BufferedReader(reader));

                st.commentChar('#');//set comment character

		if(st.nextToken()!=StreamTokenizer.TT_NUMBER)//adavance to number of machines
			throw new JobShopFileFormatException();
		I=(int)st.nval;

		if(st.nextToken()!=StreamTokenizer.TT_NUMBER)//advance to number of routes
			throw new JobShopFileFormatException();
		R = (int)st.nval;
			routes = new int[R][];
                        stepDurations = new double[R][];

		st.nextToken();//advance to Routes

		for(int r=0;r<R;r++){//read each route
			/*Read "Route" string*/
			if(st.ttype != StreamTokenizer.TT_WORD  ||
                        !st.sval.equalsIgnoreCase("Route")){
                            System.err.println(r);
                            System.err.println(st.sval);
                            System.err.println(st.nval);
				throw new JobShopFileFormatException(st.lineno());
                        }

			/*Read "Route" number*/
			if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException(st.lineno());
			int rnum=(int)st.nval-1;
			//now rnum is the index of the route that we should insert to routes[][]

			LinkedList ll = new LinkedList();//a linked list to contain steps
			while(true){//read steps into route
				if(st.nextToken()!=StreamTokenizer.TT_NUMBER)//when jobs in route are finished
					break;
				ll.add(new Integer((int)st.nval));
			}

			//put route into array
			routes[rnum]=new int[ll.size()];
			Iterator it = ll.iterator();
			for(int k=0;it.hasNext();k++)
				routes[rnum][k]=((Integer)it.next()).intValue();

			if(st.ttype != StreamTokenizer.TT_WORD  ||
				    !st.sval.equalsIgnoreCase("Means"))
				throw new JobShopFileFormatException(st.lineno());
                        
                        
                        stepDurations[rnum] = new double[ll.size()];

			for(int k=0;k<stepDurations[rnum].length;k++){
				st.nextToken();
                                 if(st.ttype!=StreamTokenizer.TT_NUMBER)
                                    throw new JobShopFileFormatException(st.lineno());
				stepDurations[rnum][k] = st.nval;
			}

                        st.nextToken();
		}//end of loop on routes
                
                setUpFastData();
	}//End of constructor that reads file
        
	/**For testing*/
	public static void main(String [] args)throws Exception{
		ShopData sd=null;
		try{
			sd = new FastShopDataFromJBSFile(new InputStreamReader(
												new FileInputStream(args[0])));
		}catch(ArrayIndexOutOfBoundsException e){
			System.err.println("give a file name as a first parameter");
			System.exit(1);
		}
		System.out.println("********** toString() of SHOP:");
		System.out.println(sd);
	}
}//END OF CLASS
