package haifa.shopsim;

import java.util.*;

/**Signifies that a machine finished processing a job. 
 Also hold information regarding the next action to be performed.
 *@version 1.1
 */
public class MachineFinishedEvent extends ShopChangeEvent{
	
        /**The machine that finished the processing.*/
        private int machineNumber;

	/**Has value of -1 if the next machine is a RouteEnd.*/
	private int nextMachineNumber;

        /**The operation that was just finished.*/
	private Operation finishedOperation;

	/**Has null value if the next operation is a route end.*/
	private Operation nextOperation;
        
        /**Constructor.*/
	public MachineFinishedEvent(	Object source, double time,
					int machineNumber_, int nextMachineNumber_,
					Operation finishedOperation_,
					Operation nextOperation_){
		super(source,time);
		machineNumber = machineNumber_;
		nextMachineNumber = nextMachineNumber_;
		finishedOperation = finishedOperation_;
		nextOperation = nextOperation_;
	}
        
        /**Smaller Constructor, leaves some values as null or 0.*/
	public MachineFinishedEvent(	Object source,
                                                                double time,
								int machineNumber_){
		super(source,time);
		machineNumber = machineNumber_;
	}

	public String toString(){
		return super.toString() + " machineNumber:" + machineNumber
		+" nextMachineNumber:" + nextMachineNumber + " finishedOperation:"+
		finishedOperation+ " nextOperation: " + nextOperation;
	}

	public int getMachineNumber(){
		return machineNumber;
	}

	public int getNextMachineNumber(){
		return nextMachineNumber;
	}

	public Operation getFinishedOperation(){
		return finishedOperation;
	}

	public Operation getNextOperation(){
			return nextOperation;
	}
}//END OF CLASS