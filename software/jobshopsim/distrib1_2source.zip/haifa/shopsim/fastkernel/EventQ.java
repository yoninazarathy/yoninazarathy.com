package haifa.shopsim.fastkernel;

/**This class keeps a record of the next events in the machine world that are to occur. 
 It is designed specfically for the job shop setting.
 An event is simply defined by a machine.
 The methods getNextTime() and getNextMachines 
 are to be used with care. The getNextTime method should be called before the getNextMachines method.  This is because the getNextTime 
 method does not alter the Q while the getNextMachines methods removes the next machines from the Q.
 @version 1.1
 */
public class EventQ {

    /**Points to the head event of the queue*/
    protected Event phead;
    
    /**Points to the tail event (highest time) of the queue.*/
    protected Event ptail;
    
    /**Stores how many events are currently in the queue.*/
    int numInQ;
       
    /** Creates new empty EventQ.*/
    public EventQ() {
    }
    
    
    /**Returns an array of the machine numbers of the next machines in the Q (machines with earliest time).A meachine may
     *appear several times in this array.
     The length of this array may often be 1.*/
    int [] getNextMachines(){
        if(phead==null){
            return null;//if Q is empty
        }
        if(phead.time==ptail.time){//if all times are identical
            int arr[] = new int[numInQ];
            for(int i=0;phead!=null;i++,phead=phead.pprev)
                arr[i]=phead.machineNumber;
            phead=ptail=null;
            numInQ=0;
            return arr;
        }
        
        double firstTime=phead.time;
        int count=0;//counts how many machines have the same time
        while(phead.time==firstTime){//must loop atleast once
            phead=phead.pprev;
            count++;
        }
     
        //at this point phead points to the first event with a higher time
        Event point=phead.pnext;//set point to point to first event with uniform time
        phead.pnext=null;
        int [] ret = new int[count];
        numInQ-=ret.length;
        while(point!=null){
          ret[--count]=point.machineNumber;
          point=point.pnext;
        }
      return ret;  
    }//END OF METHOD
    
    /**Returns the time of the next event in the Q. Returns -1.0 if the Q is empty.*/
    double getNextTime(){
        if(phead==null)
            return -1.0;
        else
            return phead.time;
    }
    
    /**Returns the earliest time that the machine is scheduled on or -1.0 if it is not scheduled.*/
    double getMachineTime(int number){
        Event point=phead;
        while(point!=null){
          if(point.machineNumber ==  number)
              return point.time;
          point=point.pprev;
        }
        return -1.0;
    }
    
    /**Schedules an event for a  machine to wake up at endTime.*/
    void scheduleMachine(int machine, double endTime){
        Event temp = new Event(machine,endTime);
        numInQ++;
     
        if(phead==null){//If Queue is empty
            phead=ptail=temp;
            return;
        }
        if(endTime<=phead.time){//If new event should go in head
            temp.pprev=phead;
            phead.pnext=temp;
            phead=temp;
            return;
        }
        if(ptail.time<=endTime){//if new event should go in tail
            temp.pnext=ptail;
            ptail.pprev=temp;
            ptail=temp;
            return;
        }
        //else the new event is somewhere in the middle start searching from tail
        Event point = ptail;
        while(endTime <point.time)
            point=point.pnext;
        //now the point points to the event past where we need to slide it in
        point.pprev.pnext=temp;
        temp.pprev=point.pprev;
        temp.pnext=point;
        point.pprev=temp;
    }//END OF METHOD
    
    /**Removes a machine from the EventQ. (Removes all event with current machine).*/
    public void removeMachine(int number){
        Event point = phead;        
        
        if(point==null)//if eventQ is empty
            return;
        
        //we do not enter this loop if there is a single event in the queue
        while(point.pprev!=null){//while there is atleast one event prior to this one in the queue
            if(point.machineNumber==number){//need to remove
                if(point.pnext==null){//if at head of queue
                    point.pprev.pnext=null;
                    phead=point.pprev;
                    point=phead;//advance to next
                    numInQ--;
                    continue;
                }
                //else
                point.pnext.pprev=point.pprev;
                point.pprev.pnext=point.pnext;
                numInQ--;
            }
            point=point.pprev;
        }//end of while loop
        
        //now handle last one
        if(ptail.machineNumber==number){
            if(numInQ==1){ 
                phead=ptail=null;
                numInQ=0;
            }else{
                ptail.pnext.pprev=null;
                ptail=ptail.pnext;
                numInQ--;
            }
        }
    }//END OF METHOD
    
    /**Removes all events of a machine from the EventQ which are before untilTime. (Removes all event with current machine).*/
    public void removeMachine(int number,double untilTime){
        Event point = phead;        
        
        if(point==null)//if eventQ is empty
            return;
        
        //we do not enter this loop if there is a single event in the queue
        while(point.pprev!=null){//while there is atleast one event prior to this one in the queue
            if(point.machineNumber==number && point.time< untilTime){//need to remove
                if(point.pnext==null){//if at head of queue
                    point.pprev.pnext=null;
                    phead=point.pprev;
                    point=phead;//advance to next
                    numInQ--;
                    continue;
                }
                //else
                point.pnext.pprev=point.pprev;
                point.pprev.pnext=point.pnext;
                numInQ--;
            }
            point=point.pprev;
        }//end of while loop
        
        //now handle last one
        if(ptail.machineNumber==number && ptail.time< untilTime){
            if(numInQ==1){ 
                phead=ptail=null;
                numInQ=0;
            }else{
                ptail.pnext.pprev=null;
                ptail=ptail.pnext;
                numInQ--;
            }
        }
    }//END OF METHOD    
    
    
    
    /**Generates string of all events starting at the head.*/
    public String toString(){
        StringBuffer sb = new StringBuffer("EventQ");
        sb.append("  size(").append(numInQ).append(")\n");
        Event point=phead;
        while(point!=null){
          sb.append(point);
          point=point.pprev;
        }
         return sb.toString();
    }//END OF toString() METHOD
    
    /**A node in the event Q.  pnext points to null if this is the head of the queue. pprev points to null if this is the tail of the queue.*/
    class Event{
        double time;
        int machineNumber;
        Event pnext;
        Event pprev;
        Event(int machineNumber_, double time_){
            machineNumber=machineNumber_;
            time=time_;
        }
        
        public String toString(){
          return "Event of machine " + machineNumber + " at time " + time +"\n";  
        }
    }//END OF INNER CLASS
    
    ////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////TESTING////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////
    
    private void testAdd(int machine, double time){
      System.out.println("\nADDING " + machine + " at " + time);
      scheduleMachine(machine,time);
        System.out.println(this);   
    }
    
    private void testRemove(int machine){
        System.out.println("\nREMOVING "+machine);
        removeMachine(machine);
            System.out.println(this);
    }
        /**For testing.*/
    private void testRemoveNext(){
      System.out.println("\nREMOVING NEXT MACHINES");
      int [] arr = getNextMachines();
        System.out.print(this);
        if(arr==null){
            System.out.println("removed null, Q is empty");
            return;
        }
            
        System.out.print("removed:");
      for(int i=0;i<arr.length;i++)
        System.out.print(arr[i]+ "  "); 
       System.out.println("");
    }
    
    /**For testing.*/
    public static void main(String [] args){
      EventQ eq = new EventQ();
      System.out.println("NEWLY CREATED QUEUE");
        System.out.println(eq);
      
        eq.testAdd(5,53);
        eq.testAdd(6,25);
        eq.testAdd(6,194);
        eq.testAdd(9,23);
        eq.testAdd(2,83);
        
        eq.testRemove(6);
      
        eq.testAdd(6,34);
        eq.testAdd(7,34);
       
        eq.testRemoveNext();
        eq.testRemoveNext();
        eq.testRemoveNext();
        eq.testAdd(7,53);
        eq.testAdd(7,1);
        eq.testRemove(7);
        eq.testRemoveNext();
        eq.testRemoveNext();
        eq.testAdd(3,67);
        eq.testAdd(3,67);
        eq.testAdd(4,23);
        eq.testRemove(3);
        
        eq.testAdd(1,0);
        eq.testAdd(2,0);
        eq.testAdd(3,0);
        
        eq.testRemoveNext();
        
        eq.testAdd(3,14);
        eq.testAdd(1,14);
        eq.testAdd(2,91);
        eq.testAdd(1,91);
        eq.testAdd(1,29);
        
    }//END OF MAIN METHOD (FOR TESTING)
}//END OF CLASS
