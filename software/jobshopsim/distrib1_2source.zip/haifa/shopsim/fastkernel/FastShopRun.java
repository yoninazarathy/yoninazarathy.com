package haifa.shopsim.fastkernel;

import haifa.shopsim.lab.*;
import haifa.shopsim.*;
import java.io.*;
import java.util.*;
import haifa.global.*;

/**This class implements both a ShopSimualtion and a ShopState. It is a single thread "primitive" simulation
of a job shop that does not keep information regarding the location of jobs. (It is called fast, because it is
much faster than the intutive-to-program ShopRun class found in haifa.shopsim.kernel package (only up to version 0.3 of this project).
 <P>
The FastShopRun is implemented by using an EventQ class.<P>
Note that this class also implements a ShopState.<P>
Listeners are to register to the FastShopRun using the addShopChangeListener() method.
 @version 1.1
 */
public class FastShopRun implements ShopSimulation, ShopState{

    /**Message log.*/
    protected PrintWriter log;

    /**The job shop data.*/
    protected ShopData shopData;

    /**The algorithm that is used for the run.*/
    protected ShopAlgorithm shopAlgorithm;

    /**The PostRunAction,  the doAction() method is called after every run of the shop.*/
    protected PostRunAction postRunAction;

    /**The problem size chooser.*/
    protected ProblemSizeChooser problemSizeChooser;

    /**The random time maker.*/
    protected RandomTimeMaker randomTimeMaker;

    /**A list of listeners that are notified whenever the state changes.*/
    protected ArrayList listeners = new ArrayList();

    /**Number of milliseconds between updates to log of '~' character showing that the simulation is running.*/
    protected final static long PROGRESS_STEP=30000;
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////ENTITIES THAT MAKE UP THE SHOP///////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**The EventQ*/
    protected EventQ eventQ;

    /**An array of machine objects.*/
    private Machine [] machines;

    /**An array of integers counting how many finished jobs are in each route.*/
    private int [] finishedJobs;

    /**The total number of finsihed jobs (equals the sum of finishedJobs)*/
    private int totalFinishedJobs;

    /**An array of references to the first buffer of each route. The length of this array is used
    to signify the number of routes.*/
    private Buffer [] firstBuffers;

    /**The system time*/
    protected double time;

    /**The number of busy machines.*/
    private int numBusyMachines;

    /**A map of the buffers where the keys are operations and the values are Integer objects.  This is used by the clients of the ShopState.
     Unlike the values of numInQ variables in the buffers and machines, the Integer values in the Qmap include jobs that are being
     processed.*/
    private HashMap Qmap;

    /**A map of the buffers where the keys are operations and the values are Integer objects.  This is used by the clients of the ShopState.
     The value assiciated with operation (r,o) is the number of jobs that on route r, that still hasn't completed operation (r,o).*/
    private HashMap QPlusMap;

    /**The start time of the last time the go() method was called.*/
    private long startTimeMillis;
    
    /**Stores the Nr[] array as it was defined by the problem size chooser.*/
    private int [] numSetJobs;

    /**The expected machine lower bound.*/
    private double expectedLowerBound;
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////CONSTRUCTORS///////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /** Creates new FastShopRun.*/
    public FastShopRun(ShopAlgorithm shopAlgorithm_,
					ShopData shopData_,
					PostRunAction postRunAction_,
					PrintWriter log_) {

                                         log=log_;
                                         shopAlgorithm=shopAlgorithm_;
                                         shopData=shopData_;
                                         postRunAction=postRunAction_;
                                         problemSizeChooser = new DefaultProblemSizeChooser(shopData);
                                         randomTimeMaker = new DefaultRandomTimeMaker();
                                         try{
                                            buildShop();
                                         }catch(Exception e){
                                            DoError.printAndQuit("building shop",e);
                                         }
                                         //log.println("FastShopRun created:" + this.toRichString());
    }//END OF CONSTRUCTOR

    /**Creates a new FastShopRun, setting the log to stdout. And the PostRunAction to null*/
    public FastShopRun(ShopAlgorithm shopAlgorithm_,
					ShopData shopData_
                                        ){

                                        log=new PrintWriter(System.out,true);
                                        shopAlgorithm=shopAlgorithm_;
                                        shopData=shopData_;
                                        problemSizeChooser = new DefaultProblemSizeChooser(shopData);
                                        randomTimeMaker = new DefaultRandomTimeMaker();

                                        try{
                                            buildShop();
                                        }catch(Exception e){
                                            DoError.printAndQuit("building shop",e);
                                        }
                                        //log.println("FastShopRun created:" + this.toRichString());
    }//END OF CONSTRUCTOR

    /**Auxillary method for the constructors. Sets up all of the data structures of the Shop.*/
    private void buildShop(){
        //log.println("Starting buildShop()");
        machines = new Machine[shopData.getI()];//allocate machine array
        HashMap tempOperationMap=new HashMap();
        Qmap=new HashMap();
        QPlusMap=new HashMap();

        for(int i=0;i<machines.length;i++){//loop on machines array and set up machines
            //log.println("Building machine "+(i+1));
            machines[i]=new Machine(i+1);
            machines[i].operationMap=new HashMap(shopData.getSizeCi(i+1));
            Collection col = shopData.getCi(i+1);

            Iterator it = col.iterator();
            while(it.hasNext()){//loop on all operations of machine i
                Operation op=(Operation)it.next();
                Buffer temp = new Buffer(op,machines[i]);
                temp.mean = shopData.getXto(op);
                machines[i].operationMap.put(op,temp);//put in operations map in machines
                Qmap.put(op,new Integer(-1));
                QPlusMap.put(op,new Integer(-1));
                    //the above map values are only tempory (reset when go() is called
                tempOperationMap.put(op,temp);//put in operations map of whole factory
            }
        }//end of for loop on all of machine array
        //log.println("Set up of machines in shop completed");

		firstBuffers = new Buffer[shopData.getR()];

        for(int r=0;r<firstBuffers.length;r++){//loop on all routes and sow them up
            List lst = shopData.getRoute(r+1);
            Iterator it = lst.iterator();

            firstBuffers[r]=(Buffer)tempOperationMap.get(it.next());
            Buffer buff = firstBuffers[r];
            while(it.hasNext()){//iterate over all of the jobs of the route
                 buff.nextBuffer=(Buffer)tempOperationMap.get(it.next());
                 buff=buff.nextBuffer;
            }
            buff.nextBuffer=null;

        }//end of for loop on all routes
    }//END OF METHOD


    /**This is a map where the keys are Integers for machine numbers and the values
     *are doubles that specify the time at which a machine was scheduled to rest.*/
    HashMap restingMap=new HashMap();//RRRRRRRRRRRRRRRRRR
    
    /**The last time during which the resting map was updated.*/
    double lastRestUpdateTime;
    
    
/////////////////////////////////////////
//////////THE SIMULATION METHODS  (THE BEEF IS HERE)/////////
/////////////////////////////////////////

    /**Start the simulation.*/
    public void go() {
        log.println("-------------------------------------------");
        startTimeMillis=System.currentTimeMillis();
        long nextTimeMillis=startTimeMillis+PROGRESS_STEP;
        
        try{
        	setUp();//prepare all data structures
        }catch(Exception e){
			  DoError.printAndQuit("setting up job shop",e);
        }
        log.println("Shop Run was set up ( "+((System.currentTimeMillis()-startTimeMillis)/1000) + " seconds).");
        log.println("Shop Started... with algorithm:"+ shopAlgorithm );
        //log.println("FAST SHOP RUN JUST BEFORE STARTING TO LOOP:"+this);
        try{
              int [] wakingMachines=null;
              ShopCommand sc=null;
outer:while(true){//loop untill no more events in Q
                    if(nextTimeMillis<System.currentTimeMillis()){//maybe time to show progresss to the unpatient
                        nextTimeMillis+=PROGRESS_STEP;
                        log.print("~");
                        log.flush();
                    }
                    double tempTime=eventQ.getNextTime();//update the time
                    if(tempTime==-1.0)
                        break;//if Q is empty
                    time=tempTime;
                    wakingMachines = eventQ.getNextMachines();
                        
                    
                    //log.println("Set a new simulation TIME: " + time);

                    //at this point the wakingMachines array has machineNumbers of the following types of machines:
                    //1) Machines which have just finished processing a job
                    //      1a)These may be machines with more jobs on the queue or...
                    //      1b)machines that had no jobs in their queues and are therefore not to be scheduled again at this time.
                    //2)  Machines which were resting (had jobs in their queues). This can be a result of a rest command
                    //          or the start of the simulation.
                    //3)   Machines which had no jobs in their queues but at this moment will get jobs which leave working machines (type 1).

                    //make sure that machines don't appear twice
                    wakingMachines=HaifaArrays.makeUniqueArray(wakingMachines);

                    try{
                        //update the state according to newly freed machines
                        updateMachines(wakingMachines);
                    }catch(Exception ee){
                        DoError.printAndQuit("updating from free machines",ee);
                    }

                    //the restingMachines array will store machines which got a rest command
                    //int [] restingMachines=new int[wakingMachines.length];
                    //int numRestingMachines=0;

                    //loop on all machines which are aviable for scheduling at the current time.
                    for(int i=0;i<wakingMachines.length;i++){
                        if(machines[wakingMachines[i]-1].numInQ>0){//only if there are jobs in the machine's queues
                            restingMap.remove(new Integer(wakingMachines[i]));//RRRRRRRRRRRRRRRRRRRRRRRRRRRR
                            if(lastRestUpdateTime<time){
                             restingMap=new HashMap();   
                            }
                            //log.println("RESTING MAP (last updated " + lastRestUpdateTime+"): "+restingMap);//RRRRRR
                            
                            sc = shopAlgorithm.whatNow(wakingMachines[i]);//ask algorithm for command
                            //note that the shopAlgorithm may have called an askAgainAtCurrentTime
                            //on some machines so the restingMap may change (decrease)
                            
                            //log.println("FastShopRun got this ShopCommand from algorithm: " + sc);
                            if(sc.isSchedule()){
                                try{
                                    performSchedulingCommand(sc);//perform the command
                                }catch(Exception ee){
                                    ee.printStackTrace(System.out);
                                    DoError.printAndQuit("performing scheduling command",ee,sc);
                                }
                            }
                            else if(sc.isRest()){
                                //if a machine is to rest, record it in the restingMachines array untill all machines are finished processing
                                //restingMachines[numRestingMachines]=sc.getMachine();
                                restingMap.put(new Integer(sc.getMachine()),new Double(time));//RRRRRRRRRRRRRRRRRR
                                lastRestUpdateTime=time;
                                //numRestingMachines++;
                                notifyListeners(new WillingRestStartedEvent(this,time,sc.getMachine()));
                            }else if(sc.isQuit())
                                break outer;//leave outer loop
                        }//and of if(there are jobs in the machine's queue)
                }//end of loop on all current free machines

                //now schedule all machines that chose to rest at the last time
                double lastTime=eventQ.getNextTime();
                lastTime =  (lastTime >=0.0 ? lastTime : time);//if eventQ was empty because all machines
                                                                                                                //decided to rest (then the time in the eventQ is -1.0)
                Iterator it = restingMap.keySet().iterator();
                
                while(it.hasNext()){
                    int mtr = ((Integer)it.next()).intValue();
                    //log.println("Scheduling resting machine " + mtr +
                                            //" to wake up at " + lastTime);
                    eventQ.scheduleMachine(mtr,lastTime);
                }

                /*for(int i=0;i<numRestingMachines;i++){
                    log.println("Scheduling resting machine " + restingMachines[i] +
                                            " to wake up at " + lastTime);
                    eventQ.scheduleMachine(restingMachines[i],lastTime);
                    
                }
                 numRestingMachines=0;
                 */
                
                 //log.println("EVENTQ:"+eventQ);
                 //log.println("END OF ITERATION OF OUTER WHILE LOOP");
            }//END OF  WHILE LOOP OF RUNNING JOB SHOP

            notifyListeners(new ShopFinishedEvent(this,time));
            log.println("\nOUT OF LOOP OF FAST SHOP RUN AT SIMULATION TIME " + time +
                                    "\n\tWITH " + getTotalFinishedJobs() + " TOTAL FINISHED JOBS"+
                                    "\n\tRUNNING TIME WAS " + ((System.currentTimeMillis()-startTimeMillis)/1000) + " SECONDS");
            if(postRunAction!=null)//if a postrunaction adapter exists
                postRunAction.doAction();
        }catch(Exception e){
            DoError.printAndQuit("runningShop",e);
        }
    }//END OF GO METHOD

    /**Take array of indexes of machines that came off the eventQ. Each such machine may have either just finished processing or
     *was resting (or resting because the simualtion has just started). The datastructures are updated accordingly.*/
    private void updateMachines(int [] wakingMachines){
        //log.println("Starting updateMachines " + HaifaArrays.toStringArray(wakingMachines));

        for(int i=0;i<wakingMachines.length;i++){
            Machine theMachine = machines[wakingMachines[i]-1];

            if(theMachine.processing==true && theMachine.expectedTime==time){//if the machine was busy untill now
                Buffer theNextBuffer=theMachine.procBuffer.nextBuffer;
                Operation finishedOp = theMachine.procBuffer.operationID;
                theMachine.processing=false;
                numBusyMachines--;
                if(theNextBuffer==null){//if this is last buffer in route
                    int route=finishedOp.getRoute();
                    //log.println("updating a job to finish on route " + route);
                    finishedJobs[route-1]++;
                    totalFinishedJobs++;
                    notifyListeners(new JobFinishedEvent(this,time,route));
                }else{//if this is not the last buffer in the route
                    theNextBuffer.numInQ++;
                    theNextBuffer.pmachine.numInQ++;
                    boolean nextBuffProcessing=theNextBuffer.pmachine.processing &&
                                                                                (theNextBuffer.pmachine.procBuffer==theNextBuffer);
                    Qmap.put(theNextBuffer.operationID,
                                        new Integer( theNextBuffer.numInQ+(nextBuffProcessing? 1 : 0)));
                }
                Qmap.put(finishedOp,new Integer(theMachine.procBuffer.numInQ));
                
                int oldQplus = ((Integer)QPlusMap.get(finishedOp)).intValue();
                QPlusMap.put(finishedOp,new Integer(oldQplus-1));
                //log.println("QPlusMap: "+QPlusMap);
                
                notifyListeners(new MachineFinishedEvent(this,time,wakingMachines[i]));
            }//END OF IF THE MACHINE WAS BUSY AND SHOULD NOW BE RESCHEDULED
        }//END OF FOR LOOP ON ALL wakingMachines
    }//END OF METHOD


    /**Changes the state of the shop accoring to the shop command.*/
    private void performSchedulingCommand(ShopCommand sc){
        Operation op = sc.getOperation();
        int machineNumber = sc.getMachine();
        Machine theMachine=machines[machineNumber-1];
        Buffer theBuffer=(Buffer)theMachine.operationMap.get(op);
        //log.println("In FastShopRun this is the machine: " + theMachine +
           //                         "\nand this is the buffer: "+theBuffer);

        //calculate the nextTime this machine is free and schedule the machine
        double nextTime = randomTimeMaker.getTime(theBuffer.mean)+time;

        theBuffer.numInQ--;
        theMachine.numInQ--;
        theMachine.processing=true;
        numBusyMachines++;
        theMachine.procBuffer=theBuffer;

        notifyListeners(new MachineStartedEvent(this,time,machineNumber,op));

       // log.println("removing machine " + machineNumber + " from eventQ (prior to "+nextTime+")");
        eventQ.removeMachine(machineNumber,nextTime);

        //log.println("Scheduling working machine " + machineNumber +" to finish at " + nextTime);
        eventQ.scheduleMachine(machineNumber,nextTime);
        theMachine.expectedTime=nextTime;

        if(theBuffer.nextBuffer!=null){


        //now see if we need to schedule the machine that gets the job
        //we "usually" should do that. We should not do it if the machine is working and due past the nextTime
        Machine theNextMachine =  theBuffer.nextBuffer.pmachine;
        double machineDueTime = eventQ.getMachineTime(theNextMachine.machineNumber);

        if(!(theNextMachine.processing && nextTime<machineDueTime) || machineDueTime==-1.0){
         // log.println("Scheduling non-processing machine " +
          //             theNextMachine.machineNumber +" to wakeup at " + nextTime);
           eventQ.scheduleMachine(theNextMachine.machineNumber,nextTime);
        }
        }
    }//END OF PERFROM COMMAND METHOD


    /**Sets up toward running the simulation.*/
    private void setUp(){
	   finishedJobs=new int[firstBuffers.length];
	   totalFinishedJobs=0;
            eventQ=new EventQ();//allocate the EventQ
            time=0.0;

            shopAlgorithm.reset();
                            expectedLowerBound=haifa.global.HaifaArrays.maxInArray(getExpectedProcessingTimes());
            
       for(int i=0;i<machines.length;i++)
           machines[i].numInQ=0;
       
            Iterator kit = Qmap.keySet().iterator();
       while(kit.hasNext())
           Qmap.put((Operation)kit.next(),new Integer(0));
    
       
            numSetJobs = problemSizeChooser.getNr();//get number of jobs in each route

            for(int r=0;r<firstBuffers.length;r++){//put jobs into elements of Simulation
                firstBuffers[r].numInQ=numSetJobs[r];//add jobs to buffers
                firstBuffers[r].pmachine.numInQ+=numSetJobs[r];//add jobs to machine
                Qmap.put(firstBuffers[r].operationID,new Integer(numSetJobs[r]));//set jobs in Qmap
            }
            
            for(int r=0;r<numSetJobs.length;r++){//loop on all routes and update QPlusMap
                Iterator it = QPlusMap.keySet().iterator();
                while(it.hasNext()){//Iterate over all of QPlusMap and only modify what is needed
                    Operation op=(Operation)it.next();
                    if(op.getRoute()==r+1)
                        QPlusMap.put(op,new Integer(numSetJobs[r]));
                }
            }//end of loop on all routes

            

        for(int i=0;i<machines.length;i++)//put all of machines with jobs in them in Q
            if(machines[i].numInQ>0)
                eventQ.scheduleMachine(i+1,0.0);

        notifyListeners(new ShopStartedEvent(this,time));
    }//END OF SETUP METHOD


    
        /**Instructs the shop simulation to ask the algorithm for another ShopCommand for the specific machine number
         *at the current simulation time.  This is needed when the algorithm has issued a rest command for the machine
         *and when called again at the current time, it decides that it would like the machine not to rest. Note that
         *the shop simulation object will do the asking again only at cases where the machine is scheduled as restiong. <P>
         *If the machine is not scheduled as resting at the current time, then the shop simulation will not ask the algorithm
         *and will return a false value (other wise, it returns a true value).
         */
        public boolean askAgainAtCurrentTime(int machineNumber){
            //log.println("askAgainAtCurrentTime("+machineNumber+") called.");
            //double time = shopState.getTime();
            Double mtime = (Double)restingMap.get(new Integer(machineNumber));
            if(mtime==null){
             //log.println("But machine " + machineNumber+ " is not scheduled to rest.");
             return false;
            }
            //log.println("The time " + machineNumber +" was sechudled to rest was " + mtime);
            if(mtime.doubleValue()==time){
                restingMap.remove(new Integer(machineNumber));
                eventQ.scheduleMachine(machineNumber,time);
                //log.println("Removed machine " + machineNumber +"  from resting map, now we have: " + restingMap);
            }else{
                log.println("Wierd ERROR, time does not match in askAgainAtCurrentTime()");
            }
        return true;
        }//END OF METHOD
    


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////SHOP STATE METHODS////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /** Returns the time as registered with the state. */
    public double getTime() {
        return time;
    }

    /** Returns a collection of all of the busy machines at the current time. */
    public int [] getBusyMachines() {
        int bm [] = new int[numBusyMachines];
        int j=0;
        for(int i=0;i<machines.length;i++)//loop on all machines and check who is busy
            if(machines[i].processing)
                bm[j++]=i+1;
        return bm;
    }

    /** Returns a collection of all of the free machines at the current time. */
    public int [] getFreeMachines() {
        int fm [] = new int[machines.length-numBusyMachines];
        int j=0;
        for(int i=0;i<machines.length;i++)//loop on all machines and check who is free
            if(!machines[i].processing)
                fm[j++]=i+1;
        return fm;
    }

    /** Returns a collection of the schedulable operations. */
    public Collection getSchedulableOperations() {
       		Collection opc = new ArrayList();
		Iterator it = Qmap.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry me = (Map.Entry)it.next();
			if(((Integer)me.getValue()).intValue()==0)
				continue;
			Operation op = (Operation)me.getKey();
			int machine = shopData.getMachine(op);
			if(machines[machine-1].processing==false)
				 opc.add(op);
		}
		return opc;
    }

    /** Returns a collection of the schedulable operations for a specific machine. */
    public Collection getSchedulableOperations(int machineNumber) {
                Collection opc = new ArrayList();
		Iterator it = Qmap.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry me = (Map.Entry)it.next();
			if(((Integer)me.getValue()).intValue()==0)
				continue;
			Operation op = (Operation)me.getKey();
			int machine = shopData.getMachine(op);
                        if(machine !=machineNumber)
                            continue;
			if(machines[machine-1].processing==false)
				 opc.add(op);
		}
		return opc;
    }

    /** Returns the total number of finished jobs. */
    public int getTotalFinishedJobs() {
        return totalFinishedJobs;
    }

    /** Returns the number of finsihed jobs on a particular route. (Route index starting at 1)*/
    public int getNumFinishedJobs(int route) {
        return finishedJobs[route-1];
    }

    /**Returns true if the machine does not have anymore jobs left to do in the job shop.*/
    public boolean isMachineDone(int machineNumber){
	Iterator it = QPlusMap.entrySet().iterator();
	while(it.hasNext()){//loop on all operations of shop
	    Map.Entry me = (Map.Entry)it.next();
	    Operation op = (Operation)me.getKey();
	    int machine = shopData.getMachine(op);
            if(machine !=machineNumber)//if operation is not of machine continue
                            continue;
            int qPlus=((Integer)me.getValue()).intValue();
            if(qPlus>0)//if there are more jobs pending machine is not done
                return false;
        }
        return true;//because no jobs were found pending
    }
    
        /**Returns true if the machine has jobs upstream (as specified in the QPlusMap) and it's buffers are empty.*/
        public boolean isMachineStarved(int machineNumber){
                List ops = shopData.getCi(machineNumber);
                Iterator it = ops.iterator();
	        
	        while(it.hasNext()){//loop on all operations of shop
	            Operation op = (Operation)it.next();
                    int q=((Integer)Qmap.get(op)).intValue();
                    if(q>0)
                        return false;
                    int qPlus=((Integer)QPlusMap.get(op)).intValue();
                    if(qPlus>0)
                        return true;
                }//END OF WHILE LOOP
                return false;
        }//END OF METHOD
    
    
    /**Returns a Qmap. Where the keys are operation objects and the values are Integer objects saying how many jobs are in each Q.
     *The Qmap Integers include jobs that are in process (they are supposidly processed by the machine while they are still in the Q.*/
    public Map getQMap() {
        return Qmap;
    }
    
    /**Returns a Map whose keys are operation objects (meaning the queues waiting for each opeartion). And whose values are Integer objects,
    *the values of the map say how jobs are still to pass/complete operation (r,o).*/
    public Map getQPlusMap(){
        return QPlusMap;
    }

    /**Returns the size of the shop as it was set by the problem size chooser.*/
    public int [] getInitialNr(){
        return numSetJobs;
    }    
    
    /**Uses the getInitialNr result and the means in the shop data to calcualte how much time a machine is expected to process.*/
    public double  getExpectedProcessingTime(int machine){    
        double [] marray= shopData.getMeanOfRoutesOnMachine(machine);
        int Nr[] = problemSizeChooser.getNr();
        double exp=0.0;
        for(int r=0;r<marray.length;r++)//loop on all routes and sum up time on machine
            exp+=marray[r]*Nr[r];
        return exp;
    }
    
    /**Returns an array with the expectedProcssing time for each machine.*/
    public double [] getExpectedProcessingTimes(){
      double [] ret = new double[shopData.getI()];
      for(int i=0;i<ret.length;i++)
          ret[i]=getExpectedProcessingTime(i+1);
      return ret;
    }
        
    
    
    /**Returns the maximum of getExpectedProcessingTimes().*/
    public double getExpectedMachineLowerBound(){
     
        return expectedLowerBound;
    }
    
    
            /** Returns an array of Operation objects, with a length the same as the number of machines in the shop. The i'th spot in this array
             * says what machine i+1 is doing.  If the spot is null, the machine is idle.  If the spot has an operation object the machine is doing that
             * operation. */
            public Operation[] getMachineActivities() {
                Operation [] ops = new Operation[machines.length];
                
                for(int i=0;i<ops.length;i++){
                    if(machines[i].processing)
                        ops[i]=machines[i].procBuffer.operationID;
                }
                return ops;
            }                
    

	///////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////AUXILLARY METHODS/////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////////////////////
    
	    public String toString(){
	      return "Fast Shop Run at time " + time;
	    }

	    /**Returns a rich represntation of the shop. Good for debugging.*/
	    public String toRichString(){
	        StringBuffer sb = new StringBuffer("FAST SHOP RUN:\n");
	        sb.append("time:").append(time).append('\n');
	        sb.append("Machines:\n");
	        for(int i=0;i<machines.length;i++)
	            sb.append(machines[i]).append('\n');
	        sb.append("firstBuffers:");
	        for(int i=0;i<firstBuffers.length;i++)
	            sb.append(firstBuffers[i].operationID).append(" ");
	        sb.append("\nroutes:\n");
	        for(int i=0;i<firstBuffers.length;i++){//loop on all first buffers
	            Buffer buff = firstBuffers[i];
	            while(buff!=null){
	                sb.append(buff.operationID).append("  ");
	                buff=buff.nextBuffer;
	            }
	            sb.append('\n');
	        }

	        sb.append("EventQ:");
	        sb.append(eventQ);
	        sb.append("\nEND OF FAST SHOP RUN OBJECT");
	        return sb.toString();
	    }

	    /**Registers an additional shop change listner.*/
	    public void addShopChangeListener(ShopChangeListener scl) {
	        listeners.add(scl);
	    }

	    /**Iterate over all of the listeners and send the the ShopChangeEvent.*/
	    protected void notifyListeners(ShopChangeEvent sce) {
	        Iterator it = listeners.iterator();
	        while(it.hasNext()){
	          ((ShopChangeListener)(it.next())).shopChanged(sce);
	        }
	    }

	    /**Set the ProblemSizeChooser.*/
	    public void setProblemSizeChooser(ProblemSizeChooser problemSizeChooser_){
	        problemSizeChooser=problemSizeChooser_;
	        problemSizeChooser.setData(shopData);
                expectedLowerBound=haifa.global.HaifaArrays.maxInArray(getExpectedProcessingTimes());
	    }
            
            /**Set the randomTimeMaker.*/
            public void setRandomTimeMaker(RandomTimeMaker randomTimeMaker_){
              randomTimeMaker=randomTimeMaker_;  
            }



    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////INNER CLASSES//////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**This class represents a queue entity. There is one such class for each operation in the job shop.*/
    private class Buffer{

       /**A reference to the next buffer in the route, it is null if this is the last buffer in the route.*/
      Buffer nextBuffer;

      /**A reference to the machine that has this buffer.*/
      Machine pmachine;

      /**The processing time.*/
      double mean;

      /**The number of jobs waiting in this buffer. (Not counting jobs being processed.*/
      int numInQ=0;

      /**The operation that identifies this buffer.*/
      Operation operationID;

       /**Constructor takes an operation.*/
        Buffer(Operation operationID_,Machine pmachine_){
            operationID=operationID_;
            pmachine=pmachine_;
        }

        /**Good for debugging.*/
        public String toString(){
          StringBuffer sb = new StringBuffer("(Buffer of operation ");
          sb.append(operationID).append(")").append("  numInQ:").append(numInQ);
          sb.append("  mean:").append(mean).append("\n");;

          return sb.toString();
        }
    }//END OF INNER CLASS


    /**This class represents a machine in the job shop.*/
    private class Machine{

      /**A map to all of the operations/buffers/classes in the machine. The key is an operation and the value is a Buffer object.*/
      HashMap operationMap;

      /**The number of the machine.*/
      int machineNumber;

      /**True if the machine is currently working on a job.*/
      boolean processing;

      /**The time at which the machine is due to finish processing.  The value is only relevant if processing == true.*/
      double expectedTime;

      /**True if the machine is scheduled in the eventQ as an empty machine. False whenever a machine is read from the eventQ.*/
      boolean scheduledEmpty;

      /**Points to the buffer that is currently processing, or null if processing is false.*/
      Buffer procBuffer;

      /**Counts the total number of jobs waiting in Queue's for the machine. (not counting jobs being processed.*/
      int numInQ;

      /**Constructor.*/
       Machine(int machineNumber_){
            machineNumber=machineNumber_;
            operationMap=new HashMap();
        }

        /**Good for debugging.*/
        public String toString(){
          StringBuffer sb = new StringBuffer("Machine:");
          sb.append(machineNumber).append("Processing:").append(processing);
          sb.append(" ScheduledEmpty:").append(scheduledEmpty).append("   has operations:").append(operationMap);
          return sb.toString();
        }
    }//END OF INNER CLASS
}//END OF CLASS