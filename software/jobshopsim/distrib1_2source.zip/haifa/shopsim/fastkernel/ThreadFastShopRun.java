package haifa.shopsim.fastkernel;

import haifa.shopsim.*;

import java.io.*;

/**Implements a FastShopRun on it's own thread.  This is usefull for working with GUI.
 @version 1.1*/
public class ThreadFastShopRun extends FastShopRun implements Runnable {

    /**The thread.*/
    private Thread t;
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////CONSTRUCTORS///////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /** Creates new FastShopRun.*/
    public ThreadFastShopRun(ShopAlgorithm shopAlgorithm_,
					ShopData shopData_,
					PostRunAction postRunAction_,
					PrintWriter log_) {
                                         super(shopAlgorithm_,shopData_,postRunAction_,log_);
    }//END OF CONSTRUCTOR
    
    /**Creates a new FastShopRun, setting the log to stdout.*/
    public ThreadFastShopRun(ShopAlgorithm shopAlgorithm_,
					ShopData shopData_){
					super(shopAlgorithm_,shopData_);
    }//END OF CONSTRUCTOR
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////SIMULATION CONTORL METHODS///////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public void go(){   
      t=new Thread(this);
      t.start();
    }

    public void kill(){
      t.stop();
      log.println("SHOP RUN WAS KILLED DURING EXECUTION: ");
    }
    
    public void run() {
        try{
            super.go();
        }catch(Exception e){
          e.printStackTrace(log);
        }
    }
    
    int counter;
    /**Iterate over all of the listeners and send the the ShopChangeEvent.*/
    protected void notifyListeners(ShopChangeEvent sce) {
        counter++;
        if(counter==30){
          counter=0;
          try{Thread.sleep(50);}catch(Exception e){}
        }
        super.notifyListeners(sce);
    }
}//END OF CLASS