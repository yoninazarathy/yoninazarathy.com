package haifa.shopsim;

/**This interface is used for it's sole method, doAction(). 
 *It should be implemented by a host of a shop simulation.  A shop simulation knows
 *to call this method after a simulation run is finished.
 *@version 1.1*/
public interface PostRunAction{
    
        /**Does whatever is needed for the specific framework.*/
	public void doAction();
}