package haifa.shopsim;

import java.util.*;

/**This is an interface for the datastrucute class that contains the data
 evlevant to a specific jobshop problem. 
The formulation of the problem is as following:<P>
i=1,....,I machines<BR>
r=1,....,R routes<BR>
for each route r, there exist steps (1,r),....,(1,Kr). there is a machine for
 each of these steps.<BR>
The duratin of each step for each job is Xr,o r = 1,....,R being the route,
  = 1,...,Kr being the step on the route.<P>
<P>
 *Note that the duration may be taken to be the mean duration.<P>
*
 *@version 1.1
 */
public interface ShopData{

        /**Returns number of machines.*/
	public int getI();

	/**Returns number of routes.*/
	public int getR();

	/**Returns the total number of steps/classes/buffers (sum of Kr)*/
	public int getK();

	/**Returns number of steps in route r, r=1,....,getR().*/
	public int getKr(int r);

	/**Returns the machine that performs the following operation.*/
	public int getMachine(Operation op);

	/**Returns a List of all operations in machine i. The returned value is a List of Operation objects*/
	public List getCi(int i);

	/**Returns the number of operations in machine i.*/
	public int getSizeCi(int i);

	/**Returns the processing time of job of route r, on step o.*/
	public double getXto(int r, int o) ;

        /**Returns the processing time of the proper operation. */
	public double getXto(Operation op) ;
        
	/**Returns a List of all operations in route r*/
	public List getRoute(int r);
        
	/**Ask if the  shop is a jobshop with a single route same as getR()==1*/
	boolean isSingleRoute();
        
        /**Returns the sum of the means of all the processing times of all operations on a machine. */
        public double getMeanOfMachine(int machineNumber);        
        
        /**Returns the sum of all of the processing times that compose a route.*/ 
        public double getMeanOfRoute(int routeNumber);
        
        /**Returns the "job lower bound".*/
        public double getMaxRouteMean();
        
        /**Returns the "machine lower bound".*/
        public double getMaxMachineMean();
        
        /**Returns the time that the machine needs to spend working on jobs from the route.*/
        public double getMeanOfRouteOnMacine(int machine_,int route_);
        
        /**Returns an array of length getR(), such that each element has getMeanOfRouteOnMachine(machine_,r)  for r=0,...,getR()-1.*/
        public double [] getMeanOfRoutesOnMachine(int machine_);
 
        /**Returns a matrix whose first dimenstion is the number of machines and second dimension is the number of routes.  The rows
         *of the matrix are getMeanOfRoutesOnMachine(i).*/
        public double [][] getMeansOfRoutesOnMachines();
}//END OF INTERFACE