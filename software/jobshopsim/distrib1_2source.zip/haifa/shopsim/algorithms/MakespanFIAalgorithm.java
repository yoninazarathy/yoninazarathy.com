package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.io.*;

/**This is the previously known GFA algorithm in Tabi Budoukh's Thesis.*/
public class MakespanFIAalgorithm extends FIAalgorithm{

	
        public void setShopData(ShopData shopData_){
            shopData=shopData_;
        }

        public void setShopStateObject(ShopState shopState_){
            shopState=shopState_;
        }
        public void reset(){
           // if(shopState!=null){
           //             lowerBound=shopState.getExpectedMachineLowerBound();
          //              log.println("In the makespan FIA algorithm, the low bound was set to: " + lowerBound);
          //  }
        }
        
        public MakespanFIAalgorithm(){
            super();
        }
        
	public MakespanFIAalgorithm(ShopData shopData_,
			                        		 ShopState shopState_,
                                                                 PrintWriter log_) {
                         super(shopData_,shopState_,log_);                                        
	}

        public MakespanFIAalgorithm(ShopData shopData_,
			                        		 ShopState shopState_) {
                        super(shopData_,shopState_,new PrintWriter(System.out,true));
	}
        
         public MakespanFIAalgorithm(ShopData shopData_) {
			super(shopData_);
	}
                
	/**Determines by how much the Operation op is lagging behind
	the immitated solution. Uses (Q-q)/q. Where Q is the reaLife function
	and q is the immitatedValue. May return infinity (Double.MAX_VALUE*/
	public double lagFunction(Operation op){
		double q=immitatedValue(op);
                double lag= (q>0 ? (realLifeFunction(op)-q)/q :  Double.MAX_VALUE);
                //log.println("lag of " + op + " is " + lag);
		return lag;
	}//END OF METHOD

	/**Returns the value of the fluid solution that is being immitated
	for a specific buffer. This is the optimal fluid draining solution.*/
	public double immitatedValue(Operation op){
		int route=op.getRoute();
                double val=((double)shopState.getInitialNr()[route-1])*
                                        (1-shopState.getTime()/shopState.getExpectedMachineLowerBound());
                if(val>0)
                    return val;
                else{
                    return 0;
                }
	}

        /**Breaks a tie by choosing the operation with the smaller step in the route*/
        public Operation breakTie(Operation one, Operation two){
          //log.println("breakTie("+one+","+two+") called");
          return one.getStep() > two.getStep() ? two : one;  
        }
        

	/**Returns the value of a function of the JobShopState.*/
        public double realLifeFunction(Operation op){
            return (double)((Integer)shopState.getQPlusMap().get(op)).intValue();
        }

	public static String StaticGetAlgorithmName(){
		return "Makespan FIA (previously known as GFA)";
	}

	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}

	public String toString(){
		return getAlgorithmName();
	}        
}//END OF CLASS