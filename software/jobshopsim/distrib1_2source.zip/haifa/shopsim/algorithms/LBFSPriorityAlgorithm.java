package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.util.*;

public class LBFSPriorityAlgorithm extends BufferPriorityAlgorithm {

    /** Creates new LBFSPriorityAlgorithm */
    public LBFSPriorityAlgorithm() {
    }
    
    public LBFSPriorityAlgorithm(ShopData shopData_){
        super(shopData_);
    }
    
    /***/
	protected void setPriority(Map map,List ops){
            Collections.sort(ops,new LBFSComparator());
            Iterator it = ops.iterator();
            int pri=1;
            while(it.hasNext()){
                map.put(it.next(),new Integer(pri++));
            }
	}

   
	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}
        
    	public static String StaticGetAlgorithmName(){
		return "LBFS Buffer Priority Algorithm";
	}


        
        
        /**A comparator that is designed to compare Operation objects. Saying that operations with higher priority are lower.*/
        class LBFSComparator implements Comparator{
            public int compare(Object o1, Object o2){
                Operation op1=(Operation)o1;
                Operation op2=(Operation)o2;
                if(op1.getStep()<op2.getStep()){
                    return 1;
                }else if(op2.getStep()<op1.getStep()){
                    return -1;
                }else{//the steps are equal
                    if(op1.getRoute()<op2.getRoute())
                        return -1;
                    else if(op2.getRoute()<op1.getRoute())
                        return 1;
                    else 
                        return 0;
                }
            }//end of method
        }//END OF INNER CLASS    
    


}//END OF CLASS
