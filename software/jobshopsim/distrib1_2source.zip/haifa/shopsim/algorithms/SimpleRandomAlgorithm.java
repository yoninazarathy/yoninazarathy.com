package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.io.*;
import java.util.*;

/**This algorithms decides what do by drawing from a discrete uniform distribution on all of the job classes that are 
 *schedulable at a given time.*/
public class SimpleRandomAlgorithm extends AbstractAlgorithm{

        final static String EXPLANATION =
	    "This algorithm schedules the jobs in a random manner (without any intelligence).";

        private Random random;
        
        /**Stores the value of the last seed that was used during a reset () method.*/
        private long lastSeed;

        ////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////CONSTRUCTORS////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////
        
        public SimpleRandomAlgorithm(){
            super();
        }
        
	public SimpleRandomAlgorithm(   ShopData shopData_,
			                ShopState shopState_,
                                        PrintWriter log_        ){
                         super(shopData_,shopState_,log_);                                        
	}

        public SimpleRandomAlgorithm(   ShopData shopData_,
			                ShopState shopState_    ){
                        super(shopData_,shopState_,new PrintWriter(System.out,true));
	}
        
         public SimpleRandomAlgorithm(ShopData shopData_        ){
			super(shopData_,new PrintWriter(System.out,true));
	}
        

         /**Resets the algorithm.*/
        public void reset(){
            long temp=System.currentTimeMillis();
            if(lastSeed!= temp){//if atleast one millis has past, may set a new seed
                random = new Random(lastSeed=temp);  
            }
        }


   

        
        ///////////////////////////////////////////////////////////////////////////////////////
        //////////////////////ALGORITHM IMPLEMINTATION//////////////////////
        //////////////////////////////////////////////////////////////////////////////////////
        
	/**Very simply reads a command from console and returns a ShopCommmand object.*/
	public ShopCommand whatNow(int machineNumber){
            Collection ops = shopState.getSchedulableOperations(machineNumber);
            //log.println("In whatNow() of SimpleRandomAlgorithm. SchedulableOperations: " + ops);
            ArrayList list = new ArrayList(ops);
            if(ops.size()==0)//if nothing to do
                return new ShopCommand(machineNumber,ShopCommand.CODE_REST);
            int num=random.nextInt(list.size());
            return new ShopCommand(machineNumber,(Operation)list. get(num));
	}

	/***/
	public String explanationString(){
		return EXPLANATION;
	}

	public boolean isDeterministic(){
		return false;
	}

	public static String StaticGetAlgorithmName(){
		return "Random Buffer Scheduling Rule (RBSR)";
	}

	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}
}//END OF CLASS