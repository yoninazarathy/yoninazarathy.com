package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.util.*;

/**Given two operations (r1,o1) and (r2,o2).  If o1<o2 then operation
1 will be given a higher priority.  If there is a tie then the buffer
with the smaller route index will be given the higher priorty.*/
public class FBFSPriorityAlgorithm extends BufferPriorityAlgorithm {

    /** Creates new FBFSPriorityAlgorithm */
    public FBFSPriorityAlgorithm(ShopData shopData_) {
        super(shopData_);
    }

    public FBFSPriorityAlgorithm() {
		super();

    }

    /***/
	protected void setPriority(Map map,List ops){
            Collections.sort(ops,new FBFSComparator());
            Iterator it = ops.iterator();
            int pri=1;
            while(it.hasNext()){
                map.put(it.next(),new Integer(pri++));
            }
	}

    public static String StaticGetAlgorithmName(){
		return "FBFS Buffer Priority Algorithm";
	}

	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}
        
        /**A comparator that is designed to compare Operation objects. Saying that operations with higher priority are lower.*/
        class FBFSComparator implements Comparator{
            public int compare(Object o1, Object o2){
                Operation op1=(Operation)o1;
                Operation op2=(Operation)o2;
                if(op1.getStep()<op2.getStep()){
                    return -1;
                }else if(op2.getStep()<op1.getStep()){
                    return 1;
                }else{//the steps are equal
                    if(op1.getRoute()<op2.getRoute())
                        return -1;
                    else if(op2.getRoute()<op1.getRoute())
                        return 1;
                    else 
                        return 0;
                }
            }
            
            
        }//END OF INNER CLASS
}
