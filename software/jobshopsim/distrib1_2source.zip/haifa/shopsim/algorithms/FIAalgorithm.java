package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.io.*;
import java.util.*;

/**This is the FluidImmitationAlgorithm(FIA).  It uses the following 
abstract entities:
<ul>
<li>realLifeFunction - This is a value of the shop (per buffer) at a certain
time.
<li>immitatedFunction - This is the value of the fluid solution (maybe fluid
optimal) at a certan time (per buffer).
<li>lagFunction - This is the value of the lag (by how much the real
life function differs from the immitatedFunction.
 *<li>breakTie - This function is called when two operations on a machine have the same lagFunction value, in that case,
 *the function decides which operation is to be scehduled.
</ul>
The whatNow(machine) method simply looks at all of lagFunctions for
all buffers of machine. And schedules the buffer that is most lagging
(and also has a job).
<P>
Dervied subclasses of this class should select proper functions
(as listed above).
*/
abstract class FIAalgorithm extends AbstractAlgorithm{

/////////////////////////////////////////////////////////////////////////
////////////////////CONSTRUCTORS//////////////////////////////    
/////////////////////////////////////////////////////////////////////////    
    
        public FIAalgorithm(){
            super();
        }
        
	public FIAalgorithm(ShopData shopData_,
			                        		 ShopState shopState_,
                                                                 PrintWriter log_) {
                         super(shopData_,shopState_,log_);                                        
	}

        public FIAalgorithm(ShopData shopData_,
			                        		 ShopState shopState_) {
                        super(shopData_,shopState_,new PrintWriter(System.out,true));
	}
        
         public FIAalgorithm(ShopData shopData_) {
			super(shopData_,new PrintWriter(System.out,true));
	}
    
	/**Returns true, this is a determinsitic algorithm.*/
	public boolean isDeterministic(){
		return true;
	}

	public ShopCommand whatNow(int machineNumber){

		//Get the operations that should be considered
		Collection ops = shopState.getSchedulableOperations(machineNumber);

		
		Iterator it=ops.iterator();
                if(!it.hasNext()){
                  return new ShopCommand(machineNumber,ShopCommand.CODE_REST);
                }
		Operation maxLagOp=(Operation)it.next();
		double maxLag=lagFunction(maxLagOp);
		double tempLag;
		while(it.hasNext()){//loop to find most lagging operation
			Operation tempOp =(Operation)it.next();
			tempLag=lagFunction(tempOp);
                        if(maxLag==tempLag){//if tie then break it
                            maxLagOp=breakTie(maxLagOp,tempOp);
                        }else if(maxLag<tempLag){
				maxLag=tempLag;//we have a new maximum
				maxLagOp=tempOp;//we have a new maximizing operation
			}
		}
		return new ShopCommand(machineNumber,maxLagOp);
	}//END OF WHATNOW METHOD


	/**Determines by how much the Operation op is lagging behind
	the immitated solution.*/
	protected abstract double lagFunction(Operation op);

	/**Returns the value of the fluid solution that is being immitated
	for a specific buffer.*/
	protected abstract double immitatedValue(Operation op);


	/**Returns the value of a function of the JobShopState.*/
	protected abstract double realLifeFunction(Operation op);
        
        /**When two operations have the same lagFunction value, this method decides which is the one that is to be scheduled.*/
        protected abstract Operation breakTie(Operation one, Operation two);
}//END OF CLASS