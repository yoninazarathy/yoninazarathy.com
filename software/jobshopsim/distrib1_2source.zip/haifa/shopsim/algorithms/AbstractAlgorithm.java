package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.io.*;

/**
This class implements the ShopAlgorithm interface and handles some of the work that should be perofrmed by any algorithm. (Associations
 *to shop data, state log etc...).
 *@version 1.1 
*/
public abstract class AbstractAlgorithm implements ShopAlgorithm{
	PrintWriter log;
	ShopData shopData;
	ShopState shopState;
        ShopSimulation shopSimulation;

        public AbstractAlgorithm(){}
        
        public AbstractAlgorithm(ShopData shopData_){
          setShopData(shopData_  );
            
        }
        
        public AbstractAlgorithm(ShopData shopData_,
			                        		 ShopState shopState_,
                                                                 PrintWriter log_){
                                                                     setShopData(shopData_);
                                                                     setShopStateObject(shopState_);
                                                                     setLog(log_);
        }

        public AbstractAlgorithm(ShopData shopData_,
                                                                 PrintWriter log_){
                                                                     setShopData(shopData_);
                                                                     setLog(log_);
        }        
        
	public String explanationString(){
		return "no explanation";
	}

	public void setLog(PrintWriter log_){
		log=log_;
	}

	public void setShopData(ShopData shopData_){
		shopData=shopData_;
	}

	public void setShopStateObject(ShopState shopState_){
		shopState=shopState_;
	}
        
        /**Set the algorithm's shop simulation object.  The algorithm may interact with a shop simulation object
         *by giving it askAgainAtCurrentTime(machine number) signals.*/
        public void setShopSimulationObject(ShopSimulation shopSimulation_){
            shopSimulation = shopSimulation_;
            //System.out.println("Shop simulation set to a value: " + shopSimulation);
        }
        
        
	/**Returns true when the algorithm decided that it is time to quit. (by default, always returns false, unless overloaded)*/
	public boolean quitCalled(){
		return false;
	}

	/**Does nothing, (may be overridden).*/        
        public void reset(){}
        
	/**Does nothing, (may be overridden).*/
	public void setEnabled(boolean enabled){}        
        
        public String toString(){
		return getAlgorithmName();
	}
        
}//END OF CLASS