package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.io.*;
import java.util.*;

/**An abstract class with one important method:
setPriority(Map map,List ops); When this method is implemented by
a dervied class it defines the priority dispatching rule.
*/
public abstract class BufferPriorityAlgorithm extends AbstractAlgorithm{

   protected static final String EXPLANATION="";

   ///////////////////////////////////////////////////////////////////////////////////////
   ////////////////////////////////CONSTRUCTORS////////////////////////////////
   //////////////////////////////////////////////////////////////////////////////////////

	/**An array of priority maps, one for each machine. The keys
	in the maps are operation objects and the values are priorities.
	A high priorty is a low number.Priorities start at one.*/
	Map [] priorityMaps;

   public BufferPriorityAlgorithm(){
        super();
   }


	public BufferPriorityAlgorithm(ShopData shopData_,
			                        		 ShopState shopState_,
                                         PrintWriter log_) {
           super(shopData_,shopState_,log_);
	}

        public BufferPriorityAlgorithm(ShopData shopData_,
			                        		 ShopState shopState_) {
                        super(shopData_,shopState_,new PrintWriter(System.out,true));
	}

         public BufferPriorityAlgorithm(ShopData shopData_) {
			super(shopData_,new PrintWriter(System.out,true));
	}


	public void setShopData(ShopData shopData_){
		shopData=shopData_;
		priorityMaps = new HashMap[shopData.getI()];

		for(int i=0;i<priorityMaps.length;i++){
			priorityMaps[i]=new HashMap();
			List ll=shopData.getCi(i+1);
			setPriority(priorityMaps[i],ll);
                        //System.out.println("the prioritiesfor machine "+(i+1)+"  are " + priorityMaps[i]);
		}
	}


	/**Gets an empty map that is to be filled with priorites.
	And gets a list of operations of all of the operations on
	a machine. Should set a unique priority for each operation.*/
	abstract protected void setPriority(Map map,List ops);





        ///////////////////////////////////////////////////////////////////////////////////////
        //////////////////////ALGORITHM IMPLEMINTATION//////////////////////
        //////////////////////////////////////////////////////////////////////////////////////

	/**Very simply reads a command from console and returns a ShopCommmand object.*/
	public ShopCommand whatNow(int machineNumber){
                Collection ops = shopState.getSchedulableOperations(machineNumber);
		Iterator it = ops.iterator();
                if(ops.size()==1)
			return new ShopCommand(machineNumber, (Operation)it.next());
                
                //obtain the proper priority map, so we can select the highest priority buffer
                Map priMap= priorityMaps[machineNumber-1];

		
		Operation highestOp=(Operation)it.next();
		int highestPriority=
					((Integer)priMap.get(highestOp)).intValue();

		while(it.hasNext()){
			Operation op=(Operation)it.next();
			int tempPri=((Integer)priMap.get(op)).intValue();
			if(tempPri<highestPriority){//found a new high priority (high priorities are low numbers
				highestPriority=tempPri;
				highestOp=op;
			}
		}
		return new ShopCommand(machineNumber,(highestOp));
	}



	/***/
	public String explanationString(){
		return EXPLANATION;
	}

	public boolean isDeterministic(){
		return true;
	}
}//END OF CLASS
