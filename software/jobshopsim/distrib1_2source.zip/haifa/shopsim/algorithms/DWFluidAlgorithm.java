package haifa.shopsim.algorithms;

import haifa.shopsim.*;
import haifa.global.*;

import java.util.*;
/**This class is not still ready.  It runs the simulation, but does not terminate.*/
public class DWFluidAlgorithm extends AbstractAlgorithm {

        public static final String EXPLANATION="Jim Dai and Gideon Weiss Fluid Heuristic";

        
/////////THE PARTS OF THE HEURISTIC////////////////////

        /**This means that the algorithm still hasn't started.*/
        protected final static int PART_ZERO=0;
        
	/**This part is the creation of the safety stocks.*/
	protected final static int PART_ONE=1;

	/**This part is the "body" of the algorithm, work
	in cycles.*/
	protected final static int PART_TWO=2;

	/**This part is the empting of the system after the bottleneck machine has finsihed.*/
	protected final static int PART_THREE=3;


	/**This part should only occur at a few (low prob) instances of
	the problem.  It means that the heuristic has become infeasble.*/
	protected final static int PART_ALARM=5;

        
        /**Safety stocks are calucated as SAFETY_CONSTANT * log(Number in route).*/
        double SAFETY_CONSTANT  = 15;
        
	/**Keys are Operation objects and values are Integers 1,...,NumOps*/
	HashMap kittedRoutesMap;
        
        /**Keys are Integers and values are Operation objects.*/
        HashMap reverseKittedRoutesMap;

	/**The number of buffers in the route.*/
	int numK;

	/**The index of the bottleneck machine.*/
	int bottleMachine;
        
        /**An array of buffer numbers (according to kitted) that states the operations of the botleneck machine.*/
        int [] bottleNeckOperations;

        
        /**An array of arrays, having I (num of machines) arrays.  The i'th array refers to the opertations
         *perforemd by machine i-1. The contents in the spot of the bottleneck machine is undefined .*/
        int [][] nonBottleNeckOperations;
        
	/**The number of safety stocks to be put in every buffer. Indexed by the buffers as
         they are mapped in the kittedRoutesMap.*/
	int [] safetyStocks;

        /**The part during which the algorithm is found.*/
        int currentPart;

    public DWFluidAlgorithm() {
    }

    public DWFluidAlgorithm(ShopData shopData_) {
        super(shopData_);
    }


    public void reset(){
	setUpKittedMaps();
	locateBottleNeck();
        setBottleNeckOperations();
        setNonBottleNeckOperations();
	//calcNeededSafetyStocks();
        currentPart=PART_ZERO;
    }

	/**Sets up the kitted hash map (concatantation of the routes).
	Requires the shop Data to be set.*/
	protected void setUpKittedMaps(){
		int k=1;
                kittedRoutesMap=new HashMap();
                reverseKittedRoutesMap=new HashMap();
		for(int r=1;r<=shopData.getR();r++){
			List ops = shopData.getRoute(r);
			Iterator it = ops.iterator();
			while(it.hasNext()){
                                Object o= it.next();
				kittedRoutesMap.put(o,new Integer(k));
                                reverseKittedRoutesMap.put(new Integer(k),o);
                                k++;
                        }
		}
		numK=k-1;
	}

	/**Find the bottleneck machine. Requires the shopData to be set.*/
	protected void locateBottleNeck(){
		double means [] = new double[shopData.getI()];
		for(int i=0;i<means.length;i++)
			means[i]=shopData.getMeanOfMachine(i+1);
		int [] maxes =haifa.global.HaifaArrays.maxIndexesInArray(means);
		if(maxes.length > 1){
			//QQQQ problem two bottleneck machine
		}
		bottleMachine= maxes[0]+1;
	}
        
        protected void setBottleNeckOperations(){
         List ops = shopData.getCi(bottleMachine);
         bottleNeckOperations=new int[ops.size()];
         Iterator it = ops.iterator();
         int i=0;
         while(it.hasNext()){
            bottleNeckOperations[i++]=((Integer)kittedRoutesMap.get(it.next())).intValue();
         }
        }//end of method
        
        protected void setNonBottleNeckOperations(){
         nonBottleNeckOperations= new int[shopData.getI()][];
         for(int i=0;i<nonBottleNeckOperations.length;i++){
             List ops = shopData.getCi(i+1);
             nonBottleNeckOperations[i]=new int[ops.size()];
             Iterator it = ops.iterator();
             int j=0;
             while(it.hasNext()){//loop on all operations of machine
                nonBottleNeckOperations[i][j++]=((Integer)kittedRoutesMap.get(it.next())).intValue();
             }
         }//end of loop on all machines
        }//end of method
        
	/**Must be called after numK is already set. Requires the shop state
	to be set.*/
	protected void calcNeededSafetyStocks(){
		safetyStocks = new int[numK];
                for(int i=0;i<safetyStocks.length;i++){
                    safetyStocks[i]=4;
                    log.println("Safety stocks for route " + i + "   " + safetyStocks[i]);
                }
	}//end of calc needed safetey stocks

        
//////////////////////////////////////////////////////////////////
//////////////////////ACTUAL ALGORITHM STUFF//////////////////////
//////////////////////////////////////////////////////////////////        
        

	/**Works by separtaing the timeline of the system to four parts
	and a special part that.*/
	public ShopCommand whatNow(int machineNumber){
		ShopCommand sc=null;
                if(currentPart==PART_ZERO){
                    doPartZero();
                }if(currentPart==PART_ONE){
			sc=whatNowPartOne(machineNumber);
		}else if(currentPart==PART_TWO){
                        sc=whatNowPartTwo(machineNumber);
		}else if(currentPart==PART_TWO){
                        sc=whatNowPartThree(machineNumber);
		}else if(currentPart==PART_ALARM){
                        sc=whatNowPartAlarm(machineNumber);
		}else{
			//error
		}

		if(sc==null){//then it means that the current part is finsihed
						//and it was up to the specific whatNowXXX
						//method to cheange the currentPart data member
                        System.out.println("A new part has just started: " + currentPart);
			sc=whatNow(machineNumber);//call what now with new part
		}
		return sc;
	}//END OF WHATNOW METHOD

	/**An array the length of shopData.getR(). It is used
	during part one of the algorithm. For each route
	it keeps either a value of 0, meaning that all of the safety stocks
	in this route have been built.  Or it keeps a value of the operation
	index (starting at 2,...,Kr) of the highest operation that still
	doesn't have full safety stocks.<P>
	Thus at the start of Part one, this array has Kr, for each operation.
	(Except for routes with one step)*/
	//int [] hungryOps;

        
        /**Keys are operaton objects and values are Integers.*/
        HashMap maxUpstreamMap;
        
        /**An array of booleans having true for each machine that is resting. When all is true,
         *the algorithm knows that Part one is done with.*/
        boolean [] restingMachines;

        
        protected void doPartZero(){
            calcNeededSafetyStocks();
                maxUpstreamMap=new HashMap();
                restingMachines=new boolean[shopData.getI()];
                log.println("kitted map: " + kittedRoutesMap);
                log.println("Bottleneck machine: " + bottleMachine);
                log.println("Operations of bottleneck: " + haifa.global.HaifaArrays.toStringArray(bottleNeckOperations));
                log.println("Operations of all machines: ");
                
                for(int i=0;i<nonBottleNeckOperations.length;i++)
                    log.println("Machine " + (i+1) + "  " + haifa.global.HaifaArrays.toStringArray(nonBottleNeckOperations[i]));
                log.println("Safety Stocks:" + haifa.global.HaifaArrays.toStringArray(safetyStocks));                 
		for(int r=1;r<=shopData.getR();r++){//loop on all routes
			List ops = shopData.getRoute(r);
                        int cumStock=0;
                        for(int o=ops.size()-1;o>=0;o--){
                            Operation op = (Operation)ops.get(o);
                            int stock=safetyStocks[((Integer)kittedRoutesMap.get(op)).intValue()-1];
                            maxUpstreamMap.put(op,new Integer(cumStock));
                            cumStock+=stock;
                        }
		}//end of loop on all routes
                log.println("IN DWFluidAlg, set maxUpStreamMap: " + maxUpstreamMap);
                
                currentPart=PART_ONE;
        }
        
        protected ShopCommand whatNowPartOne(int machineNumber){
            boolean resting=true;
            for(int i=0;i<restingMachines.length;i++)
                resting &=restingMachines[i];
            if(resting==true){//if all machines were resting
                currentPart=PART_TWO;
                return null;
            }
            
            Collection ops = shopState.getSchedulableOperations(machineNumber);
            //System.out.println("Schedulabe Ops of machine: " + machineNumber + " are: " +ops);
            for(int r=1;r<=shopData.getR();r++){//loop on all routes
                Iterator it = ops.iterator();
                int maxStep=-1;
                Operation maxOp=null;
                while(it.hasNext()){//loop on all operations of route that still haven't filled their upstream
                 Operation op = (Operation)it.next();
                 if(op.getRoute()!=r)
                     continue;
                 if(downStreamOfOperation(op)>=((Integer)maxUpstreamMap.get(op)).intValue())
                     continue;//if operation should not be performed
                 if(op.getStep()>maxStep){
                    maxStep=op.getStep();
                    maxOp=op;
                 }
                }//end of loop on all operation of a specific route
                if(maxOp!=null){//if found an operation from the route to schedule
                    restingMachines[machineNumber-1]=false;//record that machine wasn't resting
                    return new ShopCommand(machineNumber,maxOp);//schedule it
                }
            }
            
            //if here and nothing was returned yet then it is time to rest
            
            //record the resting machine
            restingMachines[machineNumber-1]=true;
            
            return new ShopCommand(machineNumber,ShopCommand.CODE_REST);
            //QQQQreturn null;//when out of Part-one
        }//END OF METHOD
        
        /**Returns the number of jobs on the route of operation that are past it (have completed it).*/
        private int downStreamOfOperation(Operation op){
            int qp=((Integer)shopState.getQPlusMap().get(op)).intValue();
            int nr = shopState.getInitialNr()[op.getRoute()-1];
            //System.out.println("Upstream of Operation " + op + " called: " + (nr-qp));
            return nr-qp;
        }
        
	
        //this is an index that cycles through 0,...,bottolenckOperations.legnth
        //when index is -1 it means that part two has still not statrted
        int cycleIndex=-1;
        
        /**An array that has an index for each machine (the index for the bottlenck don't mean nothin. 
         *and the index says on which step from the nonBottleneckOperations the machine is working.
         The values are of the indexes start at 0*/
        int [] machineIndexes;
        
        /**An array of booleans where the spot corresponding to machine i is true if the machine still
         *hasn't completed all of it's steps with the bottlecycle.  When a machine completes it's last step,
         *it sets the value to false, later, when the bottleneck machine starts another cycle, it brings
         *the values to true again.*/
        boolean [] nonBottleNotFinishedCycle;
        
        int numCycles=0;

        
       boolean firstTimePartTwo=true;
        
        ShopCommand whatNowPartTwo(int machineNumber){
            if(timeToMoveToPartThree()){
                currentPart=PART_THREE;
                return null;
            }
                
            if(firstTimePartTwo){//first time into part two
                machineIndexes=new int[shopData.getI()];
                nonBottleNotFinishedCycle= new boolean[shopData.getI()];
                 for(int i=0;i<nonBottleNotFinishedCycle.length;i++)
                        nonBottleNotFinishedCycle[i]=true;
                firstTimePartTwo=false;
                //cycleIndex=0;
            }//END OF BLOCK THAT OCCURS DURING FIRST TIME WE ENTER PART TWO
            
            Collection schedOps=shopState.getSchedulableOperations(machineNumber);
            
            if(machineNumber==bottleMachine){//if scheduling a bottlenck machine
                if(cycleIndex == bottleNeckOperations.length-1){//if end of bottlenck cycle
                  for(int i=1;i<=shopData.getI();i++)
                      if(i!= machineNumber){
                          if(shopSimulation == null)
                              System.out.println("shit");
                            shopSimulation.askAgainAtCurrentTime(i);
                      }
                    
                    cycleIndex=0;
                    for(int i=0;i<nonBottleNotFinishedCycle.length;i++)
                        nonBottleNotFinishedCycle[i]=true;
                    numCycles++;
                    log.println(shopState.getTime() + " : End of bottleneck cycle");
                }else{//if not end of cycle
                    cycleIndex++;
                }
                
                Operation nextOp=(Operation)reverseKittedRoutesMap.get(new Integer(bottleNeckOperations[cycleIndex]));
                if(!schedOps.contains(nextOp)){//if bottleneck ran out (code alert)
                 log.println(shopState.getTime() + " : Alert, Bottlenck is thristy...");
                 log.println("When called to schedule machine: " + machineNumber);
                 log.println("And when the nextOp is " + nextOp);
                 log.println("when the cycle index is " + cycleIndex);
                 log.println("And when the schedualbe operations are " + schedOps);
                 ///QQQQQQQ
                }
                log.println(shopState.getTime() + " : Bottleneck scheduled operation: " + nextOp);
                return new ShopCommand(machineNumber,nextOp);
                //END OF BLOCK OF OPERATION OF BOTTLENECK MACHINE
            }else{//AND FOR A REGULAR MACHINE
                if(nonBottleNotFinishedCycle[machineNumber-1]==false){
                    log.println(shopState.getTime() + " : Machine " + machineNumber + " is waiting for bottlenck");
                    return new ShopCommand(machineNumber,ShopCommand.CODE_REST);//QQQQ
                }
                //if there then still haven't completed cycle non-bottleneck
                int opToDoK=nonBottleNeckOperations[machineNumber-1][machineIndexes[machineNumber-1]];
                Operation op = (Operation)reverseKittedRoutesMap.get(
                                    new Integer(opToDoK));
                log.println(shopState.getTime() + " : Machine : " + machineNumber + "   opt to do : " + opToDoK + " " + op);
                
                if(!schedOps.contains(op)){//if operation is'nt avail
                    log.println(shopState.getTime() + " : op ain't avail");
                    //QQQQQQQQQQQQQQ
                    //return new ShopCommand(machineNumber,ShopCommand.CODE_REST);//QQQQ
                }
                
                if(machineIndexes[machineNumber-1]==nonBottleNeckOperations[machineNumber-1].length-1){
                 //if machine finished last operation in cycle   
                    machineIndexes[machineNumber-1] =0;
                    nonBottleNotFinishedCycle[machineNumber-1]=false;
                }else{
                    machineIndexes[machineNumber-1]++;
                    log.println(shopState.getTime() + " : Index of machine " + machineNumber +" increaed to " + machineIndexes[machineNumber-1]
                    + " meaning op of index is " + nonBottleNeckOperations[machineNumber-1][machineIndexes[machineNumber-1]]);
                }
                return new ShopCommand(machineNumber,op);
            }//end of block of regualr machine
        }//end of method

       private Random random;        

       
       private boolean timeToMoveToPartThree(){
           for(int r=1;r<=shopData.getR();r++){
             int jobs = ((Integer)shopState.getQMap().get(new Operation(r,1))).intValue();  
             if(jobs==0)
                 return true;
           }
            return false;
       }
       
        ShopCommand whatNowPartThree(int machineNumber){
            Collection ops = shopState.getSchedulableOperations(machineNumber);
            //log.println("In whatNow() of SimpleRandomAlgorithm. SchedulableOperations: " + ops);
            ArrayList list = new ArrayList(ops);
            if(ops.size()==0)//if nothing to do
                return new ShopCommand(machineNumber,ShopCommand.CODE_REST);
            int num=random.nextInt(list.size());
            return new ShopCommand(machineNumber,(Operation)list. get(num));
        }

        
       
        ShopCommand whatNowPartAlarm(int machineNumber){
            return null;            
        }
        
        
////////////////////////////////////////////////////////////////////
/////////////////MISCELLNIOUS METHODS///////////////////////////////
////////////////////////////////////////////////////////////////////        
        
    public boolean isDeterministic(){
        return true;
    }
    
    public String explanationString(){
	return EXPLANATION;
    }

    public static String StaticGetAlgorithmName(){
	return "Dai and Weiss Fluid Algorithm (Not fully complete)";
    }

    public String getAlgorithmName(){
    	return StaticGetAlgorithmName();
    }
}//END OF CLASS