package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.io.*;
import java.util.*;

/**This algorithms decides what do by drawing from a discrete 
uniform distribution on all of the job classes that are 
schedulable at a given time.*/
public class RandomJobAlgorithm extends AbstractAlgorithm{

        final static String EXPLANATION ="";
	   
        private int initialNr [];
        
        double cumProb [];
        
        private Random random;
        
        /**Stores the value of the last seed that was used during a reset () method.*/
        private long lastSeed;

        //////////////////////////////////////////////////////////////////////////
        //////////////////////////////CONSTRUCTORS////////////////////////////////
        //////////////////////////////////////////////////////////////////////////
        
        public RandomJobAlgorithm(){
            super();
        }
        
	public RandomJobAlgorithm(    ShopData shopData_,
                       		        ShopState shopState_,
                                        PrintWriter log_        ) {
                         super(shopData_,shopState_,log_);                                        
	}

        public RandomJobAlgorithm(    ShopData shopData_,
                       		        ShopState shopState_    ) {
                                super(shopData_,shopState_,new PrintWriter(System.out,true));
	}
        
        public RandomJobAlgorithm(ShopData shopData_          ) {
			super(shopData_,new PrintWriter(System.out,true));
	}
        
        public void setShopStateObject(ShopState shopState_){
		shopState=shopState_;
                int [] tempNr=shopState.getInitialNr();
                if(tempNr!=null){
                    initialNr=new int[tempNr.length];
                    cumProb=new double[initialNr.length];
                    System.arraycopy(tempNr,0,initialNr,0,tempNr.length);
	        }
        }
        

         /**Resets the algorithm.*/
        public void reset(){
            long temp=System.currentTimeMillis();
            if(lastSeed!= temp){//if atleast one millis has past, may set a new seed
                random = new Random(lastSeed=temp);  
            }
        }

        ////////////////////////////////////////////////////////////////////
        //////////////////////ALGORITHM IMPLEMINTATION//////////////////////
        ////////////////////////////////////////////////////////////////////
        
	/**Very simply reads a command from console and returns a ShopCommmand object.*/
	public ShopCommand whatNow(int machineNumber){
            if(initialNr==null){//set the initialNr if for some reason it hasn't been set
                    int [] tempNr=shopState.getInitialNr();
                    initialNr=new int[tempNr.length];
                    cumProb=new double[initialNr.length];
                    System.arraycopy(tempNr,0,initialNr,0,tempNr.length);
            }
            Collection ops = shopState.getSchedulableOperations(machineNumber);
            Map qmap = shopState.getQMap();
            //log.println("In whatNow() of SimpleRandomAlgorithm. SchedulableOperations: " + ops);
            if(ops.size()==0)//if nothing to do
                return new ShopCommand(machineNumber,ShopCommand.CODE_REST);
            
            //if there is something to do then schedule...
            Iterator it = ops.iterator();
            int C=0;
            while(it.hasNext())
                C+=((Integer)qmap.get(it.next())).intValue();
            //System.out.println("For machineNumber : " + machineNumber + "   calculated C = " + C);
            int rnd = random.nextInt(C);
            int accum=0;
            Operation op=null;
            it = ops.iterator();
            while(it.hasNext()){
                op=(Operation)it.next();
                accum+=((Integer)qmap.get(op)).intValue();
                if(rnd<accum)
                    break;
            }
            //System.out.println("The selected operation is: " + op);
            return new ShopCommand(machineNumber,op);
	}//END OF METHOD


	/***/
	public String explanationString(){
		return EXPLANATION;
	}

	public boolean isDeterministic(){
		return false;
	}

	public static String StaticGetAlgorithmName(){
		return "Random Job Scheduling Rule (RJSR)";
	}

	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}
}//END OF CLASS