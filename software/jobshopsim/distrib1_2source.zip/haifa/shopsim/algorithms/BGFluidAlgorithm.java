package haifa.shopsim.algorithms;

import haifa.shopsim.*;
/**This class is still not ready.*/
public class BGFluidAlgorithm extends AbstractAlgorithm {

    public static final String EXPLANATION="";
    
    /** Creates new BGFluidAlgorithm */
    public BGFluidAlgorithm() {
    }
    
    public BGFluidAlgorithm(ShopData shopData_) {
        super(shopData_);
    }
    
    public ShopCommand whatNow(int machineNumber){
      return null;  
        
    }
    
    public boolean isDeterministic(){
        return true;
    }
	public String explanationString(){
		return EXPLANATION;
	}

	public static String StaticGetAlgorithmName(){
		return "Bertsimas and Gamarnik Fluid Algorithm";
	}

	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}

	
}
