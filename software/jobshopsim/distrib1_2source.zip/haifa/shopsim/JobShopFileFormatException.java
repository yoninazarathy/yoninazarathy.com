package haifa.shopsim;

/**Thrown when the input file does not seem to match the specification.
 *@version 1.1*/
public class JobShopFileFormatException extends Exception{

    //-1 means that it isn't set
    protected int lineNo=-1;
    
    public JobShopFileFormatException(){}
    
    /**Sets excpetion with line on which error occured.*/
    public JobShopFileFormatException(int lineNo_){
        lineNo=lineNo_;
    }

    /**Returnes the line on which the exception was discuvered (the error in the file may be before that. Returns -1 if no line is reported*/
    public int getLineNo(){
        return lineNo;
    }
}//END OF EXCEPTION CLASS