package haifa.shopsim;

import java.util.*;

/**This Class is part of the ShopChangeListener Observer scheme. 
 An Object of this class is passed to all listeners. every time the shop 
 changes.
 *@version 1.1
 */
public abstract class ShopChangeEvent extends EventObject{

        /**The simulation time of the event.*/
	private double time;

        /**Constructs with the source being the object on which this event occured and the simulation time.*/
	public ShopChangeEvent(Object source,double time_){
		super(source);
		time = time_;
	}

        /**Get the simulation  time relating to this event.*/
	public double getTime(){
		return time;
	}

        /**Returns time.*/
	public String toString(){
		return super.toString()+ " time:"+time;
	}
}//END OF CLASS