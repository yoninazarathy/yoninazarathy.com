package haifa.shopsim;

import java.util.*;

/**An enhancement to the abstract shop data, it keeps some more data structures
 in memory (taking up more memory, but speeds up some
 *method calls.
 @version 1.1
 */
public class FastAbstractShopData extends AbstractShopData{

    
    List [] CiList;
    List [] routesList;
    int K;
    
    
    /** Creates new FastAbstractShopData */
    protected FastAbstractShopData() {}
    
    /**Is to be called by constructors of sub-classes.*/
    protected void setUpFastData(){
        CiList=new List[getI()];
        for(int i=0;i<CiList.length;i++){
            CiList[i]=super.getCi(i+1);
        }
        
        routesList=new List[getR()];
        for(int r=0;r<routes.length;r++){
            routesList[r]=super.getRoute(r+1);
        }
        K=super.getK();
    }
    
////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////OVERRIDEN METHODS (FASTER)////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////    
    
	/**Returns the total number of steps/classes/buffers (sum of Kr)*/
	public int getK(){
            return K;
        }    
    
	/**Returns a List of all operation in machine i. The elements of the list
	are arrays of ShopData.Operation instances*/
	public List getCi(int i){
                    return CiList[i-1];
	}
        
	/**Returns the number of operations in machine i.*/
	public int getSizeCi(int i){
            return CiList[i-1].size();
        }
        
	/**Returns a List of all ShopData.Operation instances in route r*/
	public List getRoute(int r){
		return routesList[r-1];
	}        

}//END OF CLASS