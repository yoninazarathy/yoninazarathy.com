package haifa.shopsim;

import java.util.*;

/**Signifies that a machine started processing a job.*/
public class MachineStartedEvent extends ShopChangeEvent{
	
        /**The number of the machine that started processing.*/
        private int machineNumber;
	
        /**The operation that the machine started working on.*/
        private Operation operation;

        
        /**Constructor.*/
	public MachineStartedEvent(Object source, double time,
				int machineNumber_,
				Operation operation_){
									
		super(source,time);
		machineNumber = machineNumber_;
		operation = operation_;
	}

	public String toString(){
		return super.toString() + " machineNumber:" + machineNumber +
                " operation: " + operation;
	}

        /**Returns the machine number of the machine that started processing.*/
	public int getMachineNumber(){
		return machineNumber;
	}
        
        public Operation getOperation(){
            return operation;
        }
}//END OF CLASS