package haifa.shopsim;

import java.io.*;

/**A ShopAlgorithm (GFA,CFA,manual etc...) has associations to a ShopState
object (An object representing the current state of the shop), a ShopData
object (the shop topology and jobs processing times),
a ShopSimulation object  and a log into which it
writes infomration regarding it's processing.<P>
*@version 1.1
*/
public interface ShopAlgorithm{

	////////////////////////////////////////////////////////////
	/////////////THE IMPORTANT METHOD////////////
	////////////////////////////////////////////////////////////

	/**Returns a ShopCommand class which has the directions on the next immidiate
	action to do for the specific machine.<p>
	This method looks at the shop state objects and decides what the machine should do.*/
	public ShopCommand whatNow(int machineNumber);
        
	///////////////////////////////////////////////////////////////////////////////////////
	///////////////////////AUXILLARY METHODS/////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////////
        
        /**Resets the algorithm. This method may have various meaninings depending on the algorithm implemented.
         It must be called by the user of the algorithm, prior to every run. This user is the shop simulation object.
         The method must be called as late as possible (that is after all refrences have been set.)*/
        public void reset();
        
	/**Set the algorithm's ShopState object. The algorithm looks at this Object and
	makes decisions based on it whenever the whatNow message is called.*/
	public void setShopStateObject(ShopState shopState);
        
        /**Set the algorithm's shop simulation object.  The algorithm may interact with a shop simulation object
         *by giving it askAgainAtCurrentTime(machine number) signals.*/
        public void setShopSimulationObject(ShopSimulation shopSimulation);

	/**Set the algorithm's shopData object, this is a reference for the general topology
	of the job shop and for processing times.*/
	public void setShopData(ShopData shopData);

	/**The algorithm writes decision information to the log.*/
	public void setLog(PrintWriter log);

	/////////////////////////////////////////////
	///////////GENERAL INFO METHODS//////////////
	/////////////////////////////////////////////
	/**Returns a string telling a little bit about what the algorithm does.*/
	public String explanationString();

	/**Returns true if the algorithm is determinsitic.*/
	public boolean isDeterministic();

	/**Returns a name of the algorithm.*/
	public String getAlgorithmName();
}//END OF INTERFACE