package haifa.shopsim;

/**A ShopChangeEvent that siginifies that a machine started a willing rest.
 *@version 1.1
 */
public class WillingRestStartedEvent extends ShopChangeEvent {

        /**The machine that finished the processing.*/
        private int machineNumber;

        /**Constructor.*/
	public WillingRestStartedEvent(	Object source, double time,
									int machineNumber_){
		super(source,time);
		machineNumber = machineNumber_;
	}//END OF COT'R
        
        /**to String represtntation.*/
	public String toString(){
		return super.toString() + " machineNumber:" + machineNumber;
	}

        /**Returns the machineNumber of the machine that started to rest.*/
	public int getMachineNumber(){
		return machineNumber;
	}
}//END OF CLASS