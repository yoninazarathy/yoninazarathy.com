package haifa.shopsim;

import java.util.*;

/**An event siginfing that a simulation has started.
 *@version 1.1
 */
public class ShopStartedEvent extends ShopChangeEvent{

	public ShopStartedEvent(Object source, double time){
		super(source,time);
	}

	public String toString(){
		return super.toString();
	}
}//END OF CLASS