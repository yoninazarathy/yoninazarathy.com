package haifa.shopsim.util;

import java.io.*;
import java.util.*;


/**Conversts from format as specified by the OR library to  .jbs format. Note: to really use this
 class you should  actually edit it and understand what it does.  It was written very hastinlgy.
 *@version 1.1
 */
class JobShopFileConverter{

	/**Give main the name of the source and destination files.*/
	public static void main(String [] args) throws IOException{
		if(args.length!=2){
			System.err.println("Give two args");
			System.exit(1);
		}

		String source = args[0];
		String dest = args[1];

		int numMachines=-1;
		int numRoutes=-1;

		StreamTokenizer st = new StreamTokenizer( new FileReader(source));
		PrintWriter pw = new PrintWriter(new FileWriter(dest));



		pw.println("#Converted from file " + source);

		st.nextToken();
		numRoutes = (int)st.nval;

		st.nextToken();
		numMachines = (int)st.nval;

		pw.println(numMachines);

		pw.println(numRoutes);

		int [] steps=new int[numMachines];
		int [] means=new int[numMachines];

		for(int r=1;r<=numRoutes;r++){
			for(int i=0;i<numMachines;i++){
				st.nextToken();
				steps[i]=(int)st.nval;
				st.nextToken();
				means[i]=(int)st.nval;
			}
			pw.println("Route "+r);
			for(int s=0;s<steps.length;s++){
				pw.print((steps[s]+1)+ " ");
			}
			pw.println("");
			pw.println("Means");
			for(int s=0;s<steps.length;s++){
				pw.print(means[s]+ " ");
			}
			pw.println("\n");

		}


		pw.close();
	}
}