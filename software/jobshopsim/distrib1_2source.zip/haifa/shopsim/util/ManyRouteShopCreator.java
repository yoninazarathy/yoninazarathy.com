package haifa.shopsim.util;

import java.io.*;
import java.util.*;

/**Creates an R about Equals N job shop. Writes it to the file test.jbs.  This 
 *is an unfinished and unused class. But it may be usefull later on.
 *@version 1.1
 */
public class ManyRouteShopCreator{
	int num=1000;
	int machines=10;
	int k=10;
	double mean=100.0;
	double std=20.0;

	Random random=new Random();

	public void doIt() throws IOException{
		PrintWriter pw = new PrintWriter(new FileWriter("test.jbs"),true);
		pw.println(machines);
		pw.println(num);
		pw.println(num);

		for(int r=1;r<=num;r++){
			pw.println("\n\nRoute " + r);
			for(int i=1;i<=machines;i++)
				pw.print((random.nextInt(k)+1)+" ");

		}

		for(int r=1;r<=num;r++){
					pw.println("\n\nJob " + r + "\n" +r +"\n1");
					for(int i=1;i<=machines;i++)
						pw.print((random.nextGaussian()*std+mean)+" ");

		}

		pw.close();
	}

	public static void main(String [] args) throws IOException{
		new ManyRouteShopCreator().doIt();
	}
}//END OF CLASS