package haifa.global;

import java.util.*;

/**Containts some usefull array methods (static).*/
public class HaifaArrays{

    /**Returns a string of this sort: (155,2,33)  if delim is ",".*/
    public static String toStringArray(int [] array,String delim){
       if(array.length==0)
           return "()";
      StringBuffer sb=new StringBuffer("(");
      for(int i=0;i<array.length;i++)
          sb.append(array[i]).append(delim);
      sb.delete(sb.length()-delim.length(),sb.length()); //to delete the last delim
      sb.append(")");
      return sb.toString();
    }

    /**Returns a string of this sort: (155.34,2.35,33.0)  if delim is "," nad ends are "{"
    and "}".*/
    public static String toStringArray(int [] array,String delim,
    						String endLeft,String endRight){
       if(array.length==0)
           return endLeft+endRight;
      StringBuffer sb=new StringBuffer(endLeft);
      for(int i=0;i<array.length;i++)
          sb.append(array[i]).append(delim);
      sb.delete(sb.length()-delim.length(),sb.length()); //to delete the last delim
      sb.append(endRight);
      return sb.toString();
    }



    /**Uses a "," for a delimiter*/
    public static String toStringArray(int [] array){
        return toStringArray(array,",");
    }

    /**Returns a string of this sort: (155.34,2.35,33.0)  if delim is ",".*/
    public static String toStringArray(double [] array,String delim){
      return toStringArray(array,delim,"(",")");
    }

    /**Returns a string of this sort: (155.34,2.35,33.0)  if delim is "," nad ends are "{"
    and "}".*/
    public static String toStringArray(double [] array,String delim,
    						String endLeft,String endRight){
       if(array.length==0)
           return endLeft+endRight;
      StringBuffer sb=new StringBuffer(endLeft);
      for(int i=0;i<array.length;i++)
          sb.append(array[i]).append(delim);
      sb.delete(sb.length()-delim.length(),sb.length()); //to delete the last delim
      sb.append(endRight);
      return sb.toString();
    }


    /**Uses a "," for a delimiter*/
    public static String toStringArray(double [] array){
        return toStringArray(array,",");
    }

    /**Gets an array of integers and returns an array smaller or equal in size such that each integer appears only once.
     Does not guarenty anything regarding the order of the elements in the array.*/
    public static int [] makeUniqueArray(int [] array){
        HashSet hashSet=new HashSet(array.length);

        for(int i=0;i<array.length;i++)
            hashSet.add(new Integer(array[i]));

        Iterator it=hashSet.iterator();

        int [] retArray = new int[hashSet.size()];
        int i=0;
        while(it.hasNext()){
            retArray[i++]=((Integer)it.next()).intValue();
        }
        return retArray;
    }//END OF METHOD

    /**Returns the maximal element in an array.*/
    public static double maxInArray(double [] array){
      if(array.length==0)
          return Double.NEGATIVE_INFINITY;
      double max = array[0];
      for(int i=1;i<array.length;i++)
          if(array[i]>max)
              max=array[i];
      return max;
    }//END OF METHOD

    /**Returns an array of the indexes of the maximal values in the array.  The return array will be of length 1 if the the input
     *array has a single maximal index.*/
    public static int [] maxIndexesInArray(double [] array){
        ArrayList list=new ArrayList();
        double max=maxInArray(array);
        for(int i=0;i<array.length;i++){
          if(array[i]==max)
              list.add(new Integer(i));
        }

        int [] retArray= new int[list.size()];
        Iterator it = list.iterator();
        int i=0;
        while(it.hasNext())
            retArray[i++]=((Integer)it.next()).intValue();
        return retArray;
    }//END OF METHOD

    /**For testing.*/
    public static void main(String [] args){
        int [] array={1,2,5,2,6,2,4,9,9};
        System.out.println("Here is the array:" + toStringArray(array,"<->"));
        System.out.println("And here it is after makeUniqueArray():"+ toStringArray(makeUniqueArray(array)));

    }//END OF MAIN METHOD FOR TESTING
}//END OF CLASS