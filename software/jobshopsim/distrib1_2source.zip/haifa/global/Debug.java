package haifa.global;

/**Has several static methods that help debugging.*/
public class Debug{

	public static void assert(boolean test, String msg){
		if(test==false)
			System.err.println("ASSERT ERROR: " +msg);
	}
}