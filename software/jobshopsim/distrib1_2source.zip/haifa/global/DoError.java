package haifa.global;

/**Has several static methods that perform generic operations in case of program error.*/
public class DoError {

    /**Prints msg to screen and exits application.*/
    public static void printAndQuit(String msg){
        System.err.println(msg);
        //System.exit(1);
    }
   
    /**Prints location and excpeion and exits application.*/
    public static void printAndQuit(String location,Exception e){
        e.printStackTrace();
      System.err.println("DURING: " + location + " CAUGHT THIS EXCEPTION: " +e);  
     // System.exit(1);
    }

    /**Prints location and excpeion and also additional info and exits application.*/
    public static void printAndQuit(String location,Exception e,Object moreInfo){
        e.printStackTrace();
      System.err.println("DURING: " + location + " CAUGHT THIS EXCEPTION: " +e + "\nAND SOME MORE INFO:"+moreInfo);  
      //System.exit(1);
    }
}//END OF CLASS