package eduni.simdiag;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/** The Graphics Area in which the Gantt Chart is actually drawn
 @authur Initially Fred Howel, converted to Swing by Yoni Nazarthy
 @version 1.1*/
class Diagram extends JPanel implements   AdjustmentListener {
  Dimension backingSize;
  Color bg;
  JScrollBar sb;
  Entries entries;

  int startx, starty;
  int Xpos, Opos;
  boolean movingX, movingO;
  double startt, endt;
  int keySpace = 50;

  Diagram( ) {
    bg = new Color(50,50,60);
    setBackground(bg);
    startx=0; starty=0;
    Xpos = 0; Opos = 0;
    movingX = false; movingO = false;
    entries = new Entries();
    startt = 0.0;
    endt   = entries.getEndTime();
  }

  void set_sb(JScrollBar s) { sb = s; s.addAdjustmentListener(this); }

  /* External commands */
  void reLayout() {
    entries.reset();
  }
  void processTrace(String t) {
    entries.addTrace(t);
  }
  void display() {
    unzoomb();	// Resets start + end times.
    repaint();
  }

  /* Utility methods */
  double xtot(int x) {
    return startt + ((double)x * (endt-startt) / (double)backingSize.width);
  }
  int ttox(double t ) {
    return  (int)(((double)backingSize.width) * (t-startt)/(endt-startt));
  }


  void zoomb() {
    int leftm = Xpos;
    int rightm = Opos;
    if (leftm > rightm) { leftm = Opos; rightm = Xpos; }
    if (rightm-leftm>5) {
      startt = xtot(leftm);
      endt = xtot(rightm);
    } else { // Default is zoom *2
      endt = startt + (endt-startt)/2;
    }
    sbset();
    repaint();
  }
  
  void sbset() {
    double theend = entries.getEndTime();
    int s1 =(int)( 1000.0 * (startt / theend));
    int s2 =(int)( 1000.0 * ((endt-startt) / theend));
    sb.setValues(s1, s2, 0, 1000);
  }
  
  void sbmoved() {
    int v = sb.getValue();
    double t = ((double)v / 1000.0) * entries.getEndTime();
    double delta = startt - t;
    startt = t;
    endt = endt - delta;
    repaint();
    }
  
    void unzoomb() {
    startt = 0.0;
    endt   = entries.getEndTime();
    sbset();
    repaint();
  }
 
  Entries getEntries() { return entries; }

  public void paintComponent(Graphics g) {
     super.paintComponent(g);
     Dimension d = getSize();
     backingSize = d;
     keySpace = (int)((double)backingSize.height * 0.10); //10% space used for timeline
     drawData(g);
  }

  double log10(double d) {
    return Math.log(d)/Math.log(10);
  }

  void drawNotches(Graphics g, int x1, int y1, int x2, int y2,
                   double v1, double v2) {
    boolean isXaxis = (y1==y2);
    double tsize = v2 - v1;                     // e.g. 17.2
    double tgaplog = log10( (double) tsize );   // e.g. 1.2ish
    int tgaprounded = (int)tgaplog;             // e.g. 1
    double tgapfinal = Math.pow( 10.0, (double) tgaprounded ); // e.g.10.0
    // Change to 0 5 10 etc?
    if (tsize/tgapfinal < 3.0) { tgapfinal /= 2.0; }

    // Get first point
    double div = 0.5 + (v1 / tgapfinal);
    int idiv = (int) div;
    double firstt1 = idiv * tgapfinal;


    g.setColor(Color.gray);
    g.drawLine(x1,y1,x2,y2);

    int notchHeight = keySpace/5;
    for (double t=firstt1; t<=v2; t+=tgapfinal ) {
      int xp = ttox(t);
      String s = Double.toString(t);
      g.setColor(Color.gray);
      g.drawLine(xp,y1,xp,notchHeight+y1);
      int w = g.getFontMetrics().stringWidth(s);
      int h = g.getFontMetrics().getHeight();
      int stry = y1+notchHeight+h;
      if (stry>y1+keySpace) stry = y1+keySpace;
      g.drawString(s,xp-w/2,stry);

      g.setColor(Color.gray.darker());
      g.drawLine(xp,y1,xp,0);
    }
  }

  void drawData(Graphics backg) {
    backg.setColor(bg);
    backg.translate(0,0);
    backg.fillRect(0,0,backingSize.width,backingSize.height);
    drawNotches(backg,0, backingSize.height- keySpace,
		backingSize.width, backingSize.height-keySpace,startt,endt);
    entries.draw(backg, startt, endt,backingSize.width,
		 backingSize.height - keySpace);
  }

  int abs(int a) { return (a<0) ? -a : a; }

  /** Respond to scroll bar events */
  public void adjustmentValueChanged(AdjustmentEvent e) {
    sbmoved();
  }
}//END OF CLASS