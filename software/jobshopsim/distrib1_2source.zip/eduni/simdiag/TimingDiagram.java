package eduni.simdiag;

import haifa.shopsim.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.net.*;
import java.applet.Applet;
import java.awt.event.*;

/**
 * This class represents the timing diagram application.
 * Note that it does not provide its own frame, it has
 * to be included in another frame.
 * The <a href="eduni.simdiag.TimingWindow.html">timing window</a>
 * embeds this into a window of its own.
 *<p>
 * This applet listens to trace events arriving, and also
 * passes them on to any registered listeners added using the
 * standard <a href="#addTraceListener">addTraceListener</a> method.
 *
 * @version     1.1
 * @author      Fred Howell, Yoni Nazarthy
 *
 *Modified by Yoni Nazarathy for Job Shop Simulator (to use swing)
 */
public class TimingDiagram extends JPanel implements
  TraceListener,  Traceable {
  
  Thread thread;
  Diagram diag;
  Key keys;
  JScrollBar hscroll;
  private TraceEventObject lastTraceEvent;
  
  /** Constructs a timing diagram */
  public TimingDiagram() {
    diag = new Diagram();
    setLayout(new BorderLayout());

   hscroll= new JScrollBar(JScrollBar.HORIZONTAL, 0, 1000, 0, 1000);
    diag.set_sb(hscroll);
    JPanel bottomPanel = new JPanel(new BorderLayout());
    Controls buttons = new Controls(diag);

    bottomPanel.add(hscroll,BorderLayout.NORTH);
    bottomPanel.add(buttons,BorderLayout.SOUTH);
    add(bottomPanel,BorderLayout.SOUTH);
    add(diag,BorderLayout.CENTER);
  }
  
   /** Processes the trace events which arrive. */
  public void handleTrace(TraceEventObject e) {
    //System.out.println("Timing Diagram got: " + e);
    lastTraceEvent = e;
    
    if (e.getCmd() == TRACE) {
      diag.processTrace(e.getLine());
    } else if (e.getCmd() == LAYOUT) {
      diag.reLayout();
    } else if (e.getCmd() == DISPLAY) {
      diag.display();
    }
  }
  
  /** Displays the graph */
  public void display() {
    diag.repaint();
  }
}//END OF CLASS TimingDiagram

class StringVector {
  protected Vector v;
  StringVector() { v = new Vector(); }
  Vector getV() { return v; }
  void add(String s) { v.addElement(s); }
  String get( int i ) { return (String)v.elementAt(i); }
  int find( String s ) {
    String found = null, curr;
    int foundi = 0, i=0;
    Enumeration e;
    for (e = v.elements(); e.hasMoreElements();i++) {
      curr = (String)e.nextElement();
      if(s.compareTo(curr) == 0) {
        found = curr;
	foundi = i;
      }
    }
    return foundi;
  }
}

/**
 * This class represents a data type to be displayed in
 * The timing diagram.
 * @version     1.0, June 1997
 * @author      Fred Howell
 */
class TypeParam {
  String typename;
  protected StringVector labels;
  TypeParam(String buff) {
    labels = new StringVector();
    StringTokenizer st = new StringTokenizer(buff, " ");
    typename = st.nextToken();
    while (st.hasMoreTokens())
      labels.add(st.nextToken());
  }
  String getLabel(int i) { return labels.get(i); }
  int get_index(String l) { return labels.find(l); }

  Color valtocol(int v) {
    if (v==0) return Color.blue;
    if (v==1) return Color.red;
    if (v==2) return Color.darkGray;
    if (v==3) return Color.gray;
    if (v==4) return Color.green;
    if (v==5) return Color.lightGray;
    if (v==6) return Color.magenta;
    if (v==7) return Color.orange;
    if (v==8) return Color.pink;
    if (v==9) return Color.red;
    if (v==10) return Color.white;
    return valtocol(v%10);
  }
  void drawKey(Graphics g, int x, int y, int w, int h) {
    g.setColor(Color.black);
    g.drawString(typename,x,y+h);

    // Draw blocks for labels too
    Enumeration e = labels.getV().elements();
    String curr;
    int i=0;
    int blksize = 20;
    for (;e.hasMoreElements();i++) {
      int keywidth = w / (labels.getV().size() +1);
      curr = (String)e.nextElement();
      g.setColor(Color.black);
      g.drawString(curr,x + (i+1)*keywidth, y+h);
      g.setColor(valtocol(i));
      g.fillRect(x + (i+1)*keywidth, y , keywidth, h/2);
    }
  }
}

class Types {
  protected Vector types;
  Types() { types = new Vector(); }
  void add(TypeParam tp) { types.addElement(tp); }
  TypeParam find( String s ) {
    TypeParam found = null, curr;
    int foundi = 0, i=0;
    Enumeration e;
    for (e = types.elements(); e.hasMoreElements();) {
      curr = (TypeParam)e.nextElement();
      if(s.compareTo(curr.typename) == 0) {
        found = curr;
      }
    }
    return found;
  }
  
  void drawKeys(Graphics g, int w, int h) {
    TypeParam curr;
    int i=0;
    Enumeration e;
    for (e = types.elements(); e.hasMoreElements();i++) {
      int keyheight = h / types.size();
      curr = (TypeParam)e.nextElement();
      curr.drawKey(g,0,i * keyheight, w, (int)(keyheight*0.7));
    }
  }
  Vector getV() { return types; }
}

class Event {
  double time;
  int stateno;
  Event() { time = -1; stateno = 0; }
  Event(double t, int s) { time = t; stateno = s; }
  boolean isblank() { return (time==-1); }
}//END OF CLASS


/**
 * This class represents an entry on the diagram
 * including all data.
 * @version     1.1
 * @author      Fred Howell, Yoni Nazarathy
 */
class Entry {

  protected String name;
  protected Vector events;
  protected TypeParam tp;
  int x,y,w,h;
  double startt, endt;

  Entry(String n, TypeParam tp) {
    name = n;
    events = new Vector();
    this.tp = tp;
    x = 0; y = 0; w = 100; h = 100;
  }

  TypeParam getType() { return tp; }
  void add(Event e) { events.addElement(e); }
  void setPosition(int x, int y, int w, int h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }

  int ttox(double t ) {
    return  (int)((w) * (t-startt)/(endt-startt));
  }

  Color valtocol(int v) {
    return tp.valtocol(v);
  }

  void drawLabel(Graphics g, int x, int y) {
    // Draw label
    g.setColor(Color.black);
    g.drawString(name,x,y);
  }

  // draw all events from t1 to t2.
  void draw(Graphics g, double t1, double t2) {
    startt = t1; endt = t2;

    
    // Get last event before starttime
    int ptri=0, previ=0;
    boolean found = false;
    int i=0;
    for (i=0; i<events.size() && !found; i++) {
      if (((Event)events.elementAt(i)).time > t1) {
	found = true;
	ptri = i;
	previ = ptri-1; if (previ<0) previ=0;
      }
    }

    

    boolean reachedend = false;
    for (; previ<events.size() && !reachedend; previ++) {
      double time1=t1,time2=t2;
      int val = 0;

      ptri = previ+1;

      Event prevevent = (Event)events.elementAt(previ);
      Event ptr;
      if (ptri<events.size())
	ptr = (Event)events.elementAt(ptri);
      else ptr = new Event();

      if (!prevevent.isblank()) {
	time1 = prevevent.time;
	val = prevevent.stateno;
      }
      if (!ptr.isblank())       time2 = ptr.time;

      if (time2 > t2) time2 = t2;
      if (time1 > t2) time1 = t2;

     
      g.setColor(valtocol(val));
      g.fillRect(ttox(time1),y, ttox(time2)-ttox(time1),h);

      if (prevevent.time > t2) reachedend = true;
    }

  }
}//END OF CLASS

/**
 * This class loads and stores all data entries
 * @version     1.1
 * @author      Fred Howel, Yoni Nazarthy
 *Modified by Yoni Nazarathy
 */
class Entries {
  protected Vector entries;
  protected Types types;

  double starttime, endtime;

  Entries() {
    entries = new Vector();
    types   = new Types();
    starttime = 0.0;
    endtime   = 1.0;
  }

  /* External commands */
  void reset() {
    entries.removeAllElements();
    types.getV().removeAllElements();
    starttime = 0.0;
    endtime   = 1.0;
  }

  /** Add a single trace line
   * return 1 if successful
   */
  final int TYPES  = 0;
  final int BARS   = 1;
  final int EVENTS = 2;
  int section = TYPES;
  int addTrace(String l) {
    int success = 1;
    if (l.startsWith("$")) {
      if ("$types".compareTo(l) == 0)        section = TYPES;
      else if ("$bars".compareTo(l) == 0)    section = BARS;
      else if ("$events".compareTo(l) == 0)  section = EVENTS;
      else {
	System.err.println("Couldn't read section name "+l);
	success = 0;
      }
    } else if (section==TYPES) {
      // Format: typename flag1 flag2 ...
      types.add(new TypeParam(l));
    } else if (section==BARS) {
      // Format: barname bartype
      StringTokenizer st = new StringTokenizer(l);
      String barname, bartype;
      if (st.hasMoreTokens()) {
	barname = st.nextToken();
	if (st.hasMoreTokens()) {
	  bartype = st.nextToken();
	  TypeParam btp = types.find(bartype);
	  if (btp!=null) {
	    entries.addElement(new Entry(barname, btp));
	  } else {
	    System.err.println("Couldn't find type "+bartype);
	    success = 0;
	  }
	}
      }
    } else if (section==EVENTS) {
      StringTokenizer st = new StringTokenizer(l, ": \n\r\t");
      if(st.nextToken().charAt(0) != 'u')
	;//System.out.println("Error: Only do 'u:' traces");
      else {
	String barname = st.nextToken();
	Entry e = find(barname);
	if (e==null)
	  ;// System.out.println("Couldn't find bar:"+barname);
	else {
	  st.nextToken(); // skip 'at'
	  double timestamp =
	    (Double.valueOf(st.nextToken())).doubleValue();
	  if (timestamp > endtime) endtime = timestamp;
	  switch(st.nextToken().charAt(0)) {
	  case('P'):
	    String val = st.nextToken();
	    int stateno = e.getType().get_index(val);
	    e.add(new Event(timestamp, stateno));
	    break;
	  default:
	    success = 0;
	    ;//System.out.println("Error: event type not P\n\t"+s);
	    break;
	  }
	}
      }
    }
    return success;
  }


  Types getTypes() { return types; }
  double getStartTime() { return starttime; }
  double getEndTime() { return endtime; }
  void draw(Graphics g, double t1, double t2, int w, int h) {
    Enumeration e;
    int i=0;
    int n = entries.size();
    if (n>0) {
      double wavespace  = h / n;
      double waveheight = wavespace * 0.75;
      for (e = entries.elements(); e.hasMoreElements();i++) {
	Entry en = (Entry)(e.nextElement());
	en.setPosition(0,i * (int)wavespace, w, (int)waveheight);
	en.draw(g,t1,t2);
      }
    }
  }
  void drawLabels(Graphics g, int w, int h) {
    Enumeration e;
    int i=0;
    int n = entries.size();
    if (n>0) {
      double wavespace  = h / n;
      double waveheight = wavespace * 0.5;
      for (e = entries.elements(); e.hasMoreElements();i++) {
	Entry en = (Entry)(e.nextElement());
	en.drawLabel(g, 0,i * (int)wavespace +  (int)waveheight );
      }
    }
  }
  Entry find( String s ) {
    Entry found = null, curr;
    Enumeration e;
    for (e = entries.elements(); e.hasMoreElements();) {
      curr = (Entry)e.nextElement();
      if (s.compareTo(curr.name) == 0) { found = curr; }
    }
    return found;
  }
}//END OF CLASS

/**Zoom and unzoom buttons.
 *@version 1.1
 */
class Controls extends JPanel implements ActionListener {
  JButton zoomb, unzoomb, reloadb;
  Diagram d;

  Controls(Diagram d) {
    this.d = d;
    setLayout(new GridLayout(1,2,5,5));
    add(zoomb=new JButton("Zoom"));
    add(unzoomb=new JButton("Unzoom"));
    zoomb.addActionListener(this);
    unzoomb.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e) {
    Object source = e.getSource();
    if (source == zoomb) { d.zoomb(); }
    if (source == unzoomb) { d.unzoomb(); }
  }
}//END OF CLASS CONTROLS
