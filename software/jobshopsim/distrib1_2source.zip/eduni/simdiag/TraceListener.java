
package eduni.simdiag;
 
import java.awt.*;
import java.util.EventObject;
import java.util.*;

/**
 * Timing diagram event listener interface 
 *@version 1.1
 */
 public interface TraceListener extends EventListener {
  /** Processes the given trace event object.
   */
  void handleTrace(TraceEventObject teo);
}