VERSION 0.4
May 8,2001

README FILE FOR Job Shop Simulator by Yoni Nazarathy, Supervised by Gideon Weiss.

Thank you for taking the time to download this package.  I hope you will enjoy it and maybe make use of it. 


The zip file contains the following files:
1)This README.txt file.
2)Some *.jbs files. These have information regarding the job shop. Specifically the file 3machine2way.jbs is well commented and may be useful.
3)shopsim.jar file.  This file contains all of the classes (Java bytecode) which are ready to run.

Requirements:
A machine with a Java runtime environment (JRE) (Version 1.3) installed on it.  This may be a Windows, Linux or Solaris machine (As for Macs there is still some problem with Java V1.3/1.2).  It may be possible that the software runs with JRE V1.2, but it hasn't been tested. Note that the software has been tested on a Windows, Linux and a Solaris machine.

Instructions:
1) Unzip the files in the .zip file into some directory.
2) Run shopsim.jar.  On a windows machine do this by double clicking the icon.  On other machines type:
java -jar shopsim.jar
3) Play around with the program. You may obviously create your own data files.
4)Problems: You most probably don't have the JRE 1.3 so you can't run the software...
GETTING JRE Version 1.3:
You need to get JRE1.3 so that you can run the software.  This is very easy. Go to the site:http://www.javasoft.com/j2se/1.3/jre/index.html and download and install the JRE. Note: If you have a windows machine with Internet Explorer 4.0 you can install the JRE in an even more automatic manner: Go to this program's applet's page: http://rstat.haifa.ac.il/~yonin/thesis/jobshopsim/run.html and let the JRE automatically install!  (You may have to click some OK's on the way.)

License Agreement: None. You may try to sell this program, but the odds are against you!:-)

Questions...
I'll be very very happy to talk: ynazarty@study.haifa.ac.il


