java -jar shopsim.jar shop1.dat
