Job Shop Simulation By Yoni Nazarathy
Haifa University, Israel

Preliminary version: 0.1

1) You may do anything with the code, even sell it and become a millioner.
2) I don't think you'll be able to do that but you can try.
3) To run without much investigation double click one of the five batch files:
	shop1.bat .... shop5.bat
   These need to be in the same directory as the shopsim.jar file and corresponding
   .dat files.
4) This version does not support any other menu features except: Exit, and Run Manual
   The other features are bound to cause problems.
5) This package uses javaSimulation by Keld Helsgaun: http://www.dat.ruc.dk/~keld/


		Enjoy.