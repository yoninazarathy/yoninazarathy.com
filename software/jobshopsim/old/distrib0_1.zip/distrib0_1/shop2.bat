java -jar shopsim.jar shop2.dat
