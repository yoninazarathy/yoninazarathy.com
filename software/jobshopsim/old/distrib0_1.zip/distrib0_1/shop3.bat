java -jar shopsim.jar shop3.dat
