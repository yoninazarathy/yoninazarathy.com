java -jar shopsim.jar shop4.dat
