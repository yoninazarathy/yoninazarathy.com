package haifa.shopsim;

import java.util.*;
import haifa.global.Debug;

/**This class represents the state of the jobshop at a given time instance
as it is seen by an Algorithm. All the
changes that occur during the simulation should be reflected in this class. This class
is also used to schedule. (i.e. the scheduling algorithm should be able to generetate
it's next command using the information in this class. Currently the state is the
following:<P>
<ol>
<li> A Map of all of the sizes of all of the queues in the system.
<li> An array of booleans where the i'th element signifies if the i'th machine is
vacant.  (The array indexes are 0,....,shop.getN()-1). So element i actually refers to
machine i+1.
</ol>*/
public class ShopStateImpl implements ShopState{

	//////////////////////////////////////////////
	//THE INFORMATION THAT MAKES UP THE STATE/////
	//////////////////////////////////////////////
	/**Indicates that the shop is running.*/
	private boolean isRunning;

	/**A Map mapping Operation objects to sizes of queues.*/
	private HashMap QMap;

	/**An array specifiing which of the machines is currently busy.*/
	private boolean [] workingMachines;

	/**an array specifing how many finshed jobs per route.*/
	private int [] finishedJobs;

	/**The current simulation time.*/
	private double time;

	/**A reference to the shop data object.*/
	private ShopData shopData;

	/**A list of all listeners to this state, that is all classes that should be
	notified when the state changes.*/
	private ArrayList shopChangeListeners = new ArrayList();

	/**Register a listener to the state.*/
	public void addShopChangeListener(ShopChangeListener scl){
		shopChangeListeners.add(scl);
	}

	public void shopChanged(ShopChangeEvent sce){
		Debug.assert(sce.getTime() >= time, "IN SHOP STATE PROBLEM WITH TIME");
		time = sce.getTime();
		if(sce instanceof ShopStartedEvent){
			QMap.putAll(((ShopStartedEvent)sce).getQMap());
			isRunning=true;
		}else if(sce instanceof MachineStartedEvent){
			int machineNum=((MachineStartedEvent)sce).getMachineNumber();
			Debug.assert(workingMachines[machineNum-1]==false,
						"COMMAND FOR WORKING MACHINE TO START WORKING");
			workingMachines[machineNum-1]=true;
		}else if(sce instanceof MachineFinishedEvent){
			int machineNum = ((MachineFinishedEvent)sce).getMachineNumber();
			Debug.assert(workingMachines[machineNum-1]==true,
						"COMMAND FOR FINISH OF MACHINE THAT WAS'NT WORKING");
			workingMachines[machineNum-1]=false;
			Operation finished = ((MachineFinishedEvent)sce).getFinishedOperation();
			Operation next = ((MachineFinishedEvent)sce).getNextOperation();
			QMap.put(finished,new Integer(((Integer)QMap.get(finished)).intValue()-1));
			if(next !=null)//if not last job of route
				QMap.put(next,new Integer(((Integer)QMap.get(next)).intValue()+1));
		}else if(sce instanceof ShopFinishedEvent){
			Debug.assert(QMap.values().size()==0,"SHOP FINISHED, BUT Q'S AREN'T EMPTY");
			isRunning=false;
		}else if(sce instanceof JobFinishedEvent){
			finishedJobs[((JobFinishedEvent)sce).getRouteNumber()-1]++;
		}else{
			System.out.println("WIERD EVENT");
			System.exit(1);
		}

		//PASS EVENTS ON TO LITENERS
		Iterator it = shopChangeListeners.iterator();
		while(it.hasNext()){
			((ShopChangeListener)it.next()).shopChanged(sce);
		}
	}

	/**Cot'r builds state according to ShopData.*/
	public ShopStateImpl(ShopData shopData_){
		shopData=shopData_;

		workingMachines=new boolean[shopData.getI()];
		finishedJobs = new int[shopData.getR()];

		try{
			QMap = new HashMap(shopData.getK());
			for(int r=1;r<=shopData.getR();r++){
				List ops = shopData.getRoute(r);
				Iterator it = ops.iterator();
				while(it.hasNext()){
					QMap.put((Operation)it.next(),new Integer(0));
				}
			}
		}catch(Exception e){
			System.err.println(e);
			System.exit(1);
		}
	}

	/**Takes operation objects from opMap and updates relevant ones*/
	public void update(Map opMap){
		Iterator it = opMap.keySet().iterator();
		while(it.hasNext()){
			if(!(it.next() instanceof Operation))
				throw new Error("Problem with map");
		}
		QMap.putAll(opMap);
	}

	/**Returns string representing the ShopState*/
	public String toString(){
		return "Shop State (at time " + time +"): " +QMap.toString();

	}

	/**Returns the time as registered with the state.*/
	public double getTime(){
		return time;
	}

	/**Returns a collection of all of the busy machines at the current time.*/
	public Collection getBusyMachines(){
		Collection c = new ArrayList(workingMachines.length);
		for(int i=0;i<workingMachines.length;i++)
			if(workingMachines[i]==true)
				c.add(new Integer(i+1));
		return c;
	}

	/**Returns the total number of finished jobs.*/
	public int getTotalFinishedJobs(){
		int total=0;
		for(int r=0;r<finishedJobs.length;r++)
			total+=finishedJobs[r];
		return total;
	}

	/**Returns the number of finsihed jobs on a particular route.*/
	public int getNumFinishedJobs(int route){
		return finishedJobs[route-1];
	}

	public Map getQMap(){
		return QMap;
	}

	/**Returns a collection of the schedulable operations.*/
	public Collection getSchedulableOperations(){
		Collection opc = new ArrayList();
		Iterator it = QMap.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry me = (Map.Entry)it.next();
			if(((Integer)me.getValue()).intValue()==0)
				continue;
			Operation op = (Operation)me.getKey();
			int machine = shopData.getMachine(op);
			if(workingMachines[machine-1]==false)
				 opc.add(op);
		}
		return opc;
	}
}//END OF CLASS