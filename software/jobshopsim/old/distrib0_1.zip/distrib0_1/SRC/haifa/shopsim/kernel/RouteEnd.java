package haifa.shopsim.kernel;

import haifa.shopsim.*;

import javaSimulation.*;
import javaSimulation.Process;


/**This class is the output pile of a route.*/
class RouteEnd extends Process implements JobHolder{
	ShopData shopData;
	ShopRun shopRun;
	int routeNumber;

	int accumulatedJobs=0;

	/**A queue of the finished jobs.*/
	Head finishedQueue = new Head();

	JobHolder previous;

	public RouteEnd(ShopData shopData_,ShopRun shopRun_, int routeNumber_){
		shopData = shopData_;
		shopRun = shopRun_;
		routeNumber = routeNumber_;
	}

	public void getJob(Job job){
		shopRun.notifyListeners(
			new JobFinishedEvent(this,time(),
									"JOB ID HERE",routeNumber));
		accumulatedJobs++;
		shopRun.unfinishedJobs--;
		activate(shopRun);
	}

	public void actions(){
	}

}//END OF CLASS
