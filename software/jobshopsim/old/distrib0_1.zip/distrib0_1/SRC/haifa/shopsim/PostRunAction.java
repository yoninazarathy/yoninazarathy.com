package haifa.shopsim;

public interface PostRunAction{
	public void doAction();
}