package haifa.shopsim.UI;

import haifa.shopsim.*;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**The GUIAlgorithm is actually not an algorithm, but a user control
through which the user may be asked to control the shops at discrete simulation
epochs*/
class GUIforComputerAlgorithm extends JPanel implements ShopAlgorithm{

	ShopState shopState;
	ShopData shopData;
	JComponent visualShopStateObject;
	PrintWriter log;
	ShopAlgorithm shopAlgorithm;

	JLabel nameLabel;
	JTextArea explanationArea;
	JButton stepButton;
	JButton goButton;
	JButton stopButton;
	JLabel commandLabel;
	JPanel centerPanel;
	JPanel buttonPanel;

	BusyAnimation animLeft;
	BusyAnimation animRight;

	GUIforComputerAlgorithm(ShopAlgorithm shopAlgorithm_,
							ShopData shopData_,
							ShopState shopState_,
							JComponent visualShopStateObject_,
							JLabel commandLabel_,
							JLabel timeLabel_) {
			shopData = shopData_;
			shopState = shopState_;
			visualShopStateObject = visualShopStateObject_;
			shopAlgorithm = shopAlgorithm_;
			commandLabel = commandLabel_;

			setLayout(new BorderLayout());

			add(centerPanel = new JPanel(new BorderLayout()),BorderLayout.CENTER);
			centerPanel.add(nameLabel = new JLabel(shopAlgorithm.getAlgorithmName() +
									" Algorithm",SwingConstants.CENTER),
									BorderLayout.NORTH);
			centerPanel.add(buttonPanel = new JPanel(new GridLayout(1,3)),BorderLayout.SOUTH);
			buttonPanel.add(stepButton = new JButton("Step"));
			buttonPanel.add(goButton = new JButton("Go"));
			buttonPanel.add(stopButton = new JButton("Stop"));

				stepButton.addActionListener(new StepL());
				goButton.addActionListener(new GoL());
				stopButton.addActionListener(new StopL());
				stopButton.setEnabled(false);

			nameLabel.setBackground(Color.green);
						nameLabel.setForeground(Color.black);
			nameLabel.setOpaque(true);

			add(animLeft = new BusyAnimation(),BorderLayout.WEST);
			add(animRight = new BusyAnimation(),BorderLayout.EAST);
			commandLabel.setText("Processing...");


	}


	boolean go;
	boolean step;

	class GoL implements ActionListener{
		public void actionPerformed(ActionEvent ae){
			animLeft.start();
			animRight.start();
			goButton.setEnabled(false);
			stepButton.setEnabled(false);
			stopButton.setEnabled(true);
			go=true;
			synchronized(GUIforComputerAlgorithm.this){
				GUIforComputerAlgorithm.this.notify();
			}
		}
	}

	class StopL implements ActionListener{
			public void actionPerformed(ActionEvent ae){
				animLeft.stop();
				animRight.stop();
				stopButton.setEnabled(false);
				goButton.setEnabled(true);
				stepButton.setEnabled(true);
				go=false;
				synchronized(GUIforComputerAlgorithm.this){
					GUIforComputerAlgorithm.this.notify();
				}
			}
	}

	class StepL implements ActionListener{
			public void actionPerformed(ActionEvent ae){
				animLeft.step();
				animRight.step();
				step=true;
				synchronized(GUIforComputerAlgorithm.this){
					GUIforComputerAlgorithm.this.notify();
				}
			}
	}

	/**Passes on to hosted shop algorithm*/
	public void setShopStateObject(ShopState shopState_){
		shopAlgorithm.setShopStateObject(shopState = shopState_);;
	}

	/**Passes on to hosted shop algorithm*/
	public void setShopData(ShopData shopData_){
		shopAlgorithm.setShopData(shopData=shopData_);
	}

	/**Passes on to hosted shop algorithm*/
	public void setLog(PrintWriter log_){
		shopAlgorithm.setLog(log=log_);
	}

	/**Passes on to hosted shop algorithm*/
	public ShopCommand whatNow(int machineNumber){
		synchronized(this){
			while(go==false && step==false)
				try{wait();}catch(InterruptedException e){}
		}
		step=false;
		return shopAlgorithm.whatNow(machineNumber);
	}

	/**Passes on to hosted shop algorithm*/
	public boolean quitCalled(){
		return shopAlgorithm.quitCalled();
	}

	/***/
	public String explanationString(){
		return shopAlgorithm.explanationString();
	}

	/**Returns false since the user's actions are not specified in the algorithm.*/
	public boolean isDeterministic(){
		return shopAlgorithm.isDeterministic();
	}

	public String getAlgorithmName(){
		return shopAlgorithm.getAlgorithmName();
	}

	public String toString(){
		return getAlgorithmName();
	}
}//END OF CLASS
