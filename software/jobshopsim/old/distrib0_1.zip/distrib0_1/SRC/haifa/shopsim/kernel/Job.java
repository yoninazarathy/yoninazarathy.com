package haifa.shopsim.kernel;

import haifa.shopsim.*;

import javaSimulation.*;

/**The Job is actually a token that travels thourgh the system.*/
class Job extends Link implements SimulationEntity{

	/**A refrence to the data about the jobShop.*/
	ShopData shopData;

	/**The type of the job*/
	int type;

	/**Determines the most recent step of processing that the job has experienced
	so far.*/
	int step=0;

	/**This variable counts how many job objects have been allocated. It is incremented
	whenever a new job is constructed. Currently it's primary use is for debugging
	(assserting).*/
	static int jobCount=0;

	/**Allocate a new job.*/
	Job(ShopData shopData_, int type_){
		shopData = shopData_;
		type = type_;
		jobCount++;
	}

	public String toString(){
		return "type: " + type + " , step: " + step;

	}
}//END OF CLASS