package haifa.shopsim;

import java.io.*;

/**A ShopAlgorithm (GFA,CFA,manual etc...) has associations to a ShopState
object (An object representing the current state of the shop), a ShopData
object (the shop topology and jobs processing times), and a log into which it
writes infomration regarding it's processing.<P>
It is recommended that the constructors will not be heavy.*/
public interface ShopAlgorithm{

	////////////////////////////////////////////////////////////
	/////////////THE IMPORTANT METHODS//////////////////////////
	////////////////////////////////////////////////////////////

	/**Returns a ShopCommand class which has the directions on the next immidiate
	action to do for the specific machine.<p>
	This method looks at the shop state objects and decides.*/
	public ShopCommand whatNow(int machineNumber);

	/**Returns true when the algorithm decided that it is time to quit.*/
	public boolean quitCalled();

	/////////////////////////////////////////////////////////////////
	///////////////AUXILLARY METHODS/////////////////////////////////
	/////////////////////////////////////////////////////////////////

	/**Set the algorithm's ShopState object. The algorithm looks at this Object and
	makes decisions based on it whenever the whatNow message is called.*/
	public void setShopStateObject(ShopState shopState);

	/**Set the algorithm's shopData object, this is a reference for the general topology
	of the job shop and for processing times.*/
	public void setShopData(ShopData shopData);

	/**The algorithm writes decision information to the log.*/
	public void setLog(PrintWriter log);


	/////////////////////////////////////////////
	///////////GENERAL INFO METHODS//////////////
	/////////////////////////////////////////////
	/**Returns a string telling a little bit about what the algorithm does.*/
	public String explanationString();

	/**Returns true if the algorithm is determinsitic.*/
	public boolean isDeterministic();

	/**Returns a name of the algorithm.*/
	public String getAlgorithmName();

}//END OF INTERFACE
