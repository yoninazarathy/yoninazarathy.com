package haifa.shopsim.UI;

import haifa.shopsim.*;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;

/**This class displays the state of the algorithm.*/
class StateTable extends JPanel implements ShopChangeListener{

	ShopState shopState;
	ShopData shopData;
	Vector rowData;

	JPanel topPanel;
		JLabel timeLabel;
		JLabel busyLabel;
	JTable bufferTable;
	JLabel bottomLabel;

	/**Updates shopState refrence and refreshes display.*/
	public void setShopState(ShopState shopState_){
		shopState=shopState_;
		repaint();
	}

	/**Responds to an event.*/
	public void shopChanged(ShopChangeEvent sce){
		repaint();
	}

	/**Uses info in shopState*/
	public void repaint(){
		//ask if not null because maybe cot'r still hasn't been called
		if(bufferTable != null){
			timeLabel.setText("TIME: " + shopState.getTime());
			busyLabel.setText("Busy Machines: " + shopState.getBusyMachines());
			bottomLabel.setText("Finished Jobs: " + shopState.getTotalFinishedJobs());
			bufferTable.repaint();
			Iterator val = shopState.getQMap().values().iterator();
			int i=0;
			while(val.hasNext()){
				((Vector)rowData.get(i++)).set(1,val.next());
			}

		}
		super.repaint();
	}//end of repaint();

	StateTable(ShopData shopData_,ShopState shopState_) {
			shopData = shopData_;
			shopState = shopState_;

			setLayout(new BorderLayout());

			Vector collNames = new Vector(2);
			collNames.add("(r,o) on \u03C3(r,o)");
			collNames.add("Queue Size");
			rowData = new Vector(shopData.getK());
			Iterator it = shopState.getQMap().keySet().iterator();
			Iterator val = shopState.getQMap().values().iterator();
			while(it.hasNext()){
				Vector row = new Vector(2);
				Operation op=(Operation)it.next();
				row.add(op.toString()+ " on " + shopData.getMachine(op));
				row.add(val.next());
				rowData.add(row);
			}
			add(topPanel = new JPanel(new GridLayout(2,1)),BorderLayout.NORTH);
				topPanel.add(timeLabel = new JLabel("",SwingConstants.CENTER));
				topPanel.add(busyLabel = new JLabel());

			timeLabel.setBackground(Color.black);
			timeLabel.setForeground(Color.white);
			timeLabel.setOpaque(true);
			timeLabel.setFont(new Font("Dialog",Font.BOLD,16));
			timeLabel.setText("TIME: " + shopState.getTime());

			busyLabel.setBackground(Color.white);
			busyLabel.setForeground(Color.black);
			busyLabel.setOpaque(true);
			busyLabel.setText("Busy Machines: " + shopState.getBusyMachines());

			add(new JScrollPane(bufferTable = new JTable(rowData,collNames)),BorderLayout.CENTER);
			add(bottomLabel = new JLabel(""),BorderLayout.SOUTH);

			bottomLabel.setBackground(Color.cyan);
			bottomLabel.setForeground(Color.black);
			bottomLabel.setOpaque(true);
			bottomLabel.setText("Finished Jobs: " + shopState.getTotalFinishedJobs());

			bufferTable.setColumnSelectionAllowed(false);
	}//END OF COT'R
}//END OF CLASS
