package haifa.shopsim.kernel;

import haifa.shopsim.*;

import haifa.global.Debug;

import java.util.*;

import javaSimulation.*;
import javaSimulation.Process;


/**This class is an enity in the simulation. It's state represents the state of a
machine working in the job shop at a given point in time.
It contains a HashMap of Machine.JobClass objects.
Each of these objects has a reference to the machine that passes jobs of
such a class to the current machine and to the machine which is the
destination of jobs after they are finished.
(These do not have to be machines but actually JobHolders
(they can also be route ends and starts). <P>
The Machine class uses it's reference to the shopRun class to ask questions such
as who to schedule, and if quit has been called.*/
class Machine extends Process implements JobHolder{

	/**Determines whether the machine is currently processing a job or is idle.*/
	private boolean processing=false;

	/**Maps the classes(buffers) in a shop. A class is identified by an Operation
	object.*/
	private HashMap classes;

	/**A reference to the data.*/
	private ShopData shopData;

	/**The machine number of the machine as specified by the shopData.*/
	private int machineNumber;

	/**A reference to the ShopRun object, the main process.*/
	private ShopRun shopRun;

	/**Returns true if the Machine is currently processing a job.*/
	boolean isProcessing(){
		return processing;
	}

	/**Constructor sets up all of the buffers (JobClass objects).*/
	Machine(ShopData shopData_, int machineNumber_, ShopRun shopRun_){
		shopData = shopData_;
		machineNumber =machineNumber_;
		shopRun=shopRun_;

		//create a HashMap of all of the operations
		List ops = shopData.getCi(machineNumber);
		classes= new HashMap(ops.size());
		Iterator it = ops.iterator();
		while(it.hasNext()){
			//associate a JobClass object with each operation
			classes.put(it.next(),new JobClass());
		}
	}

	/**Convinience class that helps setup network of routes.*/
	void bindInput(Operation op, JobHolder input_){
		((JobClass)classes.get(op)).input = input_;
	}

	/**Convencie class that helps setup network of routes.*/
	void bindOutput(Operation op, JobHolder output_){
		((JobClass)classes.get(op)).output = output_;
	}

	/**Returns a map of the Q lengths for each of the operations that the job has.
	(Based on the classes map.)*/
	Map getQMap(){
		Iterator it=classes.entrySet().iterator();
		HashMap QMap = new HashMap();
		while(it.hasNext()){
			Map.Entry entry = (Map.Entry)it.next();
			Operation op = (Operation)entry.getKey();
			Integer size = new
				Integer(((JobClass)entry.getValue()).inQueue.cardinal());
			QMap.put(op,size);
		}
		return QMap;
	}


	/**Returns true if all buffers for machine are empty.*/
	boolean isEmpty(){
		Iterator it = classes.values().iterator();
		while(it.hasNext()){//loop untill finding a non empty buffer
			if(!((JobClass)it.next()).inQueue.empty())
				return false;
		}
		return true;//if here than all buffers were empty
	}


	double restTime;

	/**The actions that a machine performs are the following: If all buffers are
	empty, call the doSchedule method which will handle things with the shop
	algorithm and determine which buffer to draw from next. The machine should then
	"start processing" the job by holding for the job processing time. (currently
	there is no preemption).*/
	public void actions(){
		//loop as long as the shop algorithm has not decided to quit
		//this loop may also be interrupted while this machine inquires the
		//shop algortihm for the next command

		while(shopRun.quitCalled()==false){
			shopRun.awakenRestingMachines();
			if(isEmpty()){
				processing=false;
				passivate();//put machine to sleep untill next time
				continue;
			}else{//machine is not empty so schedule something
				ShopCommand nextCommand = shopRun.whatNow(machineNumber);
				if(nextCommand.isQuit()){//if quit then stop process
					return;//break
				}
				if(nextCommand.isRest()){//go to sleep
					processing=false;
					restTime=time();
					shopRun.restingMachines.put(new Double(time()),this);
					//put process to sleep in the resting machines array
					passivate();
					continue;
				}
				Operation nextOp = nextCommand.op;
					//get operation that command specifies

				JobClass jobClass = //get the jobClass of the operation scheduled
							(JobClass)classes.get(nextOp);
				Debug.assert(jobClass.inQueue.empty() == false,
								"ASSERT ERROR IN ACTIONS OF MACHINE");

				Job job = (Job)jobClass.inQueue.first();//take job out of queue
				job.out();
				//process the job
				processing=true;
				job.step++;//at the epoch in which the job is getting processed
							//we increase it's step state by 1
				shopRun.notifyListeners(new MachineStartedEvent(this,
																time(),
																machineNumber,
																nextOp,
																"JOB ID HERE"));
				hold(shopData.getXto(job.type,job.step));

				Operation nextNextOp;
				if(jobClass.output instanceof RouteEnd)
					nextNextOp = null;
				else
					nextNextOp = new Operation(nextOp.getRoute(),nextOp.getStep()+1);
				shopRun.notifyListeners(new MachineFinishedEvent(	this,
																	time(),
																	machineNumber,
																	/**next here*/0,
																	"JOB ID HERE",
																	nextOp,
																	nextNextOp
																	));
				jobClass.output.getJob(job);//pass job onto next machine after processing
				activate((Process)jobClass.output);
			}//end of block that occurs if a job is to be processed
		}//end of loop that goes on as long as process continues
	}//end of actions() method

	/**Returns the machineNumber in a string.*/
	public String toString(){
		return "Machine #" + machineNumber;
	}


	/**Get a job and put in the appropriate JobClass. This method is to be used by the predecessor of the machine*/
	public void getJob(Job job){
		int route = 0 ;
		try{//determine the route that this job belongs to
			route = shopData.getRouteOfType(job.type);
		}catch(Exception e){
			System.err.println(e);
			System.exit(1);
		}//create the operation that this job will now wait for
		Operation op = new Operation(route,job.step+1);//it has done job.step operations
													//so it is waiting for the step+1 op
		JobClass jc = (JobClass)classes.get(op);
		job.into(jc.inQueue);
	}

	/**This inner class represents a buffer in a machine. It has a reference to the
	Object from which input is recieved and a reference to the Object to which the
	buffer outputs.*/
	private class JobClass{
		boolean inProcess;

		/**Reference to Object from which jobs are drawn.*/
		JobHolder input;

		/**The queue for incoming jobs.*/
		Head inQueue = new Head();

		/**Refrence to Object into which jobs are put when finished*/
		JobHolder output;
	}//END OF INNER CLASS
}//END OF CLASS