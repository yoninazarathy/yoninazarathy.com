package haifa.shopsim.UI;

import haifa.shopsim.*;
import haifa.shopsim.kernel.*;
import haifa.shopsim.algorithms.*;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.*;


/**This class is one of the several usuable products of the JobShopSimualtion Project.
It is the Algorithm testing/educational tool. It is the class that should be run
as the main class when running this tool as a stand alone application.
It may also be run as an applet. See the main() method
for information on command line parameters.<P>
When run as an applet, job shop files may be loaded only from the host at
which the applet is sitting. This should suffice for demonstration purpuses.
see the init() method.<P>
Applet code should be (assuming that a .jar file is used):
<PRE>
<APPLET archive = "shopsim.jar"
		code = "haifa.shopsim.UI.MainGUI"
		width = 600 height = 400 >
		<param name = "SHOP_DATA1" value = "shop1.dat">
		<param name = "SHOP_DATA2" value = "somefile.dat">
		...
</APPLET>

</PRE>
<P>
Note that the SHOP_DATA1 file is the one that is opened initially*/
public class MainGUI extends JApplet{

	/**Counts how many times the user started a simulation.*/
	private int numSimulations;

	/**If the user chooses exit during an applet, it is brought to this page.*/
	private  final String  HOME_PAGE = "http://study.haifa.ac.il/~ynazarty/";

	/**False if applet true if application*/
	private static boolean isApplication;

	/**Used when working with a JFrame and setting a menu.*/
	private JRootPane rootPane;

	//MAIN COMPONENETS OF GUI
	private JPanel mainPanel;//includes the whole GUI
	private JPanel topPanel;//includes command line and algorithm panel
	private JPanel centerPanel;//includes Table,Gant,Anim and Data
	private JComponent ganttArea;
	private JComponent animArea;
	private JTextArea shopDataArea;
	private JLabel commandLabel;
	private JMenuBar menuBar = new JMenuBar();
	private JMenu fileMenu = new JMenu("File");
	private JMenu algorithmMenu = new JMenu("Algorithm");

	/**Stores names of urls specified by html to applet of data files.*/
	private ArrayList dataFiles = new ArrayList();

	/**Action events of the file menu. Each of these has a corresponeding inner
	class.*/
	Action [] fileMenuActions = {
				new OpenAction(),
				new ViewLogAction(),
				new ExitAction()
				};

	/**A reference to the shopRun object (the object that runs the simulation).*/
	private ShopRun shopRun;

	/**A refrence to the currently selected shopAlgorithm, may be null.*/
	private ShopAlgorithm currentAlgorithm;

	/**A reference to the data regarding the current job shop.*/
	private ShopData shopData;

	/**A refrence to the shopState.*/
	private ShopState shopState;

	/**A reference to the stateTable*/
	private StateTable stateTable;

	/**Sets up everything. Returns 'this'. This is basically like a co'tr*/
	public MainGUI setUp(String dataName, JRootPane rootPane_){
		rootPane = rootPane_;
		Reader reader=null;
		try{//READ DATA
			if(isApplication){//read from local file
				reader = new InputStreamReader(
							new FileInputStream(dataName));
			}
			else{//if applet read from URL
				URL url = new URL(dataName);
				reader = new InputStreamReader(
							url.openConnection().getInputStream());
			}
			shopData = new GeneralShopDataArray(reader);
		}catch(Exception e){
			System.err.println(e);
			return this;
		}

		shopState = new ShopStateImpl(shopData);

		mainPanel = new JPanel(new BorderLayout());
		mainPanel.add(topPanel = new JPanel(new BorderLayout()),
								BorderLayout.NORTH);
			topPanel.add(commandLabel =
				new JLabel("To start, select an algorithm from the menu",
				SwingConstants.CENTER),BorderLayout.NORTH);

			commandLabel.setBackground(Color.yellow);
			commandLabel.setForeground(Color.red);
			commandLabel.setOpaque(true);
			commandLabel.setFont(new Font("Dialog",Font.BOLD,18));

		mainPanel.add(centerPanel = new JPanel(new GridLayout(2,2,5,5)),
								BorderLayout.CENTER);
			centerPanel.add(stateTable = new StateTable(shopData,shopState));
			centerPanel.add(ganttArea = new JLabel("Gantt Here",SwingConstants.CENTER));
			centerPanel.add(new JScrollPane(shopDataArea = new JTextArea()));
			centerPanel.add(animArea = new JLabel("Animation Here",SwingConstants.CENTER));

		shopDataArea.setEditable(false);

		menuBar.add(fileMenu);
			for(int i=0;i<fileMenuActions.length;i++)
				fileMenu.add(fileMenuActions[i]);

		///////THIS NASTY CODE USES ANONYMOUS INNER CLASES TO OVERIRED
		////// ALGORITHM SELECTION ACTION CLASSES FOR SPECIFIC ALGORITHMS
		///// TO ADD MORE ALGORITHMS' ADD TO THE CODE BELOW

		menuBar.add(algorithmMenu);
			algorithmMenu.add(new AlgorithmSelectionAction(
								GUIAlgorithm.StaticGetAlgorithmName()){

				public ShopAlgorithm allocateAlgorithm(){
					return 	new GUIAlgorithm(	shopData,shopState,
											commandLabel);
			}});
			algorithmMenu.add(new AlgorithmSelectionAction(
							SimpleRandomAlgorithm.StaticGetAlgorithmName()){

						public ShopAlgorithm allocateAlgorithm(){
							return 	new GUIforComputerAlgorithm(
									new SimpleRandomAlgorithm(null,null),
									shopData,///////QQQQQQQQQQQQQ
									shopState,
									null,commandLabel,null);
			}});

			algorithmMenu.add(new AlgorithmSelectionAction(
										CyclicAlgorithm.StaticGetAlgorithmName()){

				public ShopAlgorithm allocateAlgorithm(){
					return 	new GUIforComputerAlgorithm(
								new CyclicAlgorithm(null,null),
									shopData,///////QQQQQQQQQQQQQ
									shopState,
									null,commandLabel,null);
			}});



		rootPane.setJMenuBar(menuBar);

		shopDataArea.setText("---Topology and job info of shop---\n"+
								shopData.toString());
		return this;
	}


	/**Changes the command label*/
	public void setCommandLabel(String cmd){
		commandLabel.setText(cmd);
	}

	///////////////////////////////////////////////////////////////////////////
	///////////////////////CODE THAT IS SPECIFIC FOR APPLETS///////////////////
	///////////////////////////////////////////////////////////////////////////

	/**Reads parameters, sets up, etc...*/
	public void init(){
		isApplication=false;
		int num=1;
		while(true){
			String parName = "SHOP_DATA" + Integer.toString(num++);
			String param = getParameter(parName);
			if(param==null)
				break;
			dataFiles.add(param);
		}
		if(dataFiles.isEmpty()){
			System.err.println("SHOP_DATA# parameters aren't set!!!");
			getContentPane().add(new
					JLabel("Job Shop Simulation:  ERROR WITH PARAMETER, CHECK HTML SOURCE",
					SwingConstants.CENTER));
			return;
		}
		getContentPane().add(setUp((String)dataFiles.get(0),getRootPane()).mainPanel);
	}

	public void start(){
		//QQQQ
	}

	public void stop(){
		//QQQQ
	}

	public void destory(){
		//QQQQ
	}

	/**Kills the applet and goes to HOME_PAGE with the browser.*/
	private void exitApplet(){
		stop();
		try{
			getAppletContext().showDocument(new URL(HOME_PAGE));
		}catch(Exception e){
			mainPanel.setVisible(false);
		}
	}


	///////////////////////////////////////////////////////////////////////////
	////////////CODE THAT IS SPECIFIC FOR A STAND-ALONE APPLICATION////////////
	///////////////////////////////////////////////////////////////////////////

	/**Needs to get single argument with <ShopFileName>. It then creates an application, that automatically opens this file. Currently, canno't run an
	application without an argument.*/
	public static void main(String [] a){
		if(a.length!=1){
			System.err.print("Usage: java RunManual <ShopFileName>");
			System.exit(1);
		}

		isApplication = true;
		JFrame frame = new JFrame("Job Shop Simulator, Haifa University, Israel"
		);
		frame.getContentPane().add(new MainGUI().setUp(a[0], frame.getRootPane()).mainPanel);
		frame.setSize(800,600);
		frame.addWindowListener(new WindowAdapter()
						{
							public void windowClosing(WindowEvent we)
							{
								exitApplication();
							}
				});
		frame.setVisible(true);
	}

	/**Called to exit. Currently just kills the JVM.*/
	private static void exitApplication(){
		System.exit(0);
	}


	///////////////////////////////////////////////////////////////////////////
	////////////////////////////////INNER - CLASSES////////////////////////////
	///////////////////////////////////////////////////////////////////////////


	/**Handles the Open Action of the File menu. This action is designed to open new
	shop data files. A distiction is made whether this is an application or an applet.
	In an application, files are loaded from the file system, whereas in an applet,
	a URL of a file is to be specified.*/
	class OpenAction extends AbstractAction{
		public OpenAction(){
			super("Open ...");
		}
		public void actionPerformed(ActionEvent ae){
			//QQQQ
		}
	}

	/**This action calls the exitApplication() method in the case of an application.
	In the case of an applet, the applet is stopped and the HOME_PAGE url is browsed to.*/
	class ExitAction extends AbstractAction{
		public ExitAction(){
			super("Exit");
		}
		public void actionPerformed(ActionEvent ae){
			if(isApplication)
				exitApplication();
			else
				exitApplet();
		}
	}//END OF INNER CLASS

	/**Use for displaying a pop-up window showing the algorithm's log.*/
	class ViewLogAction extends AbstractAction{
		public ViewLogAction(){
			super("View Kernel Log");
		}

		public void actionPerformed(ActionEvent ae){
			//QQQQ
		}
	}//END OF INNER CLASS

	/**This class implements an action that occurs when a new algorithm is selected.
	The action first stops the simulation if it is running. It then removes the
	simulation and gc's what it can. A new algorithm is then created.<P>
	The class is abstract in the sense of the allocateAlgorithm method. It is best
	if this class be extended by an anonymous inner class within listeners such that
	the allocateAlgorithm method is extended and allocates the proper algorithm.<P>
	This design prevents allocating all of the available algorithms at start up.*/
	abstract class AlgorithmSelectionAction extends AbstractAction{

		/** A reference to the shopAlgorithm which this class handles.*/
		private ShopAlgorithm shopAlgorithm;

		/**The constructor uses an algorithm name.*/
		AlgorithmSelectionAction(String algName){
			super(algName);
		}

		/**This method is to be overriden by implementations such that it allocates
		the desired algorithm and returns a reference.*/
		abstract public ShopAlgorithm allocateAlgorithm();

		/**Does what is specified at the class explanation above.*/
		public void actionPerformed(ActionEvent ae){
			if(numSimulations>0){//if this isn't a first shopRun
				shopState = new ShopStateImpl(shopData);
				stateTable.setShopState(shopState);
				System.gc();
			}

			currentAlgorithm = allocateAlgorithm();
													//QQQQQQQQQQ
			currentAlgorithm.setLog(new PrintWriter(System.out,true));

			if(topPanel.getComponentCount()==2)
				topPanel.remove(1);
			topPanel.add(new JScrollPane(
							(JPanel)currentAlgorithm),BorderLayout.CENTER);
			mainPanel.updateUI();

			shopRun = new ShopRun(	currentAlgorithm
									,shopData
									,shopState
									,new PostGUIRunAction()
						/*QQQQQQ*/	,new PrintWriter(System.out,true),true);
			shopRun.addShopChangeListener(shopState);
			shopState.addShopChangeListener(stateTable);
			shopRun.start();
			numSimulations++;
		}
	}//END OF INNER CLASS

	/**This class is a functor that holds the method that is done after a run.
	It is the shopRun that calls this method.*/
	public class PostGUIRunAction implements PostRunAction{
		public void doAction(){
			commandLabel.setText("Simulation is over");
			topPanel.remove(1);
			shopRun.reset();
			shopRun=null;
			System.gc();
			mainPanel.updateUI();
		}
	}//END OF INNER CLASS
}//END OF CLASS

