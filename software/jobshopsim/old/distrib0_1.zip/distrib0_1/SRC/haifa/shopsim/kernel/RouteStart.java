package haifa.shopsim.kernel;

import haifa.shopsim.*;

import java.util.*;

import javaSimulation.*;

/**This Simulation Entity is the pile of jobs at the start of the route.*/
public class RouteStart implements JobHolder{
	ShopData shopData;
	int routeNumber;

	Machine firstMachine;

	Head jobQueue = new Head();

	public RouteStart(ShopData shopData_, int routeNumber_){
		shopData = shopData_;
		routeNumber = routeNumber_;
	}

	public void getJob(Job job){
			job.into(jobQueue);
	}

	public void passJobs(){
		while(!jobQueue.empty()){
			Job job = (Job)jobQueue.first();
			job.out();
			firstMachine.getJob(job);
		}
	}


	/**This method interconnects (by references) the route starting at this route
	start and going thourgh all the machines to the routeEnd*/
	public void bindRoute(Machine [] machines, RouteEnd end){
		List route = null;
		try{
			route = shopData.getRoute(routeNumber);
		}catch(Exception e){
			System.err.println("While trying to get route number " +
								routeNumber + " :"+e);
			System.exit(1);
		}
		//Connect first step
		Operation firstOp = (Operation)route.get(0);
		int firstM = shopData.getMachine(firstOp);
		int secondM = shopData.getMachine((Operation)route.get(1));
		machines[firstM-1].bindInput(firstOp,this);
		machines[firstM-1].bindOutput(firstOp,machines[secondM-1]);

		firstMachine = machines[firstM-1];

		//Connect rest of steps except final one
		for(int k=1; k<=route.size()-2;k++){
			Operation op_0 = (Operation)route.get(k-1);
			Operation op = (Operation)route.get(k);
			Operation op_1 = (Operation)route.get(k+1);
			int m = shopData.getMachine(op);
			machines[m-1].bindInput(op,machines[shopData.getMachine(op_0)-1]);
			machines[m-1].bindOutput(op,machines[shopData.getMachine(op_1)-1]);
		}

		Operation prevOp = (Operation)route.get(route.size()-2);
		Operation lastOp = (Operation)route.get(route.size()-1);
		int lastM = shopData.getMachine(lastOp);

		//Connect final step
		machines[lastM-1].bindInput(lastOp,machines[shopData.getMachine(prevOp)-1]);
		machines[lastM-1].bindOutput(lastOp,end);
		end.previous=machines[lastM-1];
	}//end of bindRoute() method
}//END OF CLASS
