package haifa.shopsim;

import java.io.*;
import java.util.*;
import java.net.*;

/**An implementation of a general shopData using arrays.*/
public class GeneralShopDataArray implements ShopData{

	/**Read according to file format as specified in example shop.dat*/
	public GeneralShopDataArray(Reader reader) throws JobShopFileFormatException, IOException{

		StreamTokenizer st = new StreamTokenizer(
								new BufferedReader(reader));


		st.commentChar('#');//set comment character

		if(st.nextToken()!=StreamTokenizer.TT_NUMBER)//adavance to number of machines
			throw new JobShopFileFormatException();
		I=(int)st.nval;

		if(st.nextToken()!=StreamTokenizer.TT_NUMBER)//advance to number of routes
			throw new JobShopFileFormatException();
		int R = (int)st.nval;
			routes = new int[R][];

		if(st.nextToken()!=StreamTokenizer.TT_NUMBER)//advance to number of types of jobs
			throw new JobShopFileFormatException();
		numJobTypes=(int)st.nval;
			numJobs = new int[numJobTypes];
			jobRoutes = new int[numJobTypes];
			stepDurations = new double[numJobTypes][];


		st.nextToken();//advance to Routes

		for(int r=0;r<R;r++){//read each route
			/*Read "Route" string*/
			if(st.ttype != StreamTokenizer.TT_WORD  ||
				!st.sval.equalsIgnoreCase("Route"))
				throw new JobShopFileFormatException();

			/*Read "Route" number*/
			if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
				throw new JobShopFileFormatException();
			int rnum=(int)st.nval-1;
			//now rnum is the index of the route that we should insert to routes[][]

			LinkedList ll = new LinkedList();//a linked list to contain steps
			while(true){//read steps into route
				if(st.nextToken()!=StreamTokenizer.TT_NUMBER)//when jobs in route are finished
					break;
				ll.add(new Integer((int)st.nval));
			}

			//put route into array
			routes[rnum]=new int[ll.size()];
			Iterator it = ll.iterator();
			for(int k=0;it.hasNext();k++)
				routes[rnum][k]=((Integer)it.next()).intValue();
		}//end of loop on routes



		for(int t=0;t<numJobTypes;t++){//loop on all job types

			if(st.ttype!= StreamTokenizer.TT_WORD ||
				!st.sval.equalsIgnoreCase("Job")){
					System.err.println("Value of st.ttype:" + st.ttype);
					System.err.println("Value of st.nval: " + st.nval);
					throw new JobShopFileFormatException();
			}

			if(st.nextToken()!=StreamTokenizer.TT_NUMBER)
					throw new JobShopFileFormatException();
			int jnum=(int)st.nval-1;
			st.nextToken();//advance to route number
				jobRoutes[jnum] = (int)st.nval-1;//read route number
			st.nextToken();//advance to number of repetions
				numJobs[jnum] = (int)st.nval;//read number of repetitions

			stepDurations[jnum] = new double[routes[jobRoutes[jnum]].length];
			for(int k=0;k<routes[jobRoutes[jnum]].length;k++){
				st.nextToken();
				stepDurations[jnum][k] = st.nval;
			}
			st.nextToken();
		}
	}//End of constructor that reads file

	/**Number of machines*/
	private int I;

	/**Array of routes, each route being an array of operations*/
	private int [][] routes;

	/**The different number of jobs types in the job shop*/
	private int numJobTypes;

	/**The length of this array is numJobTypes, each element determines how many
	jobs are from each type.*/
	private int numJobs [];

	/**The length of this array is numJobTypes. It associates a route number to
	each job type*/
	private int jobRoutes[];

	/**This is a ragged array of job durations per each step. The length of the
	first dimension of the array is numJobTypes. The length of the second dimension
	is the jobRoutes[job number] and it's values are the processing times in each
	step of the route.*/
	private double [][] stepDurations;


	/**Returns number of machines.*/
	public int getI(){
		return I;
	}

	/**Returns number of routes.*/
	public int getR(){
		return routes.length;
	}

	/**Returns total number of jobs*/
	public int getN(){
		int sum=0;
		for(int i=0;i<numJobs.length;i++)
			sum+=numJobs[i];
		return sum;

	}

	/**Returns number of job types.*/
	public int getT(){
		return numJobTypes;
	}

	/**Returns the total number of steps/classes/buffers (sum of Kr)*/
	public int getK(){
		try{
			int K=0;
			for(int r=0;r<getR();r++)
				K+=getKr(r);
			return K;
		}catch(Exception e){
			System.err.println(e);
			System.exit(1);
			return 0;//needed for compoiler
		}
	}

	/**Returns the number of jobs of type t*/
	public int getNt(int t){
		try{
			return numJobs[t-1];
		}catch(ArrayIndexOutOfBoundsException e){
			throw new IllegalArgumentException();
		}
	}

	/**Returns the number of types of jobs that are on route r.*/
	public int getTr(int r){
		int count = 0;

		for(int t=0;t<jobRoutes.length;t++)
			if(jobRoutes[t]==r-1)
				count++;
		return count;
	}

	/**Returns an array of type numbers of jobs that are on route r.*/
	public int [] getTypesOfRoute(int r){
		ArrayList jobs = new ArrayList();
		for(int t=0;t<jobRoutes.length;t++)
			if(jobRoutes[t]==r-1)
				jobs.add(new Integer(t+1));
		int [] types = new int[jobs.size()];
		for(int t=0;t<types.length;t++)
			types[t]=((Integer)jobs.get(t)).intValue();
		return types;
	}



	/**Returns all of the jobs of type t. The length of this array is getNt(t).*/
	public String [] getJobsOfType(int t){
		String [] jobs = new String[numJobs[t-1]];
		for(int j=0;j<jobs.length;j++){
			jobs[j]=new StringBuffer().append(t).append('_').append(j+1).toString();
		}
		return jobs;
	}

	public String [] getJobsOfRoute(int r){
		int [] types = getTypesOfRoute(r);
		String [] jobs = new String[getNr(r)];
		int t=0;
		for(int i=0;i<types.length;i++){
			String [] temp = getJobsOfType(types[i]);
			for(int j=0;j<temp.length;j++)
				jobs[t++]=temp[j];
		}
		return jobs;

	}


	/**Returns the processing time of job of type t, on step o of it's route.*/
	public double getXto(int t, int o) {
			return stepDurations[t-1][o-1];
	}

	/**Returns the route of type t.*/
	public int getRouteOfType(int t){
		return jobRoutes[t-1]+1;
	}




	public int getKr(int r){
		try{
			return routes[r].length;
		}catch(ArrayIndexOutOfBoundsException e){
			throw new IllegalArgumentException();
		}
	}

	public int getMachine(Operation op){
		return routes[op.getRoute()-1][op.getStep()-1];

	}

	public int getNr(int r){
		int types [] = getTypesOfRoute(r);
		int count=0;
		for(int t=0;t<types.length;t++){
			count+=numJobs[types[t]-1];
		}
		return count;
	}


	/**Returns a List of all operation in machine i. The elements of the list
	are arrays of ShopData.Operation instances*/
	public List getCi(int i){
		ArrayList list = new ArrayList();
		for(int r=0;r<routes.length;r++){//loop on all routes
			for(int k=0;k<routes[r].length;k++){//loop on operations of route r
				if(routes[r][k]==i)
					list.add(new Operation(r+1,k+1));
			}
		}
		return list;
	}



	/**Returns the number of operations in machine i.*/
	public int getSizeCi(int i){
		int size=0;
		for(int r=0;r<routes.length;r++)
			for(int k=0;k<routes[r].length;k++)
				if(routes[r][k]==i)
					size++;
		return size;
	}

	/**Returns a List of all ShopData.Operation instances in route r*/
	public List getRoute(int r){
		ArrayList list = new ArrayList();
		for(int o=0;o<routes[r-1].length;o++)//loop on all operations of route r
			list.add(new Operation(r,o+1));
		return list;
	}



	/**Ask is shop is a jobshop with a single route same as getR()==1*/
	public boolean isSingleRoute(){
		return routes.length==1;
	}



	/**Ask if the shop has identical jobs. Reply is false*/
	public boolean isIdenticalJobs(){
		return false;
	}

	/**Ask if the shop has proportional jobs. Reply is false*/
	public boolean isProportinalJobs(){
		return false;
	}



	/**Ask if the shop is most general, not necessarily proportional nor similar.
	reply is true.*/
	public boolean isMostGeneralJobShop(){
		return true;
	}


	/**Returns all info regarding jobshop in a displayable string*/
	public String toString(){
		StringBuffer sb=null;
	   try{
		sb = new StringBuffer();
		sb.append("Number of machines:" ).append(I).append("\n");
		for(int r=0;r<routes.length;r++){
			sb.append("Route #").append(r+1).append(" (").append(
				getTr(r+1)).append(" types) (").append(getNr(r+1)).append(
					"jobs in total").append("): ");
			for(int k=0;k<routes[r].length;k++)
				sb.append(routes[r][k]).append(", ");
			sb.delete(sb.length()-2,sb.length()-1);
			sb.append('\n');
		}
		for(int j=0;j<numJobTypes;j++){
			sb.append("Job Type #").append(j+1).append(": ");
			sb.append("(on route #").append(jobRoutes[j]+1).append(") ");
			sb.append("(").append(getNt(j+1)).append(" repetitions): ");
			for(int k=0;k<stepDurations[j].length;k++)
				sb.append(stepDurations[j][k]).append(", ");
			sb.delete(sb.length()-2,sb.length()-1);
			sb.append('\n');
		}
		for(int i=0;i<I;i++){
			sb.append("Classes in machine #").append(i+1).append(": ");
			sb.append(getCi(i+1)).append('\n');

		}
		sb.delete(sb.length()-1,sb.length()-1);
	   }catch(Exception e){
		   System.err.println(e);
		   System.exit(1);
	   }

		return sb.toString();
	}

	/**For testing*/
	public static void main(String [] args)throws Exception{
		ShopData sd=null;
		try{
			sd = new GeneralShopDataArray(new InputStreamReader(
												new FileInputStream(args[0])));
		}catch(ArrayIndexOutOfBoundsException e){
			System.err.println("give a file name as a first parameter");
			System.exit(1);
		}
		System.out.println("********** toString() of SHOP:");
		System.out.println(sd);
		System.out.println("********** Shop data arrays of SHOP:");
		for(int t=1;t<=sd.getT();t++){//loop on all job types and print jobs
			System.out.println("Jobs of type " + t + ":");
			String [] jobs = sd.getJobsOfType(t);
			for(int i=0;i<jobs.length;i++)
				System.out.print(jobs[i] + '\t');
			System.out.println();
		}
		System.out.println("********** types of each route:");
		for(int r=0;r<sd.getR();r++){
			int [] 	types = sd.getTypesOfRoute(r+1);
			System.out.print("Route #"+(r+1)+" : ");
			for(int t=0;t<types.length;t++)
				System.out.print(types[t]+"  ");
			System.out.println();
		}

		System.out.println("********** jobs of each route:");
		for(int r=0;r<sd.getR();r++){
			System.out.print("Route #"+(r+1)+" : " );
			String [] jobs = sd.getJobsOfRoute(r+1);
			for(int i=0;i<jobs.length;i++)
							System.out.print(jobs[i] + '\t');
			System.out.println();
		}

	}

}//END OF CLASS

