package haifa.shopsim.kernel;

import haifa.shopsim.*;

import java.io.*;

import javaSimulation.*;
import javaSimulation.Process;
import java.util.*;

/**This class is the Process in the simulation that starts it all (the main process).
It has references
to the shopAlgorithm, the ShopData, the log, the shopResults, it also refences all of
the entities of the simulation, the machines, the jobs, the route starts and ends.<P>
This class is a singleton because the javaSimualtion package uses static variables for
time and such, so no two shop runs can be run in the same process.*/
public class ShopRun extends Process implements Runnable{

	/**Use to ensure that at most one instance of this class exists at any time.*/
	private static int count=0;

	/**The Thread that this class runs on. It may be given low or high priority in
	the consturctor.*/
	private Thread run;

	/**A simualation may not run past this time.*/
	final long MAX_SIM_TIME = Long.MAX_VALUE;

	/**A refrence to the algorithm that is asked what to do at each time epoch.*/
	private ShopAlgorithm shopAlgorithm;

	/**A reference to the shopData. It is used to inquire about the job shop
	problem at hand.*/
	private ShopData shopData;

	/**For misc output information.*/
	private PrintWriter log;

	/**A reference to the ShopState object. It is updated before asking the algorithm
	for new commands.*/
	private ShopState shopState;

	private PostRunAction postRunAction;


	private boolean lowPriority;

	/////THE ENTITIES THAT MAKE UP THE SIMULATION WORLD

	/**An array of all of the machines in the shop.*/
	private Machine machines[];

	/**An array of all of the jobs in the shop. These travel around as the simulation
	evolves in time.*/
	private Job jobs[];

	/**An array of all of the route starts.*/
	private RouteStart routeStarts[];

	/**An array of all of the route ends.*/
	private RouteEnd routeEnds[];

	ArrayList shopChangeListeners = new ArrayList();

	int unfinishedJobs;

	HashMap restingMachines = new HashMap();

	void awakenRestingMachines(){
		Iterator it = restingMachines.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry me = (Map.Entry)it.next();
			double time = ((Double)me.getKey()).doubleValue();
			if(time < time())
				activate((Machine)me.getValue());
		}
	}

	public void addShopChangeListener(ShopChangeListener scl){
		shopChangeListeners.add(scl);
	}

	void notifyListeners(ShopChangeEvent sce){
		Iterator it = shopChangeListeners.iterator();
		while(it.hasNext())
			((ShopChangeListener)it.next()).shopChanged(sce);
	}

	Map getQMap(){
		HashMap map = new HashMap(shopData.getK());
		for(int i=0;i<machines.length;i++)
			map.putAll(machines[i].getQMap());
		return map;
	}

	/**Used by the Machine objects in the simulation. This method is responsible for
	updating the state of the ShopState object and for inquring the algorithm what now.*/
	ShopCommand whatNow(int machineNumber){
	//CURRENTLY THIS UPDATING IS VERY DIRTY AND I'M NOT REALLY SURE ABOUT IT
		Enumeration e = machinesWithSameTime(machineNumber).elements();
		//let all the machinesWithSameTime update their state before doing anything
		machines[machineNumber-1].hold(0.0);
		while(e.hasMoreElements())
			activate(machines[((Integer)e.nextElement()).intValue()-1]);

		return shopAlgorithm.whatNow(machineNumber);
	}

	/**Returns a vector of Integers of all of the machines that have the same time
	as the machine numbered mN. This vector will always have atleast one element: mN*/
	private Vector machinesWithSameTime(int mN){
		Vector v = new Vector();
		for(int i=0;i<machines.length;i++){
			if(!machines[i].idle())
				if(machines[i].evTime() == machines[mN-1].evTime())
					v.add(new Integer(i+1));
		}
		return v;
	}

	/**Returns true if quit has been called on the algorithm.*/
	boolean quitCalled(){
		return false;
	}

	public void reset(){
		logPrint("Reset called");
		count=0;
	}

	/**Sets up the shop. Bind all of the machines in the shop to their predecessors
	and successors.*/
	public ShopRun(ShopAlgorithm shopAlgorithm_,
					ShopData shopData_,
					ShopState shopState_,
					PostRunAction postRunAction_,
					PrintWriter log_, boolean lowPriority_){

		//ensure that only one instance of this class exists
		count++;
		if(count > 1){
			System.out.println("Trying to create more than one ShopRun Object");
			System.exit(1);
		}

		//update state variables
		log=log_;
		shopState = shopState_;
		shopAlgorithm=shopAlgorithm_;
		shopData=shopData_;
		postRunAction = postRunAction_;
		lowPriority = lowPriority_;

		machines = new Machine[shopData.getI()];
		jobs = new Job[shopData.getN()];

		unfinishedJobs=shopData.getN();

		for(int i=0;i<machines.length;i++)
			machines[i]=new Machine(shopData,i+1,this);


		routeStarts = new RouteStart[shopData.getR()];
		routeEnds = new RouteEnd[shopData.getR()];

		for(int r=0;r<shopData.getR();r++){
			routeEnds[r] = new RouteEnd(shopData,this,r+1);
			routeStarts[r] = new RouteStart(shopData, r+1);
			routeStarts[r].bindRoute(machines, routeEnds[r]);

		}

		try{
			int i=0;
			for(int t=1;t<=shopData.getT();t++){//loop on all job types and put them
										   //in route starts
			//all jobs of type t belong to route getRouteOfType(t)
			int route = shopData.getRouteOfType(t);

			for(int j=0;j<shopData.getNt(t);j++)
				routeStarts[route-1].getJob(jobs[i++]=new Job(shopData,t));

			}
		}catch(Exception e){
						System.err.println(e);
						System.exit(1);
		}

		for(int r=0;r<shopData.getR();r++)
			routeStarts[r].passJobs();


		//at this point shop is ready
	}


	public void start(){
		//notifyListeners
		notifyListeners(new ShopStartedEvent(this,time(),getQMap()));

		run = new Thread(this);
		run.start();
		if(lowPriority)
			run.setPriority((Thread.NORM_PRIORITY-Thread.MIN_PRIORITY)/2);
		else
			run.setPriority(Thread.MAX_PRIORITY);

	}

	/**The running thread of the simulation activates the main class.*/
	public void run(){
		logPrint("Starting Simulation");
		activate(this);
		postRunAction.doAction();
	}

	/**Writes message to log, including time */
	private void logPrint(String msg){
		log.println(time()+": " + msg);
	}

	/**This method is the main corotine of the simulation (it exists for as long as
	the simulation exists). It starts off by activating all of the machines
	(which are the main "working" entities in the system). It Then holds for the
	MAX_SIM_TIME which is an upper bound on the simulation run. In normal circumstances
	it should be rare for the method to regain controll at MAX_SIM_TIME when the other
	machines are still working.<P>
	When the method finally regains controll, it cleans up and returns, thus
	the simulation is over.*/
	public void actions(){

		for(int i=0;i<machines.length;i++)
			activate(machines[i]);

		while(unfinishedJobs>0)
			passivate();

		notifyListeners(new ShopFinishedEvent(this,time()));
		logPrint("Simulation Finished");


	}
}//END OF CLASS