package haifa.shopsim.algorithms;

import haifa.shopsim.*;

import java.io.*;

import java.util.*;

/***/
public class CyclicAlgorithm implements ShopAlgorithm{

	ShopState shopState;
	ShopData shopData;

	PrintWriter log;

	final static String EXPLANATION =
	"This algorithm schedules the jobs using cyclic algorithm (Buduch, Weiss, Penn)";


	boolean quitFlag=false;

	public CyclicAlgorithm(	ShopData shopData_,
					ShopState shopState_) {
			System.out.println("Cyclic Algorithm Cot'r");
			shopData = shopData_;
			shopState = shopState_;
	}

	public void setShopStateObject(ShopState shopState_){
		shopState=shopState_;
	}

	public void setShopData(ShopData shopData_){
		shopData=shopData_;
	}

	public void setLog(PrintWriter log_){
		log=log_;
	}

	/**Very simply reads a command from console and returns a ShopCommmand object.*/
	public ShopCommand whatNow(int machineNumber){
		return null;

	}


	/**Returns true when the algorithm decided that it is time to quit.*/
	public boolean quitCalled(){
		return quitFlag;
	}

	/***/
	public String explanationString(){
		return EXPLANATION;
	}

	/**Returns false since the user's actions are not specified in the algorithm.*/
	public boolean isDeterministic(){
		return true;
	}

	public static String StaticGetAlgorithmName(){
		return "Cyclic";
	}

	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}

	public String toString(){
			return getAlgorithmName();
	}
}//END OF CLASS
