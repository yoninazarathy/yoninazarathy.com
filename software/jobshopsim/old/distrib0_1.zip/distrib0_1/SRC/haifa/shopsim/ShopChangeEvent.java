package haifa.shopsim;

import java.util.*;

public abstract class ShopChangeEvent extends EventObject{

	private double time;

	public ShopChangeEvent(Object source,double time_){
		super(source);
		time = time_;
	}

	public double getTime(){
		return time;
	}

	public String toString(){
		return super.toString()+ " time:"+time;
	}
}