package haifa.shopsim;

import java.util.*;

public class ShopStartedEvent extends ShopChangeEvent{

	private Map operationMap;

	public ShopStartedEvent(Object source, double time, Map operationMap_){
		super(source,time);
		operationMap = operationMap_;
	}

	public Map getQMap(){
		return operationMap;
	}

	public String toString(){
		return super.toString() + " Queues:"+operationMap;
	}
}