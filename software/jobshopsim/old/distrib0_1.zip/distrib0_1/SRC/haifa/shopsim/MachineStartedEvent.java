package haifa.shopsim;

import java.util.*;

public class MachineStartedEvent extends ShopChangeEvent{
	private int machineNumber;
	private Operation operation;
	private String jobID;

	public MachineStartedEvent(	Object source, double time,
									int machineNumber_,
									Operation operation_,
									String jobID_){
		super(source,time);
		machineNumber = machineNumber_;
		operation = operation_;
		jobID = jobID_;
	}

	public String toString(){
		return super.toString() + " machineNumber:" + machineNumber +
						" job ID:"+ jobID;
	}

	public int getMachineNumber(){
		return machineNumber;
	}

	public String getJobID(){
		return jobID;
	}
}//END OF CLASS