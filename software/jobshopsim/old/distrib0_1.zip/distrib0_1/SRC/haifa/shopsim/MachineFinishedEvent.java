package haifa.shopsim;

import java.util.*;

/**Signifies that a machine finished processing a job.*/
public class MachineFinishedEvent extends ShopChangeEvent{
	private int machineNumber;

	/**Has value of -1 if the next machine is a RouteEnd.*/
	private int nextMachineNumber;

	private Operation finishedOperation;

	/**Has null value if the next operation is a route end.*/
	private Operation nextOperation;
	private String jobID;

	public MachineFinishedEvent(	Object source, double time,
									int machineNumber_, int nextMachineNumber_,
									String jobID_,
									Operation finishedOperation_,
									Operation nextOperation_){
		super(source,time);
		machineNumber = machineNumber_;
		nextMachineNumber = nextMachineNumber_;
		jobID = jobID_;
		finishedOperation = finishedOperation_;
		nextOperation = nextOperation_;
	}

	public String toString(){
		return super.toString() + " machineNumber:" + machineNumber
		+" nextMachineNumber:" + nextMachineNumber + " finishedOperation:"+
		finishedOperation+ " nextOperation: " + nextOperation +
						" job ID:"+ jobID;
	}

	public int getMachineNumber(){
		return machineNumber;
	}

	public int getNextMachineNumber(){
		return nextMachineNumber;
	}

	public Operation getFinishedOperation(){
		return finishedOperation;
	}

	public Operation getNextOperation(){
			return nextOperation;
	}
}//END OF CLASS