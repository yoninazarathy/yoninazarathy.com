package haifa.shopsim.kernel;

import haifa.shopsim.*;

/**A JobHolder is a SimulationEntity that 'physically' holds jobs during its
operation.*/
interface JobHolder extends SimulationEntity{

	/**When another SimualationEntity passes the job onto this entity, it should
	use this method by calling it on the reciveing object.*/
	void getJob(Job job);

	/**Returns the operation associated with this job holder (or null) if there
	is no such operation (end of route.)*/
	//Operation getOperation();
}