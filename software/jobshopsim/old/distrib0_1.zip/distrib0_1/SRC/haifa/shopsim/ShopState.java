package haifa.shopsim;

import java.util.*;
import haifa.global.Debug;

public interface ShopState extends ShopChangeListener{

	/**Register a listener to the state.*/
	public void addShopChangeListener(ShopChangeListener scl);

	public void shopChanged(ShopChangeEvent sce);

	/**Returns the time as registered with the state.*/
	public double getTime();

	/**Returns a collection of all of the busy machines at the current time.*/
	public Collection getBusyMachines();


	/**Returns a collection of the schedulable operations.*/
	public Collection getSchedulableOperations();

	/**Returns the total number of finished jobs.*/
	public int getTotalFinishedJobs();

	/**Returns the number of finsihed jobs on a particular route.*/
	public int getNumFinishedJobs(int route);

	public Map getQMap();

}//END OF INTERFACE