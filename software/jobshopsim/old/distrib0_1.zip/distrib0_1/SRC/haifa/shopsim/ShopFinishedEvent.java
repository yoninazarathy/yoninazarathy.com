package haifa.shopsim;

import java.util.*;


public class ShopFinishedEvent extends ShopChangeEvent{
	public ShopFinishedEvent(Object source, double time){
		super(source,time);
	}
}