package haifa.shopsim;

import java.util.*;

/**Classes which implement this interface are sensitve to changes in the job shop.*/
public interface ShopChangeListener extends EventListener{
	public void shopChanged(ShopChangeEvent sce);
}