package haifa.shopsim;

/**Thrown when the input file does not seem to match the specification.*/
public class JobShopFileFormatException extends Exception{}