package haifa.shopsim;

import java.util.*;

/**Signifies that a job finished it's processing in the job shop.*/
public class JobFinishedEvent extends ShopChangeEvent{
	private String jobID;
	private int routeNumber;

	public JobFinishedEvent(	Object source, double time,
								String jobID_,int routeNumber_){
		super(source,time);
		jobID = jobID_;
		routeNumber = routeNumber_;
	}

	public String toString(){
		return super.toString() + " job ID:"+ jobID;
	}

	public int getRouteNumber(){
		return routeNumber;
	}

	public String getJobID(){
		return jobID;
	}
}//END OF CLASS