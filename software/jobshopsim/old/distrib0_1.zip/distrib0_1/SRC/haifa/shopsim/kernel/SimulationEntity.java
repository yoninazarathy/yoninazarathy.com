package haifa.shopsim.kernel;

/**A class or interface implementing/extending this interface implies that it is
a simulation entity, thus it is a working object within the simulation.*/
interface SimulationEntity{}