package haifa.shopsim;

import java.util.*;

/**This is an interface for the datastrucute class that contains the data revlevant to a specific jobshop problem. The formulation of the problem is as following:<P>
i=1,....,I machines<BR>
r=1,....,R routes<BR>
for each route r, there exist steps (1,r),....,(1,Kr). there is a machine for each of these steps.<BR>
there are also Nr jobs in each route. N = N1+....+NR is the total sum of jobs<BR>
The duration of each step for each job is Xr,o,j r = 1,....,R being the route, o = 1,...,Kr being the step on the route, j = 1,...,Nr being the specific job on the route.<P>
Stated above is the most general problem, (there might be some room to add setup
times in later versions).<P>
Job types are numbered t=1,....,T. Each job type has an associated route. There may be
several copies of jobs from a single type.<P>
Jobs are identified using a unique string, the string is
<job type number>_<copy number>
thus the strings "12_1","12_2",....,"12_100" uniqly identify the 100 jobs of type 12.
<P>
For each job type, the processing times are identical.
*/
public interface ShopData{

	/**Returns number of machines.*/
	public int getI();

	/**Returns number of routes.*/
	public int getR();

	/**Returns number of jobs.*/
	public int getN();

	/**Returns the number of types of jobs.*/
	public int getT();

	/**Returns the total number of steps/classes/buffers (sum of Kr)*/
	public int getK();

	/**Returns number of steps in route r*/
	public int getKr(int r);

	/**Returns number of jobs in route r*/
	public int getNr(int r);

	/**Returns the number of jobs of type t*/
	public int getNt(int t);

	/**Returns the number of types of jobs that are on route r.*/
	public int getTr(int r);

	/**Returns an array of type number of jobs that are on route r.*/
	public int [] getTypesOfRoute(int r);

	/**Returns all of the jobs of type t. The length of this array is getNt(t).*/
	public String [] getJobsOfType(int t);

	/**Returns all of of route r. This includes all of the jobs of all types that
	are associated with route r*/
	public String [] getJobsOfRoute(int r);

	/**Returns the machine that performs the following operation.*/
	public int getMachine(Operation op);

	/**Returns a List of all operations in machine i.*/
	public List getCi(int i);

	/**Returns the number of operations in machine i.*/
	public int getSizeCi(int i);

	/**Returns the processing time of job of type t, on step o of it's route.*/
	public double getXto(int t, int o) ;

	/**Returns the route of type t.*/
	public int getRouteOfType(int t);

	/**Returns a List of all operations in route r*/
	public List getRoute(int r);

	/**Ask is shop is a jobshop with a single route same as getR()==1*/
	boolean isSingleRoute();

	/**Ask if the shop has identical jobs. If so, use getXr()*/
	boolean isIdenticalJobs();

	/**Ask if the shop has proportional jobs. i.e N1,...,Nr are
	proportional to some N (there exists p1,...,pr such that Ni=piN).*/
	boolean isProportinalJobs();

	/**Ask if the shop is most general, not proportional, not similar.*/
	boolean isMostGeneralJobShop();
}//END OF INTERFACE