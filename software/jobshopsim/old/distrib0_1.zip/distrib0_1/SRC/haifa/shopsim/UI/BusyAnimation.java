package haifa.shopsim.UI;

import javax.swing.*;
import java.awt.*;
import java.util.*;

public class BusyAnimation extends JPanel implements Runnable{
	int x1,y1;
	int x2,y2;

	Thread t;

	final int MIN_DELAY = 100;
	final int MAX_DELAY = 200;
	final int STEP = 10;
	int delay = MIN_DELAY;

	final int MAX_COUNT = 5;
	int upgradeCounter=0;

	boolean animating;

	boolean pause;

	Random random = new Random((int)(Math.random()*10000));
		//set this seed so that two instances of this class that are
		//created toghether will not have the same seed

	public void start(){
		animating = true;
		t = new Thread(this);
		t.start();
	}

	public void stop(){
		animating = false;
	}

	public void step(){
		nextLine();
		repaint();
	}

	public BusyAnimation(){
		setBackground(Color.pink);
		setPreferredSize(new Dimension(100,40));
	}

	private void nextLine(){
		if(++upgradeCounter==MAX_COUNT){
						delay+=STEP;
						upgradeCounter=0;
		}
		if(delay>MAX_DELAY)
			delay = MIN_DELAY;
		int h = getHeight();
		int w = getWidth();
		if(h < 1 || w < 1)
			return;
		x1 = random.nextInt(w);
		x2 = random.nextInt(w);
		y1 = random.nextInt(h);
		y2 = random.nextInt(h);
	}

	public void run(){
		while(animating){
			try{Thread.sleep(delay);}catch(InterruptedException e){}
			nextLine();
			repaint();
		}
	}

	public void paint(Graphics g){
		super.paint(g);
		g.drawLine(x1,y1,x2,y2);
	}

}