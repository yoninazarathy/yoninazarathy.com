package haifa.shopsim;

/**This little class holds and identifies an operation in a job shop (route, op).*/
public class Operation{
		public int r;
		public int k;
		public Operation(int r_,int k_){r=r_;k=k_;}
		public String toString(){return "("+r+","+k+")";}

		public boolean equals(Object obj){
			Operation op = (Operation)obj;
			return op.r == r && op.k == k;
		}

		public int hashCode(){
			return (r+1)*(k+1);
		}

		public int getRoute(){
			return r;
		}

		public int getStep(){
			return k;
		}
	}