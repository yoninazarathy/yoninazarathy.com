package haifa.shopsim.UI;

import haifa.shopsim.*;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**The GUIAlgorithm is actually not an algorithm, but a user control
through which the user may be asked to control the shops at discrete simulation
epochs*/
public class GUIAlgorithm extends JPanel implements ShopAlgorithm{

	ShopState shopState;
	ShopData shopData;
	JLabel commandLabel;
	HashMap buttonMap;
	JButton restButton;
	JPanel [] routePanels;
	JPanel stepsPanel;
	PrintWriter log;


	private boolean quitFlag=false;

	GUIAlgorithm(	ShopData shopData_,
					ShopState shopState_,
					JLabel commandLabel_) {
			System.out.println("GUI Algorithm Cot'r");
			shopData = shopData_;
			shopState = shopState_;
			commandLabel = commandLabel_;

			int R = shopData.getR();
			int K = shopData.getK();

			buttonMap = new HashMap(K);
			setLayout(new BorderLayout());
			add(restButton = new JButton("Rest"),BorderLayout.WEST);
			add(stepsPanel = new JPanel(),BorderLayout.CENTER);
			stepsPanel.setLayout(new GridLayout(R,1));
			routePanels = new JPanel[R];
			int k=0;
			OperationButtonL bl = new OperationButtonL();
			for(int r=0;r<shopData.getR();r++){
				stepsPanel.add(routePanels[r] = new JPanel(new FlowLayout(FlowLayout.LEFT)));
				java.util.List ops = null;
				try{
					ops = shopData.getRoute(r+1);
				}catch(Exception e){
					System.err.println(e);
					System.exit(1);
				}
				Iterator it = ops.iterator();
				while(it.hasNext()){
					Operation o = (Operation)it.next();
					JButton b = new JButton(o.toString() + " on " +shopData.getMachine(o));
					buttonMap.put(b,o);
					routePanels[r].add(b);
					b.addActionListener(bl);
				}
			}
			restButton.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent ae){
					restClicked=true;
					synchronized(GUIAlgorithm.this){
							GUIAlgorithm.this.notify();
					}
				}

			});
	}

	private Operation nextOperation;

	private boolean restClicked;


	class OperationButtonL implements ActionListener{
		public void actionPerformed(ActionEvent ae){
			nextOperation = (Operation)buttonMap.get(ae.getSource());
			synchronized(GUIAlgorithm.this){
				GUIAlgorithm.this.notify();
			}
		}

	}




	public void setShopStateObject(ShopState shopState_){
		shopState=shopState_;
	}

	public void setShopData(ShopData shopData_){
		shopData=shopData_;
	}

	public void setLog(PrintWriter log_){
		log=log_;
	}


	private void setEnabledDisabled(int machineNumber){
		Collection sch = shopState.getSchedulableOperations();
		Iterator it = buttonMap.entrySet().iterator();
		while(it.hasNext()){
			Map.Entry me = (Map.Entry)it.next();
			int mN = shopData.getMachine((Operation)me.getValue());
			if(sch.contains(me.getValue()) && machineNumber == mN)
				((JButton)me.getKey()).setEnabled(true);
			else
				((JButton)me.getKey()).setEnabled(false);
		}

	}

	/**Very simply reads a command from console and returns a ShopCommmand object.*/
	public ShopCommand whatNow(int machineNumber){
		commandLabel.setText("Please schedule machine #"+machineNumber );

		setEnabledDisabled(machineNumber);
		synchronized(this){
			while(nextOperation == null && restClicked==false)
				try{wait();}catch(InterruptedException e){}

		}

		if(restClicked){
			restClicked=false;
			return new ShopCommand(Integer.toString(machineNumber),
									ShopCommand.CODE_REST);
		}else{
			Operation temp = nextOperation;
			nextOperation = null;
			return new ShopCommand(Integer.toString(machineNumber),temp
									,ShopCommand.CODE_SCHEDULE);
		}
	}


	/**Returns true when the algorithm decided that it is time to quit.*/
	public boolean quitCalled(){
		return quitFlag;
	}

	/***/
	public String explanationString(){
		return null;
	}

	/**Returns false since the user's actions are not specified in the algorithm.*/
	public boolean isDeterministic(){
		return false;
	}

	public static String StaticGetAlgorithmName(){
		return "User Controlled";
	}

	public String getAlgorithmName(){
		return StaticGetAlgorithmName();
	}

	public String toString(){
		return getAlgorithmName();
	}
}//END OF CLASS
