java -jar shopsim.jar shop5.dat
