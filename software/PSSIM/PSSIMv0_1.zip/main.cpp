//////////////////////////////
// PSForkJoinSim Simulator  //
// Yoni Nazarathy, May 2009 //
//////////////////////////////

//This program simulates two processor sharing queues (1 and 2)
//Each serving its own (background) poisson arrival stream and also
//serving a foreground Poisson arrival stream (0) in which each job is
//split with proportion alpha and 1-alpha to the queues and departs once
//it has left both queues. The goal is primarlily to record sojourn times.

//The implementation is quite efficient, there is no dynamic memory allocation
//and only one job object is kept per arriving job (even when it is split).
//jobs are stored in 2 linked lists (split job is stored in both). Removal of a job
//is O(1) since remaining processing time differences are stored and there is no need
//to traverse the list to decrement remaining times.  Arrival is O(queue size) since the list
//is sorted.  An improvement would be to store jobs in a tree making the computation per arrival O(log(queue size))
//this type of improvement would  important when running with parameters in which queue size is typically large

//Note that it also suppurts JSQ routing.

//Use the program by running it while having a file "in.txt" in the directory.
//Messages are output to the consule (so if running in batch, redirect the standard output
//into a proper log file).  Output goes to "out.txt"

//////////////
// Includes //
//////////////
#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <ctime>
using namespace std;

//This is a usefull random number generator found on the web
//You need to also have ranrotb.cpp and link it when linking this compilation
#include "randomc.h"

/////////////////
// Definitions //
/////////////////

//the size of the allocated cyclic array for job objects
#define JOB_ARRAY_SIZE	300000

//the maximum number of jobs allowed to be in the array 
//this is equal to the max number of jobs in the system,
//it should be with negligble probability that this number is exceeded
//and if it is, (WE SHOULD INCREASE IT).
#define MAX_JOBS		150000

#define INFINITY		1000000000000.0

//uniform random variables (used to generate others)
//are drawn in the range (UNIFORM_RV_TRUNCATION,  1- UNIFORM_RV_TRUNCATION)
//Thus variables that are almost 0 or almost 1 are not drawn to avoid numerical
//problems when transforming them to thers (e.g. taking log of them).
#define UNIFORM_RV_TRUNCATION  1.0e-14

//Size of histogram to record with bin size equal 1
#define HIST_SIZE 3000

//File names
#define IN_FILE		"in.txt"


//////////////////////////
// Types and Structures //
//////////////////////////

//In general we use mean 1 for all service
typedef enum DIST_TYPE{
	DET_DIST,		//determinstic												'd'
	ERLANG_2_DIST,	//sum of two exponential(2) r'vs (mean 1).					'e'
	EXP_DIST,		//exponential												'm'
	BIMODAL_1_DIST,	//1/2 with prob 8/9 and 5 with prob 1/9  (mean 1)			'b'
	PARETTO_3_DIST  //paretto with suppurt (0,infinity) and 3 moments  (mean 1)	'p'
};

char* stringOfDist(DIST_TYPE eDist)
{
	switch(eDist)
	{
		case DET_DIST:
			return "Determinstic";
		case ERLANG_2_DIST:
			return "Erlang2";	
		case EXP_DIST:
			return "Exponential";
		case BIMODAL_1_DIST:
			return "Bimodal 1";
		case PARETTO_3_DIST:
			return "Paretto 3";
	}
	return "error";
}

typedef enum ARRIVAL_0_MODE{
	//Implies the arrival is a poisson process
	POISSON_ARRIVALS,

	//Implies that there is "only one" arrival
	//to a steady state system
	//Note: That this produces "bad curves"
	//if trying to keep the same seed and chaning alpha, thus it shouldn't really be used
	ARRIVAL_TO_STEADY_STATE
};

typedef enum ROUTING_TYPE{
	//Split each foreground file with proportions alpha and 1-alpha
	FIXED_FILE_SPLITTING,

	//route each foreground file to the queue with least work
	JSQ_ROUTING
};

//-1 terminated list of alpha values to be run
double*		g_pAlphaList;

struct RunParams{
	int		m_nSeed;
	int		m_nNumJobs0ToRun;

	//proportion in the interval (currently strictly in the interval)
	//of each job that goes to PS1,  the complement goes to PS2
	double	m_dAlpha;

	ARRIVAL_0_MODE	m_eArrival0Mode;

	ROUTING_TYPE	m_eRoutingType;

	//job stream 0, (these are the split jobs), the foreground jobs
	//this parameter is only relevent if the mode is POISSON_ARRIVALS
	double	m_dInterArrivalMean0;

	//this parameter is only relevent if the mode is ARRIVAL_TO_STEADY_STATE
	//it determines how long the system should run after a job 0 (the only one)
	//leaves it
	double	m_dTimeToStabilize;

	double	m_dInterArrivalMean1;
	double	m_dInterArrivalMean2;

	double	m_dServiceMean0;
	double	m_dServiceMean1;
	double	m_dServiceMean2;
	
	//Distribution type of service requirments
	//inter arrivals are always exponential
	DIST_TYPE	m_eDistType0;
	DIST_TYPE	m_eDistType1;
	DIST_TYPE	m_eDistType2;
};

///////////////////////////////////
///////////////////////////////////
///////////////////////////////////
// STATISTICS COLLECTION OBJECTS //
///////////////////////////////////
///////////////////////////////////
///////////////////////////////////

//This class was downloaded from this link:
//It keeps running mean and running variance
//http://www.johndcook.com/standard_deviation.html
class RunningStat
{
    public:
        RunningStat() : m_n(0) {}
        void Clear()
        {m_n = 0;}
        void Push(double x)
        {
            m_n++;
            // See Knuth TAOCP vol 2, 3rd edition, page 232
            if (m_n == 1)
            {
                m_oldM = m_newM = x;
                m_oldS = 0.0;
            }
            else
            {
                m_newM = m_oldM + (x - m_oldM)/m_n;
                m_newS = m_oldS + (x - m_oldM)*(x - m_newM);
                // set up for next iteration
                m_oldM = m_newM; 
                m_oldS = m_newS;
            }
        }
        int NumDataValues() const
        {return m_n;}
        double Mean() const
        {return (m_n > 0) ? m_newM : 0.0;}
        double Variance() const
        {return ( (m_n > 1) ? m_newS/(m_n - 1) : 0.0 );}
        double StandardDeviation() const
        {return sqrt( Variance() );}
    private:int m_n;double m_oldM, m_newM, m_oldS, m_newS;
};

RunningStat		g_statQ1;
RunningStat		g_statQ2;
RunningStat		g_statSojourn1;
RunningStat		g_statSojourn2;
RunningStat		g_statSojourn0;
double histogramSojourn1[HIST_SIZE];
double histogramSojourn2[HIST_SIZE];
double histogramSojourn0[HIST_SIZE];

////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////
////////////////////////////////////////////

//A Job object represents one job that arrived to the system
//even if it is split there is still one object which "is born"
//when the job arrives and "leaves" when the job has completed
//service on both queues (if it is served by both).
struct Job{

	Job():m_bInSystem(0),m_pNextJobPS1(NULL),m_pNextJobPS2(NULL){}

	//'0' if the object is free (job in system) '1' if it is in system
	int		m_bInSystem;

	//These objects are designed to be nodes of two linked lists
	//one list for each queue, thus each node is linked to the 
	//"next node" in both lists or to NULL if it is the last one

	//The lists are sorted according to decreaseing remaining processing time
	//such that the head is the next job to leave service, the one after has more remaning
	//time etc..  When a new job arrives the list is searched LINEARLY (this is a pit fall)
	//and the job is put in place.

	//Instead of keeping the remaining processing time in each node, each node (except for the first)
	//Has the difference in remaining processing time between it's RPT and the RPT of the node before it.
	//This allows for removal of nodes from the queue in constant time, since the RPT of all nodes 
	//decreaes at the same rate during the time at which the head is served.

	double	m_dProcessingTimeToNextEventPS1;
	double	m_dProcessingTimeToNextEventPS2;
	
	//time stamp when job arrives to network
	double	m_dArrivalTime;

	//type of job {0,1,2}
	int		m_nType;

	//unique id of the job
	int		m_nID;

	//'1' if in node 1, '0' if not
	int		m_bInQ1;

	//'1' if in node 2, '0' if not
	int		m_bInQ2;

	//pointers to next job in each queue or NULL if this is the last node
	Job*	m_pNextJobPS1;
	Job*	m_pNextJobPS2;
};


//////////////////////////////
// Static system parameters //
//////////////////////////////

double				g_dAlpha1;
double				g_dAlpha2;
ARRIVAL_0_MODE		g_eArrival0Mode;
ROUTING_TYPE		g_eRoutingType;
double				g_dTimeToStabilize;
double				g_dInterArrivalMean0;
double				g_dInterArrivalMean1;
double				g_dInterArrivalMean2;
double				g_dServiceMean0;
double				g_dServiceMean1;
double				g_dServiceMean2;

//pointers to functions of service times
double (*g_ptfService0)(double mean);
double (*g_ptfService1)(double mean);
double (*g_ptfService2)(double mean);

///////////////////////////////
// RANDOM VARIABLE FUNCTIONS //
///////////////////////////////

//random number generator (one for all simulation)
TRanrotBGenerator	g_SingleRVGenerator;

double rExp(double mean)
{
	double uniform = -1.0;
	double retVal;
	while(uniform < UNIFORM_RV_TRUNCATION || uniform > (1- UNIFORM_RV_TRUNCATION))
	{
		uniform		= g_SingleRVGenerator.Random();
		retVal		= -1*mean*log(uniform);
	}

	return retVal;
}


double rErlang(double mean)
{
	double halfMean = mean/2.0;
	return rExp(halfMean) + rExp(halfMean);
}

double rDet(double mean)
{
	return mean;
}

double rBimodal(double mean)
{
	double uniform		= g_SingleRVGenerator.Random();
	if(uniform <= 8/9)
		return 1/2;
	else
		return 5;
}

double rParetto3(double mean)
{
	double uniform = -1.0;
	double retVal;
	while(uniform < UNIFORM_RV_TRUNCATION || uniform > (1- UNIFORM_RV_TRUNCATION))
	{
		uniform		= g_SingleRVGenerator.Random();
		retVal		= 2 * pow(uniform,-1.0/3.0000) - 2 ;
	}

	return retVal;
}

double GetProcessingTime0()
{return g_ptfService0(g_dServiceMean0);}
double GetProcessingTime1()
{return g_ptfService1(g_dServiceMean1);}
double GetProcessingTime2()
{return g_ptfService2(g_dServiceMean2);}

///////////////////////
// Global state Vars //
///////////////////////

//Time of upcoming arrival on each of the streams
double g_dNextArrival0;
double g_dNextArrival1;
double g_dNextArrival2;

//Time of last update time
double g_dLastPS1Update;
double g_dLastPS2Update;

//Time of next completion time of PS1
double	g_dNextPS1Completion;
double	g_dNextPS2Completion;

//Count of the number of jobs in each of the queues
int		g_nNumJobsInQ1;
int		g_nNumJobsInQ2;	
int		g_nNumJobsInSystem;

//Current time
double g_dTime;


//Count of jobs completed of each type
int		g_nNumJobs0Done;
int		g_nNumJobs1Done;
int		g_nNumJobs2Done;

//Count down timer of number of type 0 jobs left to pass through
int		g_nNumber0JobsLeft;

//array of all job place holders (at any time, most will be free)
Job		g_JobArray[JOB_ARRAY_SIZE];

//index to last allocated job in g_JobArray
int		g_nIndexNextJob;

//heads of the two linked lists of the queues (NULL if empty)
Job*	g_pPS1head;
Job*	g_pPS2head;

////////////////////
// Some functions //
////////////////////

void initVars(RunParams* pParams)
{
	//System parameters	
	g_dAlpha1				= pParams->m_dAlpha;
	g_dAlpha2				= 1 - pParams->m_dAlpha;
	g_eArrival0Mode			= pParams->m_eArrival0Mode;
	g_eRoutingType			= pParams->m_eRoutingType;
	g_dTimeToStabilize		= pParams->m_dTimeToStabilize;
	g_dInterArrivalMean0	= pParams->m_dInterArrivalMean0;
	g_dInterArrivalMean1	= pParams->m_dInterArrivalMean1;
	g_dInterArrivalMean2	= pParams->m_dInterArrivalMean2;
	g_dServiceMean0			= pParams->m_dServiceMean0;
	g_dServiceMean1			= pParams->m_dServiceMean1;
	g_dServiceMean2			= pParams->m_dServiceMean2;

	g_SingleRVGenerator.RandomInit(pParams->m_nSeed);

	switch(pParams->m_eDistType0)
	{
		case 	EXP_DIST:		g_ptfService0 = rExp;		break;
		case	ERLANG_2_DIST:	g_ptfService0 = rErlang;	break;
		case	DET_DIST:		g_ptfService0 = rDet;		break;
		case	BIMODAL_1_DIST:	g_ptfService0 = rBimodal;	break;
		case	PARETTO_3_DIST:	g_ptfService0 = rParetto3;	break;
	}
	
	switch(pParams->m_eDistType1)
	{
		case 	EXP_DIST:		g_ptfService1 = rExp;		break;
		case	ERLANG_2_DIST:	g_ptfService1 = rErlang;	break;
		case	DET_DIST:		g_ptfService1 = rDet;		break;
		case	BIMODAL_1_DIST:	g_ptfService1 = rBimodal;	break;
		case	PARETTO_3_DIST:	g_ptfService1 = rParetto3;	break;
	}
	
	switch(pParams->m_eDistType2)
	{
		case 	EXP_DIST:		g_ptfService2 = rExp;		break;
		case	ERLANG_2_DIST:	g_ptfService2 = rErlang;	break;
		case	DET_DIST:		g_ptfService2 = rDet;		break;
		case	BIMODAL_1_DIST:	g_ptfService2 = rBimodal;	break;
		case	PARETTO_3_DIST:	g_ptfService2 = rParetto3;	break;
	}

	////////////////////
	//State Variables //

	g_dNextArrival0 =  rExp(g_dInterArrivalMean0);
	g_dNextArrival1 =  rExp(g_dInterArrivalMean1);
	g_dNextArrival2 =  rExp(g_dInterArrivalMean2);

	g_dNextPS1Completion = INFINITY;
	g_dNextPS2Completion = INFINITY;
	g_nNumJobsInQ1		= 0;
	g_nNumJobsInQ2		= 0;	
	g_nNumJobsInSystem	= 0;

	g_dTime	= 0;

	g_nNumJobs0Done = 0;
	g_nNumJobs1Done = 0;
	g_nNumJobs2Done = 0;

	g_nNumber0JobsLeft = pParams->m_nNumJobs0ToRun;

	g_nIndexNextJob = 0;

	g_pPS1head = NULL;
	g_pPS2head = NULL;


	////////////
	// Recroding stuff

	for(int i=0;i<HIST_SIZE;++i)
	{
		histogramSojourn0[i] = 0;
		histogramSojourn1[i] = 0;
		histogramSojourn2[i] = 0;
	}

	g_statQ1.Clear();
	g_statQ2.Clear();
	g_statSojourn0.Clear();
	g_statSojourn1.Clear();
	g_statSojourn2.Clear();
}


//////////////////////////
// Get a new job object //
//////////////////////////
Job* GetNewJob()
{
	//cout << g_nNumJobsInSystem << endl;

	//if too many jobs then abort - it should be "virtually impossible"
	if(g_nNumJobsInSystem >= MAX_JOBS)
	{
		cout << "error - to many jobs:"<< g_nNumJobsInSystem << endl;
	}

	//find index of next free job object
	//typically there should be 1 iteration here (unless hitting on a very big job 
	//that stayed the whole wrap around the list)
	while(g_JobArray[g_nIndexNextJob].m_bInSystem == 1)
	{
		++g_nIndexNextJob;
		if(g_nIndexNextJob  == JOB_ARRAY_SIZE) //wrap around
			g_nIndexNextJob =0;
	}

	++g_nNumJobsInSystem;

	g_JobArray[g_nIndexNextJob].m_bInSystem = 1;
	g_JobArray[g_nIndexNextJob].m_dArrivalTime	= g_dTime;

	return &(g_JobArray[g_nIndexNextJob]);
}
	
//////////////////////////
// Release a job object //
//////////////////////////
void FreeJob(Job* job)
{
	--g_nNumJobsInSystem;
	job->m_bInSystem = 0;
}


void ArrivalToPS1(Job* pJob,double serviceTime)
{
	//first update remaining service time of the jobs.
	if(g_nNumJobsInQ1 > 0)
	{
		//remove from the remaining processing time registered
		//in the head node the service that has been given since the last update
		//note that since we keep a linked list of differences this removes
		//service from all processing times.
		g_pPS1head->m_dProcessingTimeToNextEventPS1 
			-= (g_dTime - g_dLastPS1Update)/g_nNumJobsInQ1;

		//this thing can occur due to numeric error
		if(g_pPS1head->m_dProcessingTimeToNextEventPS1 < -10e-6)
		{
			cout << "error PS1, time to next event:" << g_pPS1head->m_dProcessingTimeToNextEventPS1<< endl;
		} 
	}
	g_dLastPS1Update = g_dTime;


	//if no jobs in queue (linked list)
	//add a new job
	if(g_pPS1head == NULL)
	{
		//////////////////////////////
		// ADDING JOB TO EMPTY LIST //
		//////////////////////////////
		
		//cout << "adding to empty PS1 list" <<endl;

		//link job in
		g_pPS1head = pJob;
		pJob->m_pNextJobPS1 = NULL;

		//set service time
		pJob->m_dProcessingTimeToNextEventPS1 = serviceTime;
	}
	//else - if there are jobs but the new one has least remaining service time
	//add the new job at the head
	else if(serviceTime < g_pPS1head->m_dProcessingTimeToNextEventPS1)
	{
		////////////////////////////////////////////////
		// ADDING JOB AT THE HEAD OF A NON-EMPTY LIST //
		////////////////////////////////////////////////

		//cout << "adding to head of non empty PS1 list" <<endl;

		//link job in
		pJob->m_pNextJobPS1 = g_pPS1head;
		g_pPS1head			= pJob;

		//set service time
		pJob->m_dProcessingTimeToNextEventPS1 = serviceTime;

		//set service time of next
		pJob->m_pNextJobPS1->m_dProcessingTimeToNextEventPS1 =
				pJob->m_pNextJobPS1->m_dProcessingTimeToNextEventPS1 - pJob->m_dProcessingTimeToNextEventPS1;
	}
	//else - there are other jobs and we need to search for the spot in the linked list
	else
	{
		////////////////////////////////////////////////////
		// ADDING JOB SOME PLACE NOT AT START OF THE LIST //
		////////////////////////////////////////////////////

		Job* pTemp = g_pPS1head;
		double timeTemp = serviceTime - pTemp->m_dProcessingTimeToNextEventPS1;

		while(true)
		{		
			//if reached end of list (we have biggest job)
			if(pTemp->m_pNextJobPS1 == NULL)
			{
				////////////////////////////////////
				// ADD JOB AT THE END OF THE LIST //
				////////////////////////////////////
				
				//cout << "adding at end of non empty PS1 list" <<endl;

				//link job in
				pTemp->m_pNextJobPS1	= pJob;
				pJob->m_pNextJobPS1		= NULL;

				//set service time
				pJob->m_dProcessingTimeToNextEventPS1 = timeTemp;

				break;
			}


			if(timeTemp < pTemp->m_pNextJobPS1->m_dProcessingTimeToNextEventPS1)
			{			
				/////////////////////////////////
				// ADD JOB IN BODY OF THE LIST //
				/////////////////////////////////

				//cout << "adding in body of non empty PS1 list" <<endl;

				//add job to linked list
				pJob->m_pNextJobPS1		= pTemp->m_pNextJobPS1;
				pTemp->m_pNextJobPS1	= pJob;
			
				//set service time
				pJob->m_dProcessingTimeToNextEventPS1 = timeTemp;

				//set service time of next
				double diff = pJob->m_pNextJobPS1->m_dProcessingTimeToNextEventPS1 - timeTemp;
				pJob->m_pNextJobPS1->m_dProcessingTimeToNextEventPS1 = diff;				;
				
				break;
			}
			
			//iterate to next node
			timeTemp -= pTemp->m_pNextJobPS1->m_dProcessingTimeToNextEventPS1;
			pTemp = pTemp->m_pNextJobPS1;

		}//end of while loop iterating on list
	}//end of else
		

	////////////////////////////
	// UPDATE COMPLETION TIME //
	////////////////////////////

	//increase count of number of jobs in queue
	g_nNumJobsInQ1++;

	g_dNextPS1Completion = g_dTime + g_pPS1head->m_dProcessingTimeToNextEventPS1 * g_nNumJobsInQ1;
}


//This function is horribly copy pasted from the previous
void ArrivalToPS2(Job* pJob,double serviceTime)
{
	//first update remaining service time of the jobs.
	if(g_nNumJobsInQ2 > 0)
	{
		//remove from the remaining processing time registered
		//in the head node the service that has been given since the last update
		//note that since we keep a linked list of differences this removes
		//service from all processing times.
		g_pPS2head->m_dProcessingTimeToNextEventPS2 
			-= (g_dTime - g_dLastPS2Update)/g_nNumJobsInQ2;
		
		if(g_pPS2head->m_dProcessingTimeToNextEventPS2 < -10e-6)
		{
			cout << "error PS2, time to next event:" << g_pPS1head->m_dProcessingTimeToNextEventPS2<< endl;
		}
	}
	g_dLastPS2Update = g_dTime;

	//if no jobs in queue (linked list)
	//add a new job
	if(g_pPS2head == NULL)
	{
		//////////////////////////////
		// ADDING JOB TO EMPTY LIST //
		//////////////////////////////

		//link job in
		g_pPS2head = pJob;
		pJob->m_pNextJobPS2 = NULL;

		//set service time
		pJob->m_dProcessingTimeToNextEventPS2 = serviceTime;
	}
	//else - if there are jobs but the new one has least remaining service time
	//add the new job at the head
	else if(serviceTime < g_pPS2head->m_dProcessingTimeToNextEventPS2)
	{
		////////////////////////////////////////////////
		// ADDING JOB AT THE HEAD OF A NON-EMPTY LIST //
		////////////////////////////////////////////////

		//link job in
		pJob->m_pNextJobPS2 = g_pPS2head;
		g_pPS2head			= pJob;

		//set service time
		pJob->m_dProcessingTimeToNextEventPS2 = serviceTime;

		//set service time of next
		pJob->m_pNextJobPS2->m_dProcessingTimeToNextEventPS2 =
				pJob->m_pNextJobPS2->m_dProcessingTimeToNextEventPS2 - pJob->m_dProcessingTimeToNextEventPS2;
	}
	//else - there are other jobs and we need to search for the spot in the linked list
	else
	{
		////////////////////////////////////////////////////
		// ADDING JOB SOME PLACE NOT AT START OF THE LIST //
		////////////////////////////////////////////////////

		Job* pTemp = g_pPS2head;
		double timeTemp = serviceTime - pTemp->m_dProcessingTimeToNextEventPS2;

		while(true)
		{		
			//if reached end of list (we have biggest job)
			if(pTemp->m_pNextJobPS2 == NULL)
			{
				////////////////////////////////////
				// ADD JOB AT THE END OF THE LIST //
				////////////////////////////////////
				
				//link job in
				pTemp->m_pNextJobPS2	= pJob;
				pJob->m_pNextJobPS2		= NULL;

				//set service time
				pJob->m_dProcessingTimeToNextEventPS2 = timeTemp;

				break;
			}

			if(timeTemp < pTemp->m_pNextJobPS2->m_dProcessingTimeToNextEventPS2)
			{			
				/////////////////////////////////
				// ADD JOB IN BODY OF THE LIST //
				/////////////////////////////////

				//add job to linked list
				pJob->m_pNextJobPS2		= pTemp->m_pNextJobPS2;
				pTemp->m_pNextJobPS2	= pJob;
			
				//set service time
				pJob->m_dProcessingTimeToNextEventPS2 = timeTemp;

				//set service time of next
				pJob->m_pNextJobPS2->m_dProcessingTimeToNextEventPS2 = 
					pJob->m_pNextJobPS2->m_dProcessingTimeToNextEventPS2 - timeTemp;
				
				break;
			}
			
			//iterate to next node
			timeTemp -= pTemp->m_pNextJobPS2->m_dProcessingTimeToNextEventPS2;
			pTemp = pTemp->m_pNextJobPS2;

		}//end of while loop iterating on list
	}//end of else
		

	////////////////////////////
	// UPDATE COMPLETION TIME //
	////////////////////////////

	//increase count of number of jobs in queue
	g_nNumJobsInQ2++;

	g_dNextPS2Completion = g_dTime + g_pPS2head->m_dProcessingTimeToNextEventPS2 * g_nNumJobsInQ2;
}

Job* RemoveJobFromPS1()
{
	--g_nNumJobsInQ1;
	//cout << "Num in Q1 (after removal): " << g_nNumJobsInQ1 << endl;
	Job* retVal = g_pPS1head;
	retVal->m_bInQ1 = 0;

	if(g_nNumJobsInQ1 > 0)
	{
		g_pPS1head = retVal->m_pNextJobPS1;
		g_dNextPS1Completion	= g_dTime + g_pPS1head->m_dProcessingTimeToNextEventPS1 * g_nNumJobsInQ1;
	}
	else
	{
		//cout << "Q1 emptied" << endl;
		g_pPS1head				= NULL;
		g_dNextPS1Completion	= INFINITY;
	}

	g_dLastPS1Update = g_dTime;

	return retVal;
}

//This function is horribly copy pasted from the previous
Job* RemoveJobFromPS2()
{
	--g_nNumJobsInQ2;
	//cout << "Num in Q2 (after removal): " << g_nNumJobsInQ2 << endl;
	Job* retVal = g_pPS2head;
	retVal->m_bInQ2 = 0;

	if(g_nNumJobsInQ2 > 0)
	{
		g_pPS2head = retVal->m_pNextJobPS2;
		g_dNextPS2Completion	= g_dTime + g_pPS2head->m_dProcessingTimeToNextEventPS2 * g_nNumJobsInQ2;
	}
	else
	{
		//cout << "Q2 emptied" << endl;
		g_pPS2head				= NULL;
		g_dNextPS2Completion	= INFINITY;
	}

	g_dLastPS2Update = g_dTime;

	return retVal;
}

//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////

void Report(int jobType,double sojournTime)
{
	int bin = (int)sojournTime;
	if(bin >= HIST_SIZE)
		bin = HIST_SIZE -1;

	switch(jobType)
	{
		case 0:
			histogramSojourn0[bin]++;
			g_statSojourn0.Push(sojournTime);
			break;
		case 1:
			histogramSojourn1[bin]++;
			g_statSojourn1.Push(sojournTime);
			break;
		case 2:
			histogramSojourn2[bin]++;
			g_statSojourn2.Push(sojournTime);
			break;
	}
}


///////////////////////
// Main Sim Function //
///////////////////////



void doRun()
{
	double	newTime;
	double	rTime;
	Job*	pJob,pJob2;
	double dWorkPS1,dWorkPS2;

	double nReportStep = g_nNumber0JobsLeft / 80;
	double nReportCountDown = nReportStep;

	//Main simulation loop;
	while(g_nNumber0JobsLeft > 0)
	{
		//Find time of next event
		newTime = g_dNextArrival0;
		if(g_dNextArrival1 < newTime)
			newTime = g_dNextArrival1;

		if(g_dNextArrival2 < newTime)
			newTime = g_dNextArrival2;

		if(g_dNextPS1Completion < newTime)
			newTime = g_dNextPS1Completion;

		if(g_dNextPS2Completion < newTime)
			newTime = g_dNextPS2Completion;

		g_dTime = newTime;

		//If next event is a type 0 arrival
		if(g_dNextArrival0 == g_dTime)
		{
			//observe queue (PASTA)
			g_statQ1.Push(g_nNumJobsInQ1);
			g_statQ2.Push(g_nNumJobsInQ2);

			pJob = GetNewJob();
			pJob->m_nType = 0;
			rTime = GetProcessingTime0();

			if(g_eRoutingType == JSQ_ROUTING)
			{
				if(g_nNumJobsInQ1 < g_nNumJobsInQ2)
				{
					dWorkPS1 = rTime;
					dWorkPS2 = 0;
				}
				else if(g_nNumJobsInQ1 > g_nNumJobsInQ2)
				{
					dWorkPS1 = 0;
					dWorkPS2 = rTime;
				}
				else //break tie with coin flip
				{
					int bernulli = g_SingleRVGenerator.IRandom(0,1);
					dWorkPS1 = rTime*bernulli;
					dWorkPS2 = rTime*(1-bernulli);
				}
			}
			else	//FIXED_FILE_SPLITTING
			{
				dWorkPS1 = g_dAlpha1*rTime;
				dWorkPS2 = g_dAlpha2*rTime;
			
			}

			pJob->m_bInQ1 = 0;
			pJob->m_bInQ2 = 0;

			if(dWorkPS1 > 0.0)
			{
				pJob->m_bInQ1 = 1;
				ArrivalToPS1(pJob,dWorkPS1);
			}

			if(dWorkPS2 > 0.0)
			{
				pJob->m_bInQ2 = 1;
				ArrivalToPS2(pJob,dWorkPS2);
			}
			
			if(g_eArrival0Mode == POISSON_ARRIVALS)
			{
				g_dNextArrival0 = g_dTime  + rExp(g_dInterArrivalMean0);
			}
			else	//ARRIVAL_TO_STEADY_STATE
			{
				g_dNextArrival0	= INFINITY;
			}
		}

		//If next event is a type 1 arrival
		if(g_dNextArrival1 == g_dTime)
		{
			//observe queue (PASTA)
			g_statQ1.Push(g_nNumJobsInQ1);
			g_statQ2.Push(g_nNumJobsInQ2);

			pJob = GetNewJob();
			pJob->m_nType = 1;
			pJob->m_bInQ1 = 1;
			pJob->m_bInQ2 = 0;
			rTime = GetProcessingTime1();
			ArrivalToPS1(pJob,rTime);
			g_dNextArrival1 = g_dTime + rExp(g_dInterArrivalMean1);
		}

		//If next event is a type 2 arrival
		if(g_dNextArrival2 == g_dTime)
		{
			//observe queue (PASTA)
			g_statQ1.Push(g_nNumJobsInQ1);
			g_statQ2.Push(g_nNumJobsInQ2);

			pJob = GetNewJob();
			pJob->m_nType = 2;
			pJob->m_bInQ1 = 0;
			pJob->m_bInQ2 = 1;
			rTime = GetProcessingTime2();
			ArrivalToPS2(pJob,rTime);
			g_dNextArrival2 = g_dTime + rExp(g_dInterArrivalMean2);
		}

		//If next event is a completion of a job in PS1
		if(g_dNextPS1Completion == g_dTime)
		{
			//cout << "Event: completion of job in PS1" << endl;
			pJob = RemoveJobFromPS1();
			if(pJob->m_nType == 0)
			{
				if(pJob->m_bInQ2 == 0)//if job is '0' type and finished in other queue, time to go
				{
					Report(0, g_dTime - pJob->m_dArrivalTime);
					FreeJob(pJob);
					--g_nNumber0JobsLeft;

					if(g_eArrival0Mode == ARRIVAL_TO_STEADY_STATE)
						g_dNextArrival0 = g_dTime + g_dTimeToStabilize;

					--nReportCountDown;
					if(nReportCountDown == 0)
					{
						nReportCountDown = nReportStep;
						cout << '.';
					}
				}
			}
			else
			{
				FreeJob(pJob);
				Report(pJob->m_nType, g_dTime - pJob->m_dArrivalTime);
			}
		}

		//If next event is a completion of a job in PS2
		if(g_dNextPS2Completion == g_dTime)
		{
			//cout << "Event: completion of job in PS2" << endl;
			pJob = RemoveJobFromPS2();
			if(pJob->m_nType == 0)
			{
				if(pJob->m_bInQ1 == 0)//if job is '0' type and finished in other queue, time to go
				{
					Report(0, g_dTime - pJob->m_dArrivalTime);
					FreeJob(pJob);
					--g_nNumber0JobsLeft;

					if(g_eArrival0Mode == ARRIVAL_TO_STEADY_STATE)
						g_dNextArrival0 = g_dTime + g_dTimeToStabilize;

					//note that jobs of type 0 that are released at same time of both queues
					//are handled in this caluse

					--nReportCountDown;
					if(nReportCountDown == 0)
					{
						nReportCountDown = nReportStep;
						cout << '.';
					}
				}
			}	
			else
			{
				FreeJob(pJob);
				Report(pJob->m_nType, g_dTime - pJob->m_dArrivalTime);
			}
		}
		//cout	<< g_dTime << '\t' 
		//		<< g_nNumJobsInQ1 << '\t'
		//		<< g_nNumJobsInQ2 << '\t'
		//		<< g_nNumJobsInSystem << '\t'
		//		<< g_nIndexNextJob << endl;
	}//loop as long as we have more jobs that need to pass through the system
}

//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////
//////////////////////////////////

char g_outFileName[100];

void DumpStats()
{
	int i;
	ofstream outFile;
	outFile.open(g_outFileName,std::ios_base::app);
	outFile << setiosflags(ios::fixed);
	outFile << " (* NumObs, Mean, Variance *) " << endl;

	outFile << " (* Q1 *) "  << "{" << g_statQ1.NumDataValues()  << "," << g_statQ1.Mean()  << "," << g_statQ1.Variance() << "}," << endl;;
	outFile << " (* Q2 *) "  << "{" << g_statQ2.NumDataValues()  << ","<< g_statQ2.Mean()  << "," << g_statQ2.Variance() << "}," <<endl;
	outFile << " (* Sojourn0 *) "  << "{" << g_statSojourn0.NumDataValues()  << ","<< g_statSojourn0.Mean()  << "," << g_statSojourn0.Variance() << "},"<< endl;;
	outFile << " (* Sojourn1 *) "  << "{" << g_statSojourn1.NumDataValues()  << ","<< g_statSojourn1.Mean()  << "," << g_statSojourn1.Variance() << "},"<< endl;;
	outFile << " (* Sojourn2 *) "  << "{" << g_statSojourn2.NumDataValues()  << ","<< g_statSojourn2.Mean()  << "," << g_statSojourn2.Variance() << "},"<< endl;
	
	outFile << "{";
	outFile << " (* Histogram 1 *) ";
	for(i=0;i<HIST_SIZE-1;++i)
		outFile << "{" << i <<"," << histogramSojourn0[i] << "},";
	outFile << "{" << HIST_SIZE-1 <<"," << histogramSojourn0[HIST_SIZE-1] << "}";
	outFile << "},";
	outFile << endl;

	outFile << "{";
	outFile << " (* Histogram 2 *) ";
	for(i=0;i<HIST_SIZE-1;++i)
		outFile << "{" << i <<"," << histogramSojourn1[i] << "},";
	outFile << "{" << HIST_SIZE-1 <<"," << histogramSojourn0[HIST_SIZE-1] << "}";
	outFile << "},";
	outFile << endl;

	outFile << "{";
	outFile << " (* Histogram 3 *) ";
	for(i=0;i<HIST_SIZE-1;++i)
		outFile << "{" << i <<"," << histogramSojourn2[i] << "},";
	outFile << "{" << HIST_SIZE-1 <<"," << histogramSojourn0[HIST_SIZE-1] << "}";
	outFile << "}";
	outFile << endl;

	outFile.close();
}

bool ReadParams(ifstream& fin, RunParams& runParams)
{
	double dAlpha;
	fin >> dAlpha;
	//'2' stands for JSQ,  '-1' stands for quitting
	if(dAlpha == 2.0)
		runParams.m_eRoutingType		= JSQ_ROUTING;
	else if(dAlpha == -1)
		return false;
	else
	{
		runParams.m_eRoutingType		= FIXED_FILE_SPLITTING;
		runParams.m_dAlpha = dAlpha;
	}

	fin >> runParams.m_nSeed;
	fin >> runParams.m_nNumJobs0ToRun;

	double rate;
	fin >> rate;
		runParams.m_dInterArrivalMean0 = 1/rate;
	fin >> rate;
		runParams.m_dInterArrivalMean1 = 1/rate;
	fin >> rate;
		runParams.m_dInterArrivalMean2 = 1/rate;

	char chDist;
	fin >> chDist;
	switch(chDist)
	{
		case 'd':
			runParams.m_eDistType0 = DET_DIST;
			break;
		case 'e':
			runParams.m_eDistType0 = ERLANG_2_DIST;
			break;
		case 'm':
			runParams.m_eDistType0 = EXP_DIST;
			break;
		case 'b':
			runParams.m_eDistType0 = BIMODAL_1_DIST;
			break;
		case 'p':
			runParams.m_eDistType0 = PARETTO_3_DIST;
			break;
	}

	fin >> chDist;
	switch(chDist)
	{
		case 'd':
			runParams.m_eDistType1 = DET_DIST;
			break;
		case 'e':
			runParams.m_eDistType1 = ERLANG_2_DIST;
			break;
		case 'm':
			runParams.m_eDistType1 = EXP_DIST;
			break;
		case 'b':
			runParams.m_eDistType1 = BIMODAL_1_DIST;
			break;
		case 'p':
			runParams.m_eDistType1 = PARETTO_3_DIST;
			break;
	}

	fin >> chDist;
	switch(chDist)
	{
		case 'd':
			runParams.m_eDistType2 = DET_DIST;
			break;
		case 'e':
			runParams.m_eDistType2 = ERLANG_2_DIST;
			break;
		case 'm':
			runParams.m_eDistType2 = EXP_DIST;
			break;
		case 'b':
			runParams.m_eDistType2 = BIMODAL_1_DIST;
			break;
		case 'p':
			runParams.m_eDistType2 = PARETTO_3_DIST;
			break;
	}

	runParams.m_eArrival0Mode		= POISSON_ARRIVALS;
	runParams.m_dTimeToStabilize	= 100.0;
	runParams.m_dServiceMean0		= 1.0;
	runParams.m_dServiceMean1		= 1.0;
	runParams.m_dServiceMean2		= 1.0;

	return true;
}

//////////
// Main //
//////////

void main()
{
	ifstream fin;
	fin.open(IN_FILE);

	if(fin.good() == 0)
	{
		cout << "problem opening " << IN_FILE << endl;
		exit(0);
	}

	ofstream outFile;
	sprintf(g_outFileName,"out_%d.txt",time(NULL));
	outFile.open(g_outFileName);outFile << "{" <<endl;outFile.close();
	outFile << setiosflags(ios::fixed);

	double timeStart;
	bool bFirst = true;
	while(true)
	{
		RunParams runParams;
		bool bRet = ReadParams(fin,runParams);

		if(!bRet)
			break;

		if(!bFirst)
		{
			outFile.open(g_outFileName,std::ios_base::app);
			outFile << "," <<endl;
			outFile.close();
		}
		bFirst = false;



		initVars(&runParams);

		if(g_eRoutingType == JSQ_ROUTING)
			cout << endl << "running JSQ * " << runParams.m_nNumJobs0ToRun << " jobs" << endl;
		else
			cout << endl << "running alpha = " << runParams.m_dAlpha << " * " << runParams.m_nNumJobs0ToRun  << " jobs"<< endl;
		
		//Do the run
		timeStart = time(NULL);
		doRun();
		cout << "Average simulation time per 100K jobs: " << (100000.0*((time(NULL)-timeStart) / runParams.m_nNumJobs0ToRun)) << endl<< endl;
		
		//Summarize parameters
		outFile.open(g_outFileName,std::ios_base::app);
		outFile << "{";
		outFile << " (*seed*) " << runParams.m_nSeed << ",";
		outFile << " (*policy/alpha*) ";
		if(g_eRoutingType == JSQ_ROUTING)
			outFile << "JSQ" << "," << endl;
		else
			outFile	<< g_dAlpha1 << "," << endl;
		outFile << "{";
		outFile << "{";
		outFile << " (*arrival rates*) ";
		outFile << 1/g_dInterArrivalMean0 << ",";
		outFile << 1/g_dInterArrivalMean1 << ",";
		outFile << 1/g_dInterArrivalMean2 << "},";
		outFile << " { (*distributions*) ";
		outFile << stringOfDist(runParams.m_eDistType0) << ",";
		outFile << stringOfDist(runParams.m_eDistType1) << ",";
		outFile << stringOfDist(runParams.m_eDistType2) << "}},"<< endl;
		outFile.close();

		//dump all collected statistics
		DumpStats();

		outFile.open(g_outFileName,std::ios_base::app); outFile << "}"; outFile.close();
	}

	outFile.open(g_outFileName,std::ios_base::app);outFile << endl << "}";outFile.close();
	fin.close();
}//end of main
